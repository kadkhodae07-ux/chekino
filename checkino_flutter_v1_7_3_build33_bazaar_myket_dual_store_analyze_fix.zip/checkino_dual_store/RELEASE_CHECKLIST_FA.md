# چک‌لیست انتشار چکینو ۱.۶.۲

## پیش‌نیازها

- پکیج‌نیم: `mk.kadkhodai.chekino`
- alias امضا: `bazikhone`
- نسخه: `1.6.2+26`
- فایل‌های `android/bazikhone_release_key.jks` و `android/key.properties` در ZIP سورس موجود هستند.
- آدرس API داخل خود اپ قرار گرفته است: `https://podtman.anony.ir/chekino/api.php`

## راه‌اندازی بک‌اند

1. ZIP بک‌اند `checkino_backend_v1_0_1_offline_sync.zip` را در `public_html/chekino` آپلود و Extract کن.
2. در cPanel یک دیتابیس MySQL و User بساز و دسترسی `ALL PRIVILEGES` بده.
3. `https://podtman.anony.ir/chekino/install.php` را باز کن و نصب را کامل کن.
4. پس از نصب، `install.php` را حذف یا تغییر نام بده.
5. در مرورگر `https://podtman.anony.ir/chekino/health.php` را باز کن و پاسخ سالم بودن سرویس را بررسی کن.

هیچ Variable یا Secret مربوط به API در GitHub لازم نیست.

## اجرای Workflow

1. ZIP سورس `checkino_flutter_v1_6_2_api_embedded_build26.zip` را در ریشهٔ repository قرار بده.
2. فایل `.github/workflows/build-apk.yml` را یک‌بار در repository قرار بده.
3. از تب Actions، Workflow **Build Checkino Android Release** را اجرا کن.
4. APK و AAB امضاشده را از Artifact دانلود کن.

## تست پیش از انتشار

- APK جدید باید روی نسخه قبلی به‌صورت Update نصب شود.
- گوشی را روی حالت پرواز بگذار: ساخت، ویرایش، حذف، یادآور، ویجت، قفل، آمار و بکاپ باید کار کنند.
- در حالت آفلاین یک تیکت ثبت کن؛ پس از اتصال باید از صف ارسال خارج شود.
- پیام همگانی، Pro و ورود ویژه را روی یک دستگاه آزمایشی بررسی کن.
