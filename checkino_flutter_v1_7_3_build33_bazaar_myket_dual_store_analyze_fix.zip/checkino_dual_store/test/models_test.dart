import 'package:checkino/models/check_item.dart';
import 'package:checkino/models/check_list.dart';
import 'package:checkino/models/remote_models.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('CheckItem keeps reminder fields after JSON round-trip', () {
    final dueAt = DateTime(2030, 6, 1, 9, 30);
    final item = CheckItem(
      id: 'item-1',
      title: 'پرداخت قبض',
      note: 'یادآوری مهم',
      priority: ItemPriority.high,
      repeatRule: RepeatRule.monthly,
      dueAt: dueAt,
      reminderEnabled: true,
      subTasks: [SubTask(id: 'sub-1', title: 'بررسی رسید', done: true)],
    );

    final restored = CheckItem.fromJson(item.toJson());

    expect(restored.id, 'item-1');
    expect(restored.reminderEnabled, isTrue);
    expect(restored.dueAt, dueAt);
    expect(restored.priority, ItemPriority.high);
    expect(restored.repeatRule, RepeatRule.monthly);
    expect(restored.completedSubTasks, 1);
  });

  test('a reminder can only be scheduled for an unfinished future item', () {
    final futureItem = CheckItem(
      id: 'future',
      title: 'کار آینده',
      dueAt: DateTime.now().add(const Duration(days: 1)),
      reminderEnabled: true,
    );
    final completedItem = futureItem.copyWith(done: true);

    expect(futureItem.canScheduleReminder, isTrue);
    expect(completedItem.canScheduleReminder, isFalse);
  });

  test('CheckList stores stable manual sort order', () {
    final list = CheckListModel(id: 'list-1', title: 'خانه', sortOrder: 1200);
    final restored = CheckListModel.fromJson(list.toJson());

    expect(restored.sortOrder, 1200);
    expect(restored.id, 'list-1');
  });

  test('server timestamps without timezone are treated as UTC', () {
    final profile = RemoteUserProfile.fromJson({
      'id': 'user-1',
      'tier': 'pro',
      'isBlocked': false,
      'proUntil': '2030-06-01 09:30:00',
    });

    expect(profile.userId, 'user-1');
    expect(profile.proUntil, DateTime.utc(2030, 6, 1, 9, 30).toLocal());
    expect(profile.isPro, isTrue);
  });

  test('remote broadcasts retain their delivery flags after JSON parsing', () {
    final message = RemoteBroadcast.fromJson({
      'id': 'broadcast-1',
      'title': 'نسخه جدید',
      'body': 'امکانات تازه فعال شد.',
      'audience': 'pro',
      'popup': true,
      'active': false,
      'createdAt': '2030-06-01 09:30:00',
    });

    expect(message.id, 'broadcast-1');
    expect(message.audience, 'pro');
    expect(message.popup, isTrue);
    expect(message.active, isFalse);
  });

}
