# چکینو 1.6.5+29

## رفع خطای Build
- افزودن import صحیح `flutter/widgets.dart` برای `RemoteSupportScope` تا `InheritedNotifier` و `BuildContext` شناخته شوند.
- اصلاح ویجت `RemoteSupportScope` که باعث خطا در `main.dart` می‌شد.
- جایگزینی آیکن نامعتبر `Icons.person_edit_rounded` با `Icons.person_rounded`.
- حذف importها و متغیرهای بلااستفاده.
- اصلاح دسترسی به `BuildContext` بعد از عملیات async در اعلان‌های همگانی و تغییر وضعیت پیام.

## تنظیمات ثابت
- پکیج: `mk.kadkhodai.chekino`
- API داخلی: `https://podtman.anony.ir/chekino/api.php`
- نسخه Gradle پین‌شده: `8.14.5`
