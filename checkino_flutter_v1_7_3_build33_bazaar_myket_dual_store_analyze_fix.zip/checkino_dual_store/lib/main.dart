import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'screens/home_shell.dart';
import 'screens/lock_gate.dart';
import 'services/data_controller.dart';
import 'services/reminder_service.dart';
import 'services/theme_settings_controller.dart';
import 'services/monetization_controller.dart';
import 'services/adivery_ads_service.dart';
import 'services/remote_support_controller.dart';
import 'widgets/ad_widgets.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(statusBarColor: Colors.transparent));
  await ReminderService.instance.initialize();
  await AdiveryAdsService.instance.initialize();
  final dataController = CheckinoDataController();
  await dataController.load();
  final monetizationController = MonetizationController();
  await monetizationController.load();
  await monetizationController.recordAppOpen();
  final remoteSupportController = RemoteSupportController();
  await remoteSupportController.load();
  remoteSupportController.observeUsage(
    dataController: dataController,
    monetizationController: monetizationController,
  );
  if (remoteSupportController.profile != null) {
    await monetizationController.setRemoteSubscription(
      isPro: remoteSupportController.profile!.tier == 'pro',
      expiresAt: remoteSupportController.profile!.proUntil,
      source: remoteSupportController.profile!.subscriptionSource,
    );
  }
  runApp(
    CheckinoApp(
      dataController: dataController,
      monetizationController: monetizationController,
      remoteSupportController: remoteSupportController,
    ),
  );
}

class CheckinoApp extends StatefulWidget {
  const CheckinoApp({
    super.key,
    required this.dataController,
    required this.monetizationController,
    required this.remoteSupportController,
  });
  final CheckinoDataController dataController;
  final MonetizationController monetizationController;
  final RemoteSupportController remoteSupportController;

  @override
  State<CheckinoApp> createState() => _CheckinoAppState();
}

class _CheckinoAppState extends State<CheckinoApp> {
  final ThemeSettingsController _themeController = ThemeSettingsController();

  @override
  void initState() {
    super.initState();
    _themeController.load();
  }

  @override
  void dispose() {
    _themeController.dispose();
    widget.monetizationController.dispose();
    widget.remoteSupportController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeController,
      builder: (context, _) {
        final settings = _themeController.settings;
        final isDark = settings.appearance == CheckinoAppearance.dark;
        SystemChrome.setSystemUIOverlayStyle(
          SystemUiOverlayStyle(
            statusBarColor: Colors.transparent,
            statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
            systemNavigationBarColor: isDark ? const Color(0xFF08090F) : const Color(0xFFFAF7FB),
            systemNavigationBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
          ),
        );

        return CheckinoSettings(
          controller: _themeController,
          child: MonetizationScope(
            controller: widget.monetizationController,
            child: RemoteSupportScope(
              controller: widget.remoteSupportController,
              child: CheckinoDataScope(
                controller: widget.dataController,
                child: MaterialApp(
                  title: 'چکینو',
                  debugShowCheckedModeBanner: false,
                  locale: const Locale('fa', 'IR'),
                  supportedLocales: const [Locale('fa', 'IR')],
                  localizationsDelegates: const [
                    GlobalMaterialLocalizations.delegate,
                    GlobalWidgetsLocalizations.delegate,
                    GlobalCupertinoLocalizations.delegate,
                  ],
                  theme: AppTheme.light(settings.accent),
                  darkTheme: AppTheme.dark(settings.accent),
                  themeMode: settings.appearance.mode,
                  builder: (context, child) {
                    return Directionality(
                      textDirection: TextDirection.rtl,
                      child: child ?? const SizedBox.shrink(),
                    );
                  },
                  home: const LockGate(child: HomeShell()),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
