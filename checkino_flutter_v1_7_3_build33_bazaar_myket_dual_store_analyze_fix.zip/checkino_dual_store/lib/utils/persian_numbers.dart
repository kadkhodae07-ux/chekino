String toPersianDigits(Object? value) {
  final input = value?.toString() ?? '';
  const english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  const persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  var output = input;
  for (var i = 0; i < english.length; i++) {
    output = output.replaceAll(english[i], persian[i]);
  }
  return output;
}

String twoDigitsFa(int value) => toPersianDigits(value.toString().padLeft(2, '0'));

class JalaliDate {
  const JalaliDate(this.year, this.month, this.day);

  final int year;
  final int month;
  final int day;

  String get monthName => jalaliMonthNames[month - 1];

  @override
  String toString() => '${toPersianDigits(year)}/${twoDigitsFa(month)}/${twoDigitsFa(day)}';
}

const List<String> jalaliMonthNames = [
  'فروردین',
  'اردیبهشت',
  'خرداد',
  'تیر',
  'مرداد',
  'شهریور',
  'مهر',
  'آبان',
  'آذر',
  'دی',
  'بهمن',
  'اسفند',
];

const List<String> persianWeekdayNames = [
  'دوشنبه',
  'سه‌شنبه',
  'چهارشنبه',
  'پنجشنبه',
  'جمعه',
  'شنبه',
  'یکشنبه',
];

JalaliDate gregorianToJalali(DateTime dateTime) {
  final gDaysInMonth = <int>[31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  final jDaysInMonth = <int>[31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];

  var gy = dateTime.year - 1600;
  var gm = dateTime.month - 1;
  var gd = dateTime.day - 1;

  var gDayNo = 365 * gy + ((gy + 3) ~/ 4) - ((gy + 99) ~/ 100) + ((gy + 399) ~/ 400);
  for (var i = 0; i < gm; ++i) {
    gDayNo += gDaysInMonth[i];
  }
  if (gm > 1 && _isGregorianLeap(dateTime.year)) {
    gDayNo++;
  }
  gDayNo += gd;

  var jDayNo = gDayNo - 79;
  final jNp = jDayNo ~/ 12053;
  jDayNo %= 12053;

  var jy = 979 + 33 * jNp + 4 * (jDayNo ~/ 1461);
  jDayNo %= 1461;

  if (jDayNo >= 366) {
    jy += (jDayNo - 1) ~/ 365;
    jDayNo = (jDayNo - 1) % 365;
  }

  var jm = 0;
  while (jm < 11 && jDayNo >= jDaysInMonth[jm]) {
    jDayNo -= jDaysInMonth[jm];
    jm++;
  }

  return JalaliDate(jy, jm + 1, jDayNo + 1);
}

DateTime jalaliToGregorian(int jy, int jm, int jd, {int hour = 0, int minute = 0}) {
  final gDaysInMonth = <int>[31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  final jDaysInMonth = <int>[31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];

  jy -= 979;
  jm -= 1;
  jd -= 1;

  var jDayNo = 365 * jy + (jy ~/ 33) * 8 + ((jy % 33 + 3) ~/ 4);
  for (var i = 0; i < jm; ++i) {
    jDayNo += jDaysInMonth[i];
  }
  jDayNo += jd;

  var gDayNo = jDayNo + 79;
  var gy = 1600 + 400 * (gDayNo ~/ 146097);
  gDayNo %= 146097;

  var leap = true;
  if (gDayNo >= 36525) {
    gDayNo--;
    gy += 100 * (gDayNo ~/ 36524);
    gDayNo %= 36524;
    if (gDayNo >= 365) {
      gDayNo++;
    } else {
      leap = false;
    }
  }

  gy += 4 * (gDayNo ~/ 1461);
  gDayNo %= 1461;

  if (gDayNo >= 366) {
    leap = false;
    gDayNo--;
    gy += gDayNo ~/ 365;
    gDayNo %= 365;
  }

  var gm = 0;
  while (gm < 11) {
    final days = gDaysInMonth[gm] + (gm == 1 && leap ? 1 : 0);
    if (gDayNo < days) break;
    gDayNo -= days;
    gm++;
  }

  return DateTime(gy, gm + 1, gDayNo + 1, hour, minute);
}

bool _isGregorianLeap(int year) {
  return (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
}

bool isJalaliLeapYear(int year) {
  final start = jalaliToGregorian(year, 1, 1);
  final next = jalaliToGregorian(year + 1, 1, 1);
  return next.difference(start).inDays == 366;
}

int jalaliMonthLength(int year, int month) {
  if (month <= 6) return 31;
  if (month <= 11) return 30;
  return isJalaliLeapYear(year) ? 30 : 29;
}

String formatDateFa(DateTime? dateTime) {
  if (dateTime == null) return 'تنظیم نشده';
  final j = gregorianToJalali(dateTime);
  final weekday = persianWeekdayNames[dateTime.weekday - 1];
  return '$weekday ${toPersianDigits(j.day)} ${j.monthName} ${toPersianDigits(j.year)}';
}

String formatDateShortFa(DateTime? dateTime) {
  if (dateTime == null) return 'تنظیم نشده';
  final j = gregorianToJalali(dateTime);
  return '${toPersianDigits(j.year)}/${twoDigitsFa(j.month)}/${twoDigitsFa(j.day)}';
}

String formatTimeFa(DateTime? dateTime) {
  if (dateTime == null) return '';
  return '${twoDigitsFa(dateTime.hour)}:${twoDigitsFa(dateTime.minute)}';
}

String formatDateTimeFa(DateTime? dateTime) {
  if (dateTime == null) return 'تنظیم نشده';
  return '${formatDateFa(dateTime)} ساعت ${formatTimeFa(dateTime)}';
}

String formatDateTimeCompactFa(DateTime? dateTime) {
  if (dateTime == null) return 'تنظیم نشده';
  return '${formatDateShortFa(dateTime)} - ${formatTimeFa(dateTime)}';
}

bool isSameDay(DateTime a, DateTime b) {
  return a.year == b.year && a.month == b.month && a.day == b.day;
}
