import 'package:flutter/material.dart';

/// Resolves persisted Material icon code points to compile-time icon constants.
///
/// Flutter release builds tree-shake Material icons. Creating [IconData] from a
/// dynamic code point prevents that process and fails in recent Flutter versions.
/// Keep every selectable list icon in this resolver.
IconData checkinoIconFromCodePoint(int codePoint) {
  switch (codePoint) {
    case 0xe85d:
      return Icons.folder_rounded;
    case 0xf8ed:
      return Icons.today;
    case 0xe29c:
      return Icons.flight_takeoff;
    case 0xe8cc:
      return Icons.shopping_cart;
    case 0xe80c:
      return Icons.school;
    case 0xe8f9:
      return Icons.work;
    case 0xe88a:
      return Icons.home;
    case 0xeb43:
      return Icons.fitness_center;
    case 0xe87d:
      return Icons.favorite;
    case 0xe838:
      return Icons.star;
    default:
      return Icons.folder_rounded;
  }
}
