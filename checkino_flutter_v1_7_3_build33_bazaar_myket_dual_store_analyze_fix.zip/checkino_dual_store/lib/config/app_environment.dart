/// Release-time configuration.
///
/// The production API endpoint is embedded in the app. A `--dart-define`
/// named `CHECKINO_API_URL` can still override it for development or staging
/// builds, but no GitHub Variable is required for the production build.
class AppEnvironment {
  const AppEnvironment._();

  static const String appVersion = '1.7.2+32';
  static const String apiUrl = String.fromEnvironment(
    'CHECKINO_API_URL',
    defaultValue: 'https://podtman.anony.ir/chekino/api.php',
  );
  static const bool allowHttpForDebug = bool.fromEnvironment(
    'CHECKINO_ALLOW_HTTP',
    defaultValue: false,
  );

  static Uri? get apiUri {
    final raw = apiUrl.trim();
    if (raw.isEmpty) return null;
    final uri = Uri.tryParse(raw);
    if (uri == null || !uri.hasScheme || uri.host.isEmpty) return null;
    if (uri.scheme != 'https' && !allowHttpForDebug) return null;
    return uri;
  }

  static bool get remoteEnabled => apiUri != null;
}
