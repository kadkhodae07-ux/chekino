import 'package:flutter/material.dart';

class AppThemeColors extends ThemeExtension<AppThemeColors> {
  const AppThemeColors({
    required this.background,
    required this.backgroundSoft,
    required this.card,
    required this.cardAlt,
    required this.border,
    required this.text,
    required this.muted,
    required this.mutedDark,
    required this.accent,
    required this.accentDark,
    required this.danger,
    required this.success,
    required this.warning,
    required this.track,
    required this.isDark,
  });

  final Color background;
  final Color backgroundSoft;
  final Color card;
  final Color cardAlt;
  final Color border;
  final Color text;
  final Color muted;
  final Color mutedDark;
  final Color accent;
  final Color accentDark;
  final Color danger;
  final Color success;
  final Color warning;
  final Color track;
  final bool isDark;

  @override
  AppThemeColors copyWith({
    Color? background,
    Color? backgroundSoft,
    Color? card,
    Color? cardAlt,
    Color? border,
    Color? text,
    Color? muted,
    Color? mutedDark,
    Color? accent,
    Color? accentDark,
    Color? danger,
    Color? success,
    Color? warning,
    Color? track,
    bool? isDark,
  }) {
    return AppThemeColors(
      background: background ?? this.background,
      backgroundSoft: backgroundSoft ?? this.backgroundSoft,
      card: card ?? this.card,
      cardAlt: cardAlt ?? this.cardAlt,
      border: border ?? this.border,
      text: text ?? this.text,
      muted: muted ?? this.muted,
      mutedDark: mutedDark ?? this.mutedDark,
      accent: accent ?? this.accent,
      accentDark: accentDark ?? this.accentDark,
      danger: danger ?? this.danger,
      success: success ?? this.success,
      warning: warning ?? this.warning,
      track: track ?? this.track,
      isDark: isDark ?? this.isDark,
    );
  }

  @override
  AppThemeColors lerp(ThemeExtension<AppThemeColors>? other, double t) {
    if (other is! AppThemeColors) return this;
    return AppThemeColors(
      background: Color.lerp(background, other.background, t)!,
      backgroundSoft: Color.lerp(backgroundSoft, other.backgroundSoft, t)!,
      card: Color.lerp(card, other.card, t)!,
      cardAlt: Color.lerp(cardAlt, other.cardAlt, t)!,
      border: Color.lerp(border, other.border, t)!,
      text: Color.lerp(text, other.text, t)!,
      muted: Color.lerp(muted, other.muted, t)!,
      mutedDark: Color.lerp(mutedDark, other.mutedDark, t)!,
      accent: Color.lerp(accent, other.accent, t)!,
      accentDark: Color.lerp(accentDark, other.accentDark, t)!,
      danger: Color.lerp(danger, other.danger, t)!,
      success: Color.lerp(success, other.success, t)!,
      warning: Color.lerp(warning, other.warning, t)!,
      track: Color.lerp(track, other.track, t)!,
      isDark: t < 0.5 ? isDark : other.isDark,
    );
  }
}

extension AppThemeContext on BuildContext {
  AppThemeColors get appColors => Theme.of(this).extension<AppThemeColors>()!;
}

enum CheckinoAccent { pink, green, purple, blue }

enum CheckinoAppearance { dark, light }

extension CheckinoAccentInfo on CheckinoAccent {
  String get id {
    switch (this) {
      case CheckinoAccent.pink:
        return 'pink';
      case CheckinoAccent.green:
        return 'green';
      case CheckinoAccent.purple:
        return 'purple';
      case CheckinoAccent.blue:
        return 'blue';
    }
  }

  String get title {
    switch (this) {
      case CheckinoAccent.pink:
        return 'صورتی';
      case CheckinoAccent.green:
        return 'سبز';
      case CheckinoAccent.purple:
        return 'بنفش';
      case CheckinoAccent.blue:
        return 'آبی';
    }
  }

  Color get color {
    switch (this) {
      case CheckinoAccent.pink:
        return const Color(0xFFFF70B8);
      case CheckinoAccent.green:
        return const Color(0xFF22C55E);
      case CheckinoAccent.purple:
        return const Color(0xFF9D4EDD);
      case CheckinoAccent.blue:
        return const Color(0xFF38BDF8);
    }
  }

  Color get darkColor {
    switch (this) {
      case CheckinoAccent.pink:
        return const Color(0xFF9D4EDD);
      case CheckinoAccent.green:
        return const Color(0xFF14B8A6);
      case CheckinoAccent.purple:
        return const Color(0xFF5B6CFF);
      case CheckinoAccent.blue:
        return const Color(0xFF2563EB);
    }
  }
}

CheckinoAccent checkinoAccentFromId(String? id) {
  return CheckinoAccent.values.firstWhere(
    (item) => item.id == id,
    orElse: () => CheckinoAccent.pink,
  );
}

extension CheckinoAppearanceInfo on CheckinoAppearance {
  String get id => this == CheckinoAppearance.dark ? 'dark' : 'light';
  String get title => this == CheckinoAppearance.dark ? 'تم تیره' : 'تم روشن';
  ThemeMode get mode => this == CheckinoAppearance.dark ? ThemeMode.dark : ThemeMode.light;
}

CheckinoAppearance checkinoAppearanceFromId(String? id) {
  return CheckinoAppearance.values.firstWhere(
    (item) => item.id == id,
    orElse: () => CheckinoAppearance.dark,
  );
}

class CheckinoThemeSettings {
  const CheckinoThemeSettings({
    this.appearance = CheckinoAppearance.dark,
    this.accent = CheckinoAccent.pink,
  });

  final CheckinoAppearance appearance;
  final CheckinoAccent accent;

  CheckinoThemeSettings copyWith({CheckinoAppearance? appearance, CheckinoAccent? accent}) {
    return CheckinoThemeSettings(
      appearance: appearance ?? this.appearance,
      accent: accent ?? this.accent,
    );
  }

  Map<String, dynamic> toJson() => {'appearance': appearance.id, 'accent': accent.id};

  factory CheckinoThemeSettings.fromJson(Map<String, dynamic> json) {
    return CheckinoThemeSettings(
      appearance: checkinoAppearanceFromId(json['appearance'] as String?),
      accent: checkinoAccentFromId(json['accent'] as String?),
    );
  }
}

class AppTheme {
  static ThemeData dark(CheckinoAccent accent) => _base(Brightness.dark, _darkColors(accent));
  static ThemeData light(CheckinoAccent accent) => _base(Brightness.light, _lightColors(accent));

  static ThemeData _base(Brightness brightness, AppThemeColors colors) {
    final base = ThemeData(useMaterial3: true, brightness: brightness, fontFamily: null);
    return base.copyWith(
      scaffoldBackgroundColor: colors.background,
      extensions: [colors],
      colorScheme: ColorScheme(
        brightness: brightness,
        primary: colors.accent,
        onPrimary: Colors.white,
        secondary: colors.accentDark,
        onSecondary: Colors.white,
        error: colors.danger,
        onError: Colors.white,
        surface: colors.card,
        onSurface: colors.text,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        foregroundColor: colors.text,
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: colors.accent,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
          textStyle: const TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: colors.accent,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: colors.cardAlt.withValues(alpha: colors.isDark ? 0.88 : 0.96),
        hintStyle: TextStyle(color: colors.mutedDark),
        labelStyle: TextStyle(color: colors.muted),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: BorderSide(color: colors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: BorderSide(color: colors.accent, width: 1.2),
        ),
      ),
      chipTheme: base.chipTheme.copyWith(
        side: BorderSide(color: colors.border),
        selectedColor: colors.accent.withValues(alpha: 0.18),
        backgroundColor: colors.cardAlt,
        labelStyle: TextStyle(color: colors.text, fontWeight: FontWeight.w700),
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: colors.card.withValues(alpha: 0.92),
        selectedItemColor: colors.accent,
        unselectedItemColor: colors.mutedDark,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
      ),
    );
  }

  static AppThemeColors _darkColors(CheckinoAccent accent) {
    return AppThemeColors(
      background: const Color(0xFF08090F),
      backgroundSoft: const Color(0xFF11131D),
      card: const Color(0xFF151724),
      cardAlt: const Color(0xFF1C1F2E),
      border: const Color(0xFF2B3045),
      text: const Color(0xFFF7F7FF),
      muted: const Color(0xFFB9BCD0),
      mutedDark: const Color(0xFF7E839A),
      accent: accent.color,
      accentDark: accent.darkColor,
      danger: const Color(0xFFFF5D73),
      success: const Color(0xFF34D399),
      warning: const Color(0xFFFBBF24),
      track: const Color(0xFF2A2E42),
      isDark: true,
    );
  }

  static AppThemeColors _lightColors(CheckinoAccent accent) {
    return AppThemeColors(
      background: const Color(0xFFFAF7FB),
      backgroundSoft: const Color(0xFFF2ECF6),
      card: const Color(0xFFFFFFFF),
      cardAlt: const Color(0xFFF8F3FC),
      border: const Color(0xFFE9DFF0),
      text: const Color(0xFF181622),
      muted: const Color(0xFF555065),
      mutedDark: const Color(0xFF898292),
      accent: accent.color,
      accentDark: accent.darkColor,
      danger: const Color(0xFFE11D48),
      success: const Color(0xFF16A34A),
      warning: const Color(0xFFD97706),
      track: const Color(0xFFEADFED),
      isDark: false,
    );
  }
}
