import 'check_item.dart';

String _id() => DateTime.now().microsecondsSinceEpoch.toString();

int _stableListNotificationId(String value) {
  var hash = 17;
  for (final codeUnit in value.codeUnits) {
    hash = (hash * 37 + codeUnit) & 0x3fffffff;
  }
  return 100000000 + (hash % 90000000);
}

enum ReminderLeadTime { none, atDueTime, fiveMinutesBefore, tenMinutesBefore, fifteenMinutesBefore, oneHourBefore, oneDayBefore }

extension ReminderLeadTimeInfo on ReminderLeadTime {
  String get id {
    switch (this) {
      case ReminderLeadTime.none:
        return 'none';
      case ReminderLeadTime.atDueTime:
        return 'at_due_time';
      case ReminderLeadTime.fiveMinutesBefore:
        return 'five_minutes_before';
      case ReminderLeadTime.tenMinutesBefore:
        return 'ten_minutes_before';
      case ReminderLeadTime.fifteenMinutesBefore:
        return 'fifteen_minutes_before';
      case ReminderLeadTime.oneHourBefore:
        return 'one_hour_before';
      case ReminderLeadTime.oneDayBefore:
        return 'one_day_before';
    }
  }

  String get title {
    switch (this) {
      case ReminderLeadTime.none:
        return 'بدون یادآور';
      case ReminderLeadTime.atDueTime:
        return 'در زمان موعد';
      case ReminderLeadTime.fiveMinutesBefore:
        return '۵ دقیقه قبل';
      case ReminderLeadTime.tenMinutesBefore:
        return '۱۰ دقیقه قبل';
      case ReminderLeadTime.fifteenMinutesBefore:
        return '۱۵ دقیقه قبل';
      case ReminderLeadTime.oneHourBefore:
        return '۱ ساعت قبل';
      case ReminderLeadTime.oneDayBefore:
        return '۱ روز قبل';
    }
  }

  Duration? get offset {
    switch (this) {
      case ReminderLeadTime.none:
        return null;
      case ReminderLeadTime.atDueTime:
        return Duration.zero;
      case ReminderLeadTime.fiveMinutesBefore:
        return const Duration(minutes: 5);
      case ReminderLeadTime.tenMinutesBefore:
        return const Duration(minutes: 10);
      case ReminderLeadTime.fifteenMinutesBefore:
        return const Duration(minutes: 15);
      case ReminderLeadTime.oneHourBefore:
        return const Duration(hours: 1);
      case ReminderLeadTime.oneDayBefore:
        return const Duration(days: 1);
    }
  }
}

ReminderLeadTime reminderLeadTimeFromId(String? id) {
  return ReminderLeadTime.values.firstWhere((item) => item.id == id, orElse: () => ReminderLeadTime.none);
}

class CheckListModel {
  CheckListModel({
    required this.id,
    required this.title,
    List<CheckItem>? items,
    DateTime? createdAt,
    this.dueAt,
    this.reminderLeadTime = ReminderLeadTime.none,
    this.archived = false,
    this.pinned = false,
    this.sortOrder = 0,
    this.iconCodePoint = 0xe85d,
    this.colorValue,
  })  : items = items ?? <CheckItem>[],
        createdAt = createdAt ?? DateTime.now();

  final String id;
  final String title;
  final List<CheckItem> items;
  final DateTime createdAt;
  final DateTime? dueAt;
  final ReminderLeadTime reminderLeadTime;
  final bool archived;
  final bool pinned;
  final int sortOrder;
  final int iconCodePoint;
  final int? colorValue;

  int get totalItems => items.length;
  int get completedItems => items.where((item) => item.done).length;
  int get remainingItems => totalItems - completedItems;
  int get highPriorityCount => items.where((item) => !item.done && item.priority == ItemPriority.high).length;
  int get overdueCount => items.where((item) => item.isOverdue).length;
  int get todayCount => items.where((item) => item.hasDueToday && !item.done).length;

  double get progress => totalItems == 0 ? 0 : completedItems / totalItems;
  int get progressPercent => (progress * 100).round();
  bool get isComplete => totalItems > 0 && remainingItems == 0;

  bool get reminderEnabled => dueAt != null && reminderLeadTime != ReminderLeadTime.none;

  DateTime? get reminderAt {
    final offset = reminderLeadTime.offset;
    if (dueAt == null || offset == null) return null;
    return dueAt!.subtract(offset);
  }

  DateTime? get nextReminderAt {
    if (!reminderEnabled || dueAt == null || reminderAt == null) return null;
    final now = DateTime.now();
    if (!dueAt!.isAfter(now)) return null;
    final safeMinimum = now.add(const Duration(seconds: 30));
    if (reminderAt!.isAfter(safeMinimum)) return reminderAt;
    if (dueAt!.isAfter(safeMinimum)) return dueAt;
    return null;
  }

  int get reminderNotificationId => _stableListNotificationId(id);

  CheckListModel copyWith({
    String? id,
    String? title,
    List<CheckItem>? items,
    DateTime? createdAt,
    DateTime? dueAt,
    bool clearDueAt = false,
    ReminderLeadTime? reminderLeadTime,
    bool? archived,
    bool? pinned,
    int? sortOrder,
    int? iconCodePoint,
    int? colorValue,
    bool clearColor = false,
  }) {
    return CheckListModel(
      id: id ?? this.id,
      title: title ?? this.title,
      items: items ?? this.items,
      createdAt: createdAt ?? this.createdAt,
      dueAt: clearDueAt ? null : dueAt ?? this.dueAt,
      reminderLeadTime: reminderLeadTime ?? this.reminderLeadTime,
      archived: archived ?? this.archived,
      pinned: pinned ?? this.pinned,
      sortOrder: sortOrder ?? this.sortOrder,
      iconCodePoint: iconCodePoint ?? this.iconCodePoint,
      colorValue: clearColor ? null : colorValue ?? this.colorValue,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'items': items.map((item) => item.toJson()).toList(),
      'createdAt': createdAt.toIso8601String(),
      'dueAt': dueAt?.toIso8601String(),
      'reminderLeadTime': reminderLeadTime.id,
      'archived': archived,
      'pinned': pinned,
      'sortOrder': sortOrder,
      'iconCodePoint': iconCodePoint,
      'colorValue': colorValue,
    };
  }

  factory CheckListModel.fromJson(Map<String, dynamic> json) {
    final rawItems = json['items'];
    return CheckListModel(
      id: json['id'] as String? ?? _id(),
      title: json['title'] as String? ?? 'لیست بدون عنوان',
      items: rawItems is List
          ? rawItems.whereType<Map>().map((item) => CheckItem.fromJson(Map<String, dynamic>.from(item))).toList()
          : <CheckItem>[],
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
      dueAt: DateTime.tryParse(json['dueAt'] as String? ?? ''),
      reminderLeadTime: reminderLeadTimeFromId(json['reminderLeadTime'] as String?),
      archived: json['archived'] as bool? ?? false,
      pinned: json['pinned'] as bool? ?? false,
      sortOrder: json['sortOrder'] as int? ?? 0,
      iconCodePoint: json['iconCodePoint'] as int? ?? 0xe85d,
      colorValue: json['colorValue'] as int?,
    );
  }
}
