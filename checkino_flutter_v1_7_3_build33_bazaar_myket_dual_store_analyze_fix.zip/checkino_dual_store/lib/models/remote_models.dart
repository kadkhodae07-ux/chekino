DateTime? _date(dynamic value) {
  if (value is! String || value.trim().isEmpty) return null;
  final raw = value.trim();
  // MySQL timestamps returned by the API are UTC but do not contain a timezone.
  // Make that explicit before converting to the device's local time.
  final hasTimezone = RegExp(r'(Z|[+-]\d{2}:?\d{2})$', caseSensitive: false).hasMatch(raw);
  final normalized = hasTimezone ? raw : '${raw.replaceFirst(' ', 'T')}Z';
  return DateTime.tryParse(normalized)?.toLocal();
}

int _int(dynamic value) => value is int ? value : int.tryParse(value?.toString() ?? '') ?? 0;
bool _bool(dynamic value) => value == true || value == 1 || value == '1';

class RemoteUserProfile {
  const RemoteUserProfile({
    required this.userId,
    required this.tier,
    required this.isBlocked,
    this.proUntil,
    this.blockReason,
    this.unreadTicketCount = 0,
    this.subscriptionSource,
  });

  final String userId;
  final String tier;
  final bool isBlocked;
  final DateTime? proUntil;
  final String? blockReason;
  final int unreadTicketCount;
  final String? subscriptionSource;

  bool get isPro => tier == 'pro' && (proUntil == null || proUntil!.isAfter(DateTime.now()));

  Map<String, dynamic> toJson() => {
        'userId': userId,
        'tier': tier,
        'isBlocked': isBlocked,
        'proUntil': proUntil?.toUtc().toIso8601String(),
        'blockReason': blockReason,
        'unreadTicketCount': unreadTicketCount,
        'subscriptionSource': subscriptionSource,
      };

  factory RemoteUserProfile.fromJson(Map<String, dynamic> json) {
    return RemoteUserProfile(
      userId: json['id']?.toString() ?? json['userId']?.toString() ?? '',
      tier: json['tier']?.toString() == 'pro' ? 'pro' : 'free',
      isBlocked: _bool(json['isBlocked'] ?? json['is_blocked']),
      proUntil: _date(json['proUntil'] ?? json['pro_until']),
      blockReason: json['blockReason']?.toString() ?? json['block_reason']?.toString(),
      unreadTicketCount: _int(json['unreadTicketCount'] ?? json['unread_ticket_count']),
      subscriptionSource: json['subscriptionSource']?.toString() ?? json['subscription_source']?.toString(),
    );
  }
}

class RemoteBroadcast {
  const RemoteBroadcast({
    required this.id,
    required this.title,
    required this.body,
    required this.audience,
    required this.popup,
    required this.active,
    required this.createdAt,
  });

  final String id;
  final String title;
  final String body;
  final String audience;
  final bool popup;
  final bool active;
  final DateTime? createdAt;

  factory RemoteBroadcast.fromJson(Map<String, dynamic> json) => RemoteBroadcast(
        id: json['id']?.toString() ?? '',
        title: json['title']?.toString() ?? 'پیام جدید',
        body: json['body']?.toString() ?? '',
        audience: json['audience']?.toString() ?? 'all',
        popup: _bool(json['popup'] ?? json['showPopup'] ?? json['show_popup']),
        active: json.containsKey('active') || json.containsKey('isActive') || json.containsKey('is_active')
            ? _bool(json['active'] ?? json['isActive'] ?? json['is_active'])
            : true,
        createdAt: _date(json['createdAt'] ?? json['created_at']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'body': body,
        'audience': audience,
        'popup': popup,
        'active': active,
        'createdAt': createdAt?.toUtc().toIso8601String(),
      };
}

/// A support ticket is stored locally as well as on the server. The local state
/// enables users to compose and keep tickets while completely offline.
class SupportTicket {
  const SupportTicket({
    required this.id,
    required this.subject,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    this.lastMessage,
    this.messages = const [],
    this.syncState = TicketSyncState.synced,
  });

  final String id;
  final String subject;
  final String status;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String? lastMessage;
  final List<SupportTicketMessage> messages;
  final TicketSyncState syncState;

  bool get isClosed => status == 'closed';
  bool get isLocalOnly => id.startsWith('local-');
  bool get hasPendingSync => syncState != TicketSyncState.synced;

  SupportTicket copyWith({
    String? id,
    String? subject,
    String? status,
    DateTime? createdAt,
    DateTime? updatedAt,
    String? lastMessage,
    bool clearLastMessage = false,
    List<SupportTicketMessage>? messages,
    TicketSyncState? syncState,
  }) {
    return SupportTicket(
      id: id ?? this.id,
      subject: subject ?? this.subject,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      lastMessage: clearLastMessage ? null : lastMessage ?? this.lastMessage,
      messages: messages ?? this.messages,
      syncState: syncState ?? this.syncState,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'subject': subject,
        'status': status,
        'createdAt': createdAt?.toUtc().toIso8601String(),
        'updatedAt': updatedAt?.toUtc().toIso8601String(),
        'lastMessage': lastMessage,
        'messages': messages.map((item) => item.toJson()).toList(),
        'syncState': syncState.name,
      };

  factory SupportTicket.fromJson(Map<String, dynamic> json) {
    final rawMessages = json['messages'];
    final rawSyncState = json['syncState']?.toString();
    final syncState = TicketSyncState.values.where((item) => item.name == rawSyncState).firstOrNull ?? TicketSyncState.synced;
    return SupportTicket(
      id: json['id']?.toString() ?? '',
      subject: json['subject']?.toString() ?? 'درخواست پشتیبانی',
      status: json['status']?.toString() ?? 'open',
      createdAt: _date(json['createdAt'] ?? json['created_at']),
      updatedAt: _date(json['updatedAt'] ?? json['updated_at']),
      lastMessage: json['lastMessage']?.toString() ?? json['last_message']?.toString(),
      messages: rawMessages is List
          ? rawMessages.whereType<Map>().map((item) => SupportTicketMessage.fromJson(Map<String, dynamic>.from(item))).toList()
          : const [],
      syncState: syncState,
    );
  }
}

enum TicketSyncState { synced, pending, failed }

class SupportTicketMessage {
  const SupportTicketMessage({
    required this.id,
    required this.sender,
    required this.body,
    required this.createdAt,
    this.pending = false,
  });

  final String id;
  final String sender;
  final String body;
  final DateTime? createdAt;
  final bool pending;

  bool get fromUser => sender == 'user';

  factory SupportTicketMessage.fromJson(Map<String, dynamic> json) => SupportTicketMessage(
        id: json['id']?.toString() ?? '',
        sender: json['sender']?.toString() ?? json['sender_type']?.toString() ?? 'user',
        body: json['body']?.toString() ?? '',
        createdAt: _date(json['createdAt'] ?? json['created_at']),
        pending: _bool(json['pending']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'sender': sender,
        'body': body,
        'createdAt': createdAt?.toUtc().toIso8601String(),
        'pending': pending,
      };
}

class AdminSession {
  const AdminSession({required this.token, required this.username, required this.expiresAt});

  final String token;
  final String username;
  final DateTime? expiresAt;

  bool get isExpired => expiresAt != null && !expiresAt!.isAfter(DateTime.now());

  factory AdminSession.fromJson(Map<String, dynamic> json) => AdminSession(
        token: json['token']?.toString() ?? '',
        username: json['username']?.toString() ?? '',
        expiresAt: _date(json['expiresAt'] ?? json['expires_at']),
      );

  Map<String, dynamic> toJson() => {
        'token': token,
        'username': username,
        'expiresAt': expiresAt?.toUtc().toIso8601String(),
      };
}

class AdminDashboardStats {
  const AdminDashboardStats({
    required this.totalUsers,
    required this.activeToday,
    required this.freeUsers,
    required this.proUsers,
    required this.blockedUsers,
    required this.openTickets,
    required this.newUsersWeek,
  });

  final int totalUsers;
  final int activeToday;
  final int freeUsers;
  final int proUsers;
  final int blockedUsers;
  final int openTickets;
  final int newUsersWeek;

  factory AdminDashboardStats.fromJson(Map<String, dynamic> json) => AdminDashboardStats(
        totalUsers: _int(json['totalUsers'] ?? json['total_users']),
        activeToday: _int(json['activeToday'] ?? json['active_today']),
        freeUsers: _int(json['freeUsers'] ?? json['free_users']),
        proUsers: _int(json['proUsers'] ?? json['pro_users']),
        blockedUsers: _int(json['blockedUsers'] ?? json['blocked_users']),
        openTickets: _int(json['openTickets'] ?? json['open_tickets']),
        newUsersWeek: _int(json['newUsersWeek'] ?? json['new_users_week']),
      );
}

class ManagedUser {
  const ManagedUser({
    required this.id,
    required this.tier,
    required this.isBlocked,
    required this.createdAt,
    required this.lastSeenAt,
    required this.appVersion,
    required this.platform,
    required this.activeLists,
    required this.totalItems,
    required this.doneItems,
    required this.ticketCount,
    this.proUntil,
    this.note,
    this.blockReason,
    this.subscriptionSource,
  });

  final String id;
  final String tier;
  final bool isBlocked;
  final DateTime? createdAt;
  final DateTime? lastSeenAt;
  final String appVersion;
  final String platform;
  final int activeLists;
  final int totalItems;
  final int doneItems;
  final int ticketCount;
  final DateTime? proUntil;
  final String? note;
  final String? blockReason;
  final String? subscriptionSource;

  factory ManagedUser.fromJson(Map<String, dynamic> json) => ManagedUser(
        id: json['id']?.toString() ?? '',
        tier: json['tier']?.toString() == 'pro' ? 'pro' : 'free',
        isBlocked: _bool(json['isBlocked'] ?? json['is_blocked']),
        createdAt: _date(json['createdAt'] ?? json['created_at']),
        lastSeenAt: _date(json['lastSeenAt'] ?? json['last_seen_at']),
        appVersion: json['appVersion']?.toString() ?? json['app_version']?.toString() ?? '-',
        platform: json['platform']?.toString() ?? '-',
        activeLists: _int(json['activeLists'] ?? json['active_lists']),
        totalItems: _int(json['totalItems'] ?? json['total_items']),
        doneItems: _int(json['doneItems'] ?? json['done_items']),
        ticketCount: _int(json['ticketCount'] ?? json['ticket_count']),
        proUntil: _date(json['proUntil'] ?? json['pro_until']),
        note: json['note']?.toString(),
        blockReason: json['blockReason']?.toString() ?? json['block_reason']?.toString(),
        subscriptionSource: json['subscriptionSource']?.toString() ?? json['subscription_source']?.toString(),
      );
}

class AdminAuditEntry {
  const AdminAuditEntry({required this.id, required this.action, required this.summary, required this.createdAt});

  final String id;
  final String action;
  final String summary;
  final DateTime? createdAt;

  factory AdminAuditEntry.fromJson(Map<String, dynamic> json) => AdminAuditEntry(
        id: json['id']?.toString() ?? '',
        action: json['action']?.toString() ?? '',
        summary: json['summary']?.toString() ?? '',
        createdAt: _date(json['createdAt'] ?? json['created_at']),
      );
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
