import '../utils/persian_numbers.dart';

String _id() => DateTime.now().microsecondsSinceEpoch.toString();

int _stableNotificationId(String value, int offset) {
  var hash = 17;
  for (final codeUnit in value.codeUnits) {
    hash = (hash * 37 + codeUnit) & 0x3fffffff;
  }
  return offset + (hash % 90000000);
}

enum ItemPriority { low, normal, high }

extension ItemPriorityInfo on ItemPriority {
  String get id {
    switch (this) {
      case ItemPriority.low:
        return 'low';
      case ItemPriority.normal:
        return 'normal';
      case ItemPriority.high:
        return 'high';
    }
  }

  String get title {
    switch (this) {
      case ItemPriority.low:
        return 'کم‌اهمیت';
      case ItemPriority.normal:
        return 'معمولی';
      case ItemPriority.high:
        return 'مهم';
    }
  }
}

ItemPriority itemPriorityFromId(String? id) {
  return ItemPriority.values.firstWhere((item) => item.id == id, orElse: () => ItemPriority.normal);
}

enum RepeatRule { none, daily, weekly, monthly }

extension RepeatRuleInfo on RepeatRule {
  String get id {
    switch (this) {
      case RepeatRule.none:
        return 'none';
      case RepeatRule.daily:
        return 'daily';
      case RepeatRule.weekly:
        return 'weekly';
      case RepeatRule.monthly:
        return 'monthly';
    }
  }

  String get title {
    switch (this) {
      case RepeatRule.none:
        return 'بدون تکرار';
      case RepeatRule.daily:
        return 'روزانه';
      case RepeatRule.weekly:
        return 'هفتگی';
      case RepeatRule.monthly:
        return 'ماهانه';
    }
  }

  DateTime? nextDate(DateTime? base) {
    if (base == null || this == RepeatRule.none) return null;
    switch (this) {
      case RepeatRule.none:
        return null;
      case RepeatRule.daily:
        return base.add(const Duration(days: 1));
      case RepeatRule.weekly:
        return base.add(const Duration(days: 7));
      case RepeatRule.monthly:
        return DateTime(base.year, base.month + 1, base.day, base.hour, base.minute);
    }
  }
}

RepeatRule repeatRuleFromId(String? id) {
  return RepeatRule.values.firstWhere((item) => item.id == id, orElse: () => RepeatRule.none);
}

class SubTask {
  SubTask({required this.id, required this.title, this.done = false});

  final String id;
  final String title;
  final bool done;

  SubTask copyWith({String? id, String? title, bool? done}) {
    return SubTask(id: id ?? this.id, title: title ?? this.title, done: done ?? this.done);
  }

  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'done': done};

  factory SubTask.fromJson(Map<String, dynamic> json) {
    return SubTask(
      id: json['id'] as String? ?? _id(),
      title: json['title'] as String? ?? 'زیرکار',
      done: json['done'] as bool? ?? false,
    );
  }
}

class CheckItem {
  CheckItem({
    required this.id,
    required this.title,
    this.note,
    this.done = false,
    this.priority = ItemPriority.normal,
    this.repeatRule = RepeatRule.none,
    this.dueAt,
    this.reminderEnabled = false,
    this.imagePath,
    List<SubTask>? subTasks,
    DateTime? createdAt,
    this.completedAt,
  })  : subTasks = subTasks ?? <SubTask>[],
        createdAt = createdAt ?? DateTime.now();

  final String id;
  final String title;
  final String? note;
  final bool done;
  final ItemPriority priority;
  final RepeatRule repeatRule;
  final DateTime? dueAt;
  final bool reminderEnabled;
  final String? imagePath;
  final List<SubTask> subTasks;
  final DateTime createdAt;
  final DateTime? completedAt;

  int get completedSubTasks => subTasks.where((item) => item.done).length;
  int get totalSubTasks => subTasks.length;
  bool get hasDueToday => dueAt != null && isSameDay(dueAt!, DateTime.now());
  bool get isOverdue => dueAt != null && !done && dueAt!.isBefore(DateTime.now());
  bool get canScheduleReminder => reminderEnabled && !done && dueAt != null && dueAt!.isAfter(DateTime.now());
  int get reminderNotificationId => _stableNotificationId('item:$id', 200000000);

  CheckItem copyWith({
    String? id,
    String? title,
    String? note,
    bool clearNote = false,
    bool? done,
    ItemPriority? priority,
    RepeatRule? repeatRule,
    DateTime? dueAt,
    bool clearDueAt = false,
    bool? reminderEnabled,
    String? imagePath,
    bool clearImagePath = false,
    List<SubTask>? subTasks,
    DateTime? createdAt,
    DateTime? completedAt,
    bool clearCompletedAt = false,
  }) {
    return CheckItem(
      id: id ?? this.id,
      title: title ?? this.title,
      note: clearNote ? null : note ?? this.note,
      done: done ?? this.done,
      priority: priority ?? this.priority,
      repeatRule: repeatRule ?? this.repeatRule,
      dueAt: clearDueAt ? null : dueAt ?? this.dueAt,
      reminderEnabled: reminderEnabled ?? this.reminderEnabled,
      imagePath: clearImagePath ? null : imagePath ?? this.imagePath,
      subTasks: subTasks ?? this.subTasks,
      createdAt: createdAt ?? this.createdAt,
      completedAt: clearCompletedAt ? null : completedAt ?? this.completedAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'note': note,
      'done': done,
      'priority': priority.id,
      'repeatRule': repeatRule.id,
      'dueAt': dueAt?.toIso8601String(),
      'reminderEnabled': reminderEnabled,
      'imagePath': imagePath,
      'subTasks': subTasks.map((item) => item.toJson()).toList(),
      'createdAt': createdAt.toIso8601String(),
      'completedAt': completedAt?.toIso8601String(),
    };
  }

  factory CheckItem.fromJson(Map<String, dynamic> json) {
    final rawSubTasks = json['subTasks'];
    return CheckItem(
      id: json['id'] as String? ?? _id(),
      title: json['title'] as String? ?? 'آیتم بدون عنوان',
      note: json['note'] as String?,
      done: json['done'] as bool? ?? false,
      priority: itemPriorityFromId(json['priority'] as String?),
      repeatRule: repeatRuleFromId(json['repeatRule'] as String?),
      dueAt: DateTime.tryParse(json['dueAt'] as String? ?? ''),
      reminderEnabled: json['reminderEnabled'] as bool? ?? false,
      imagePath: json['imagePath'] as String?,
      subTasks: rawSubTasks is List
          ? rawSubTasks.whereType<Map>().map((e) => SubTask.fromJson(Map<String, dynamic>.from(e))).toList()
          : <SubTask>[],
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
      completedAt: DateTime.tryParse(json['completedAt'] as String? ?? ''),
    );
  }
}
