import 'package:flutter/material.dart';

import '../models/remote_models.dart';
import '../services/remote_api_client.dart';
import '../services/remote_support_controller.dart';
import '../theme/app_theme.dart';
import '../utils/persian_numbers.dart';
import '../widgets/gradient_background.dart';
import '../widgets/premium_card.dart';
import 'ticket_detail_screen.dart';

class SupportScreen extends StatefulWidget {
  const SupportScreen({super.key});

  @override
  State<SupportScreen> createState() => _SupportScreenState();
}

class _SupportScreenState extends State<SupportScreen> {
  bool _loading = true;
  List<SupportTicket> _tickets = const [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    if (!mounted) return;
    final remote = RemoteSupportScope.of(context);
    setState(() {
      _loading = true;
      _tickets = remote.cachedTickets;
    });

    try {
      await remote.syncPendingNow(forceConnectionCheck: true);
      final tickets = await remote.fetchTickets(refresh: false);
      if (mounted) setState(() => _tickets = tickets);
    } catch (_) {
      // The cached timeline remains usable. Online errors are deliberately not
      // surfaced as a blocking state in this local-first screen.
      if (mounted) setState(() => _tickets = remote.cachedTickets);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _createTicket() async {
    final created = await showModalBottomSheet<SupportTicket>(
      context: context,
      isScrollControlled: true,
      builder: (context) => const _TicketComposer(),
    );
    if (created != null) await _load();
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final remote = RemoteSupportScope.of(context);
    final notices = remote.pendingBroadcasts.where((item) => !item.popup).toList();
    final canWrite = remote.remoteEnabled && !remote.isBlocked;
    return GradientBackground(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('پشتیبانی و پیام‌ها'),
          actions: [
            IconButton(
              onPressed: _loading ? null : _load,
              icon: const Icon(Icons.refresh_rounded),
              tooltip: 'همگام‌سازی',
            ),
          ],
        ),
        floatingActionButton: canWrite
            ? FloatingActionButton.extended(
                onPressed: _createTicket,
                icon: Icon(remote.isOnline ? Icons.add_comment_rounded : Icons.cloud_upload_outlined),
                label: Text(remote.isOnline ? 'درخواست جدید' : 'ثبت برای ارسال'),
              )
            : null,
        body: SafeArea(
          top: false,
          child: RefreshIndicator(
            onRefresh: _load,
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
              children: [
                PremiumCard(
                  child: Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(color: colors.accent.withValues(alpha: 0.16), borderRadius: BorderRadius.circular(16)),
                        child: Icon(remote.isOnline ? Icons.cloud_done_rounded : Icons.cloud_off_rounded, color: colors.accent),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('تاریخچه درخواست‌ها', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 17)),
                          const SizedBox(height: 4),
                          Text(remote.offlineStatusLabel, style: TextStyle(color: colors.muted, fontSize: 12)),
                        ]),
                      ),
                    ],
                  ),
                ),
                if (remote.hasPendingSync) ...[
                  const SizedBox(height: 10),
                  _SyncQueueCard(count: remote.queuedOperationCount),
                ],
                if (notices.isNotEmpty) ...[
                  const SizedBox(height: 14),
                  Text('پیام‌های عمومی', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 17)),
                  const SizedBox(height: 8),
                  ...notices.map(
                    (notice) => Padding(
                      padding: const EdgeInsets.only(bottom: 9),
                      child: PremiumCard(
                        child: Row(children: [
                          Icon(Icons.campaign_rounded, color: colors.accent),
                          const SizedBox(width: 10),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(notice.title, style: TextStyle(color: colors.text, fontWeight: FontWeight.w900)),
                            const SizedBox(height: 4),
                            Text(notice.body, style: TextStyle(color: colors.muted), maxLines: 3, overflow: TextOverflow.ellipsis),
                          ])),
                          IconButton(
                            tooltip: 'خواندم',
                            onPressed: () => remote.acknowledgeBroadcast(notice.id),
                            icon: const Icon(Icons.done_rounded),
                          ),
                        ]),
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 14),
                if (_loading && _tickets.isEmpty)
                  const Padding(padding: EdgeInsets.only(top: 56), child: Center(child: CircularProgressIndicator()))
                else if (_tickets.isEmpty)
                  _StateCard(
                    icon: remote.isOnline ? Icons.mark_email_read_outlined : Icons.forum_outlined,
                    title: 'درخواستی ثبت نشده است',
                    message: remote.isOnline
                        ? 'برای گزارش مشکل یا ارسال پیشنهاد، از دکمهٔ پایین صفحه استفاده کن.'
                        : 'می‌توانی درخواست را همین حالا ثبت کنی؛ بعد از اتصال اینترنت خودکار ارسال می‌شود.',
                    actionLabel: canWrite ? (remote.isOnline ? 'ارسال درخواست' : 'ثبت برای ارسال') : null,
                    onAction: canWrite ? _createTicket : null,
                  )
                else ...[
                  Text('درخواست‌های شما', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 17)),
                  const SizedBox(height: 8),
                  ..._tickets.map(
                    (ticket) => Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: _TicketCard(
                        ticket: ticket,
                        onTap: () async {
                          await Navigator.of(context).push(MaterialPageRoute(builder: (_) => TicketDetailScreen(ticketId: ticket.id)));
                          if (mounted) _load();
                        },
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SyncQueueCard extends StatelessWidget {
  const _SyncQueueCard({required this.count});

  final int count;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final label = count > 0
        ? '${toPersianDigits(count)} مورد در صف همگام‌سازی است و با اتصال اینترنت خودکار ارسال می‌شود.'
        : 'آخرین آمار استفاده پس از اتصال اینترنت همگام‌سازی می‌شود.';
    return PremiumCard(
      child: Row(children: [
        Icon(Icons.sync_rounded, color: colors.warning),
        const SizedBox(width: 10),
        Expanded(child: Text(label, style: TextStyle(color: colors.muted, fontSize: 12, height: 1.5))),
      ]),
    );
  }
}

class _StateCard extends StatelessWidget {
  const _StateCard({required this.icon, required this.title, required this.message, this.actionLabel, this.onAction});

  final IconData icon;
  final String title;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return PremiumCard(
      margin: const EdgeInsets.only(top: 40),
      child: Column(
        children: [
          Icon(icon, size: 58, color: colors.accent),
          const SizedBox(height: 14),
          Text(title, style: TextStyle(color: colors.text, fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text(message, style: TextStyle(color: colors.muted), textAlign: TextAlign.center),
          if (actionLabel != null) ...[
            const SizedBox(height: 16),
            FilledButton(onPressed: onAction, child: Text(actionLabel!)),
          ],
        ],
      ),
    );
  }
}

class _TicketCard extends StatelessWidget {
  const _TicketCard({required this.ticket, required this.onTap});

  final SupportTicket ticket;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final status = switch (ticket.status) {
      'open' => ('در انتظار پاسخ', colors.warning),
      'answered' => ('پاسخ جدید', colors.accent),
      'closed' => ('بسته‌شده', colors.muted),
      _ => ('در حال بررسی', colors.warning),
    };
    final syncText = switch (ticket.syncState) {
      TicketSyncState.pending => 'در صف ارسال',
      TicketSyncState.failed => 'نیازمند همگام‌سازی',
      TicketSyncState.synced => null,
    };
    return PremiumCard(
      onTap: onTap,
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(color: status.$2.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(15)),
            child: Icon(ticket.isClosed ? Icons.task_alt_rounded : Icons.forum_rounded, color: status.$2),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(ticket.subject, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: colors.text, fontWeight: FontWeight.w900)),
              if (ticket.lastMessage != null && ticket.lastMessage!.trim().isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(ticket.lastMessage!, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: colors.muted, fontSize: 12)),
              ],
              const SizedBox(height: 7),
              Wrap(spacing: 6, runSpacing: 4, children: [
                Text('${status.$1} • ${formatDateTimeCompactFa(ticket.updatedAt)}', style: TextStyle(color: status.$2, fontSize: 11, fontWeight: FontWeight.w800)),
                if (syncText != null) Text(syncText, style: TextStyle(color: colors.warning, fontSize: 11, fontWeight: FontWeight.w800)),
              ]),
            ]),
          ),
          Icon(Icons.chevron_left_rounded, color: colors.muted),
        ],
      ),
    );
  }
}

class _TicketComposer extends StatefulWidget {
  const _TicketComposer();

  @override
  State<_TicketComposer> createState() => _TicketComposerState();
}

class _TicketComposerState extends State<_TicketComposer> {
  final _subject = TextEditingController();
  final _message = TextEditingController();
  bool _saving = false;

  @override
  void dispose() {
    _subject.dispose();
    _message.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final subject = _subject.text.trim();
    final message = _message.text.trim();
    if (subject.length < 3 || message.length < 3) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('عنوان و متن درخواست را کامل وارد کن.')));
      return;
    }
    setState(() => _saving = true);
    try {
      final ticket = await RemoteSupportScope.of(context).createTicket(subject: subject, message: message);
      if (!mounted) return;
      Navigator.pop(context, ticket);
    } on RemoteApiException catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.message)));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    final remote = RemoteSupportScope.of(context);
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, bottom + 16),
      child: Material(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('ارسال درخواست جدید', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
            const SizedBox(height: 6),
            Text(
              remote.isOnline ? 'درخواست پس از ثبت به سرویس پشتیبانی ارسال می‌شود.' : 'اینترنت لازم نیست؛ درخواست روی گوشی ذخیره و پس از اتصال ارسال می‌شود.',
              style: TextStyle(color: context.appColors.muted, fontSize: 12),
            ),
            const SizedBox(height: 14),
            TextField(controller: _subject, maxLength: 120, decoration: const InputDecoration(labelText: 'عنوان درخواست', counterText: '')),
            const SizedBox(height: 10),
            TextField(controller: _message, maxLines: 5, minLines: 4, maxLength: 3000, decoration: const InputDecoration(labelText: 'شرح درخواست', alignLabelWithHint: true, counterText: '')),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _saving ? null : _submit,
                icon: _saving ? const SizedBox.square(dimension: 18, child: CircularProgressIndicator(strokeWidth: 2)) : Icon(remote.isOnline ? Icons.send_rounded : Icons.cloud_upload_outlined),
                label: Text(_saving ? 'در حال ذخیره...' : remote.isOnline ? 'ثبت و ارسال درخواست' : 'ثبت برای ارسال بعدی'),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
