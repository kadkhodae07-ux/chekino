import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/data_controller.dart';
import '../services/reminder_service.dart';
import '../services/remote_support_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/ad_widgets.dart';
import 'checklist_detail_screen.dart';
import 'list_overview_screen.dart';
import 'settings_screen.dart';
import 'stats_screen.dart';
import 'templates_screen.dart';
import 'today_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> with WidgetsBindingObserver {
  int _index = 0;
  bool _presentingRemoteMessage = false;
  bool _blockedNoticeShown = false;
  final _pages = const [TodayScreen(), ListOverviewScreen(), TemplatesScreen(), StatsScreen(), SettingsScreen()];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      ReminderService.instance.setNotificationTapHandler(_openNotificationPayload);
      showOpenInterstitialAd(context);
      _syncRemoteAndPresent();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _syncRemoteAndPresent();
  }

  Future<void> _syncRemoteAndPresent() async {
    if (!mounted) return;
    final remote = RemoteSupportScope.of(context);
    await remote.syncWithData(
      dataController: CheckinoDataScope.of(context),
      monetizationController: MonetizationScope.of(context),
    );
    if (!mounted) return;
    await _showRemoteMessages(remote);
  }

  Future<void> _showRemoteMessages(RemoteSupportController remote) async {
    if (_presentingRemoteMessage || !mounted) return;
    _presentingRemoteMessage = true;
    try {
      if (remote.isBlocked && !_blockedNoticeShown) {
        _blockedNoticeShown = true;
        if (!context.mounted) return;
        await showDialog<void>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: const Text('دسترسی آنلاین غیرفعال است'),
            content: Text(
              remote.profile?.blockReason?.trim().isNotEmpty == true
                  ? remote.profile!.blockReason!
                  : 'استفاده از چک‌لیست‌های ذخیره‌شده روی دستگاه ادامه دارد، اما ارسال درخواست آنلاین در دسترس نیست.',
            ),
            actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('متوجه شدم'))],
          ),
        );
        if (!mounted) return;
      }

      while (mounted) {
        final next = remote.pendingBroadcasts.where((item) => item.popup).firstOrNull;
        if (next == null) break;
        if (!mounted) break;
        await showDialog<void>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: Text(next.title),
            content: SingleChildScrollView(child: Text(next.body)),
            actions: [FilledButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('متوجه شدم'))],
          ),
        );
        if (!mounted) break;
        await remote.acknowledgeBroadcast(next.id);
      }
    } finally {
      _presentingRemoteMessage = false;
    }
  }

  void _openNotificationPayload(String payload) {
    if (!mounted) return;
    final parts = payload.split(':');
    if (parts.isEmpty || (parts.first != 'list' && parts.first != 'item') || parts.length < 2) return;
    final listId = parts[1];
    setState(() => _index = 0);
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChecklistDetailScreen(listId: listId)));
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        final shouldExit = await showExitDialogWithAd(context);
        if (shouldExit) SystemNavigator.pop();
      },
      child: Scaffold(
        body: IndexedStack(index: _index, children: _pages),
        bottomNavigationBar: Container(
          decoration: BoxDecoration(border: Border(top: BorderSide(color: colors.border)), color: colors.card),
          child: SafeArea(
            top: false,
            child: BottomNavigationBar(
              currentIndex: _index,
              type: BottomNavigationBarType.fixed,
              onTap: (value) => setState(() => _index = value),
              items: const [
                BottomNavigationBarItem(icon: Icon(Icons.today_rounded), label: 'امروز'),
                BottomNavigationBarItem(icon: Icon(Icons.checklist_rounded), label: 'لیست‌ها'),
                BottomNavigationBarItem(icon: Icon(Icons.dashboard_customize_rounded), label: 'قالب‌ها'),
                BottomNavigationBarItem(icon: Icon(Icons.bar_chart_rounded), label: 'آمار'),
                BottomNavigationBarItem(icon: Icon(Icons.settings_rounded), label: 'تنظیمات'),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

extension _IterableFirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
