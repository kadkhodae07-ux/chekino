import 'package:flutter/material.dart';

import '../models/remote_models.dart';
import '../services/remote_api_client.dart';
import '../services/remote_support_controller.dart';
import '../theme/app_theme.dart';
import '../utils/persian_numbers.dart';
import '../widgets/gradient_background.dart';

class TicketDetailScreen extends StatefulWidget {
  const TicketDetailScreen({super.key, required this.ticketId, this.adminMode = false});

  final String ticketId;
  final bool adminMode;

  @override
  State<TicketDetailScreen> createState() => _TicketDetailScreenState();
}

class _TicketDetailScreenState extends State<TicketDetailScreen> {
  final _reply = TextEditingController();
  SupportTicket? _ticket;
  bool _loading = true;
  bool _sending = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  @override
  void dispose() {
    _reply.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final remote = RemoteSupportScope.of(context);
      final ticket = widget.adminMode ? await remote.fetchAdminTicket(widget.ticketId) : await remote.fetchTicket(widget.ticketId);
      if (!mounted) return;
      setState(() => _ticket = ticket);
    } on RemoteApiException catch (error) {
      if (!mounted) return;
      setState(() => _error = error.message);
    } catch (_) {
      if (!mounted) return;
      setState(() => _error = 'دریافت گفتگو ناموفق بود.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _send() async {
    final message = _reply.text.trim();
    final ticket = _ticket;
    if (ticket == null || message.length < 2) return;
    setState(() => _sending = true);
    try {
      final remote = RemoteSupportScope.of(context);
      final updated = widget.adminMode
          ? await remote.replyAdminTicket(ticketId: ticket.id, message: message)
          : await remote.replyToTicket(ticketId: ticket.id, message: message);
      if (!mounted) return;
      _reply.clear();
      setState(() => _ticket = updated);
      if (!widget.adminMode && updated.hasPendingSync) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('پاسخ روی گوشی ثبت شد و پس از اتصال اینترنت ارسال می‌شود.')),
        );
      }
    } on RemoteApiException catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.message)));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _setStatus(String status) async {
    final ticket = _ticket;
    if (ticket == null || !widget.adminMode) return;
    setState(() => _sending = true);
    try {
      await RemoteSupportScope.of(context).setAdminTicketStatus(ticketId: ticket.id, status: status);
      if (!mounted) return;
      await _load();
    } on RemoteApiException catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.message)));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final ticket = _ticket;
    return GradientBackground(
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.adminMode ? 'مدیریت تیکت' : 'جزئیات درخواست'),
          actions: [
            if (!widget.adminMode)
              Icon(
                RemoteSupportScope.of(context).isOnline ? Icons.cloud_done_rounded : Icons.cloud_off_rounded,
                color: RemoteSupportScope.of(context).isOnline ? colors.success : colors.muted,
              ),
            const SizedBox(width: 6),
            IconButton(onPressed: _loading ? null : _load, icon: const Icon(Icons.refresh_rounded), tooltip: 'همگام‌سازی'),
            if (widget.adminMode && ticket != null)
              PopupMenuButton<String>(
                onSelected: _setStatus,
                itemBuilder: (context) => const [
                  PopupMenuItem(value: 'open', child: Text('بازگشایی')),
                  PopupMenuItem(value: 'answered', child: Text('در حال پیگیری')),
                  PopupMenuItem(value: 'closed', child: Text('بستن تیکت')),
                ],
              ),
          ],
        ),
        body: SafeArea(
          top: false,
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _error != null
                  ? Center(child: Padding(padding: const EdgeInsets.all(28), child: Text(_error!, textAlign: TextAlign.center)))
                  : ticket == null
                      ? const SizedBox.shrink()
                      : Column(
                          children: [
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.fromLTRB(18, 8, 18, 12),
                              decoration: BoxDecoration(color: colors.card.withValues(alpha: 0.88), border: Border(bottom: BorderSide(color: colors.border))),
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(ticket.subject, style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 18)),
                                const SizedBox(height: 5),
                                Text(
                                  '${_statusTitle(ticket.status)} • ${formatDateTimeCompactFa(ticket.updatedAt)}',
                                  style: TextStyle(color: _statusColor(ticket.status, colors), fontWeight: FontWeight.w800, fontSize: 12),
                                ),
                                if (!widget.adminMode && ticket.hasPendingSync) ...[
                                  const SizedBox(height: 5),
                                  Text('برخی پیام‌ها هنوز در صف ارسال هستند.', style: TextStyle(color: colors.warning, fontWeight: FontWeight.w800, fontSize: 11)),
                                ],
                              ]),
                            ),
                            Expanded(
                              child: ListView.builder(
                                padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
                                itemCount: ticket.messages.length,
                                itemBuilder: (context, index) => _MessageBubble(message: ticket.messages[index], adminMode: widget.adminMode),
                              ),
                            ),
                            if (!ticket.isClosed || widget.adminMode)
                              SafeArea(
                                top: false,
                                child: Container(
                                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
                                  decoration: BoxDecoration(color: colors.card, border: Border(top: BorderSide(color: colors.border))),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: TextField(
                                          controller: _reply,
                                          minLines: 1,
                                          maxLines: 4,
                                          maxLength: 3000,
                                          decoration: InputDecoration(
                                            labelText: widget.adminMode ? 'پاسخ پشتیبانی' : 'نوشتن پاسخ',
                                            counterText: '',
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      IconButton.filled(
                                        onPressed: _sending ? null : _send,
                                        icon: _sending ? const SizedBox.square(dimension: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.send_rounded),
                                      ),
                                    ],
                                  ),
                                ),
                              )
                            else
                              Container(
                                width: double.infinity,
                                padding: const EdgeInsets.all(16),
                                color: colors.card,
                                child: Text('این درخواست بسته شده است.', textAlign: TextAlign.center, style: TextStyle(color: colors.muted)),
                              ),
                          ],
                        ),
        ),
      ),
    );
  }

  String _statusTitle(String status) {
    return switch (status) {
      'open' => 'در انتظار پاسخ',
      'answered' => 'پاسخ داده شد',
      'closed' => 'بسته‌شده',
      _ => 'در حال بررسی',
    };
  }

  Color _statusColor(String status, AppThemeColors colors) {
    return switch (status) {
      'open' => colors.warning,
      'answered' => colors.accent,
      'closed' => colors.muted,
      _ => colors.warning,
    };
  }
}

class _MessageBubble extends StatelessWidget {
  const _MessageBubble({required this.message, required this.adminMode});

  final SupportTicketMessage message;
  final bool adminMode;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final mine = adminMode ? !message.fromUser : message.fromUser;
    final label = message.fromUser ? 'کاربر' : 'پشتیبانی';
    final background = mine ? colors.accent.withValues(alpha: 0.16) : colors.card;
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 330),
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
          decoration: BoxDecoration(
            color: background,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: mine ? colors.accent.withValues(alpha: 0.28) : colors.border),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: TextStyle(color: mine ? colors.accent : colors.muted, fontWeight: FontWeight.w900, fontSize: 11)),
            const SizedBox(height: 5),
            Text(message.body, style: TextStyle(color: colors.text, height: 1.5)),
            const SizedBox(height: 6),
            Wrap(spacing: 5, children: [
              Text(formatDateTimeCompactFa(message.createdAt), style: TextStyle(color: colors.muted, fontSize: 10)),
              if (message.pending) Text('در صف ارسال', style: TextStyle(color: colors.warning, fontSize: 10, fontWeight: FontWeight.w800)),
            ]),
          ]),
        ),
      ),
    );
  }
}
