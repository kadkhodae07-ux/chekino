import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../models/check_item.dart';
import '../models/check_list.dart';
import '../services/data_controller.dart';
import '../theme/app_theme.dart';
import '../utils/persian_numbers.dart';

Future<DateTime?> pickDateTime(BuildContext context, DateTime? initial) async {
  final base = initial ?? DateTime.now().add(const Duration(hours: 1));
  final date = await _showJalaliDatePicker(context, base);
  if (date == null || !context.mounted) return null;
  final time = await showTimePicker(
    context: context,
    initialTime: TimeOfDay.fromDateTime(base),
    builder: (context, child) => Directionality(
      textDirection: TextDirection.rtl,
      child: MediaQuery(data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true), child: child ?? const SizedBox.shrink()),
    ),
  );
  if (time == null) return null;
  return jalaliToGregorian(date.year, date.month, date.day, hour: time.hour, minute: time.minute);
}

Future<JalaliDate?> _showJalaliDatePicker(BuildContext context, DateTime initial) async {
  final initialJalali = gregorianToJalali(initial);
  final currentJalali = gregorianToJalali(DateTime.now());
  var year = initialJalali.year;
  var month = initialJalali.month;
  var day = initialJalali.day;
  final years = List<int>.generate(8, (index) => currentJalali.year - 1 + index);

  return showModalBottomSheet<JalaliDate>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) {
      final colors = context.appColors;
      return StatefulBuilder(
        builder: (context, setSheetState) {
          final maxDay = jalaliMonthLength(year, month);
          if (day > maxDay) day = maxDay;
          return SafeArea(
            child: Container(
              margin: const EdgeInsets.all(12),
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: colors.card,
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: colors.border),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('انتخاب تاریخ شمسی', style: TextStyle(color: colors.text, fontSize: 20, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 10),
                  Text('تاریخ انتخابی: ${toPersianDigits(day)} ${jalaliMonthNames[month - 1]} ${toPersianDigits(year)}', style: TextStyle(color: colors.accent, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: DropdownButtonFormField<int>(
                          key: ValueKey('jalali-year-$year'),
                          initialValue: year,
                          decoration: const InputDecoration(labelText: 'سال'),
                          items: years.map((value) => DropdownMenuItem(value: value, child: Text(toPersianDigits(value)))).toList(),
                          onChanged: (value) => setSheetState(() => year = value ?? year),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: DropdownButtonFormField<int>(
                          key: ValueKey('jalali-month-$month'),
                          initialValue: month,
                          decoration: const InputDecoration(labelText: 'ماه'),
                          items: List<int>.generate(12, (index) => index + 1)
                              .map((value) => DropdownMenuItem(value: value, child: Text(jalaliMonthNames[value - 1])))
                              .toList(),
                          onChanged: (value) => setSheetState(() => month = value ?? month),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<int>(
                    key: ValueKey('jalali-day-$year-$month-$day'),
                    initialValue: day,
                    decoration: const InputDecoration(labelText: 'روز'),
                    items: List<int>.generate(maxDay, (index) => index + 1)
                        .map((value) => DropdownMenuItem(value: value, child: Text(toPersianDigits(value))))
                        .toList(),
                    onChanged: (value) => setSheetState(() => day = value ?? day),
                  ),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('لغو'))),
                      const SizedBox(width: 10),
                      Expanded(child: FilledButton(onPressed: () => Navigator.pop(context, JalaliDate(year, month, day)), child: const Text('تأیید تاریخ'))),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}

Future<CheckListModel?> showListEditor(BuildContext context, {CheckListModel? list}) async {
  final title = TextEditingController(text: list?.title ?? '');
  DateTime? dueAt = list?.dueAt;
  ReminderLeadTime leadTime = list?.reminderLeadTime ?? ReminderLeadTime.none;
  int iconCodePoint = list?.iconCodePoint ?? Icons.folder_rounded.codePoint;
  int? colorValue = list?.colorValue;
  final iconOptions = [Icons.folder_rounded, Icons.today, Icons.flight_takeoff, Icons.shopping_cart, Icons.school, Icons.work, Icons.home, Icons.fitness_center, Icons.favorite, Icons.star];
  final colorOptions = [null, 0xFFFF70B8, 0xFF22C55E, 0xFF9D4EDD, 0xFF38BDF8, 0xFFF59E0B, 0xFFEF4444];

  return showModalBottomSheet<CheckListModel>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) {
      final colors = context.appColors;
      return StatefulBuilder(
        builder: (context, setSheetState) {
          return SafeArea(
            child: Container(
              margin: const EdgeInsets.all(12),
              padding: EdgeInsets.only(left: 18, right: 18, top: 18, bottom: MediaQuery.of(context).viewInsets.bottom + 18),
              decoration: BoxDecoration(color: colors.card, borderRadius: BorderRadius.circular(30), border: Border.all(color: colors.border)),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(list == null ? 'پوشه جدید' : 'ویرایش پوشه', style: TextStyle(color: colors.text, fontSize: 20, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 16),
                    TextField(controller: title, autofocus: true, decoration: const InputDecoration(labelText: 'نام پوشه')),
                    const SizedBox(height: 14),
                    Text('آیکن پوشه', style: TextStyle(color: colors.muted, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: iconOptions.map((icon) {
                        final selected = icon.codePoint == iconCodePoint;
                        return ChoiceChip(
                          selected: selected,
                          label: Icon(icon, color: selected ? colors.accent : colors.muted),
                          onSelected: (_) => setSheetState(() => iconCodePoint = icon.codePoint),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 14),
                    Text('رنگ اختصاصی', style: TextStyle(color: colors.muted, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: colorOptions.map((value) {
                        final selected = value == colorValue;
                        return InkWell(
                          borderRadius: BorderRadius.circular(20),
                          onTap: () => setSheetState(() => colorValue = value),
                          child: Container(
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: value == null ? colors.cardAlt : Color(value),
                              border: Border.all(color: selected ? colors.text : colors.border, width: selected ? 2 : 1),
                            ),
                            child: value == null ? Icon(Icons.auto_awesome, size: 18, color: colors.muted) : null,
                          ),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 14),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text('موعد پوشه', style: TextStyle(color: colors.text, fontWeight: FontWeight.w800)),
                      subtitle: Text(formatDateTimeFa(dueAt), style: TextStyle(color: colors.muted)),
                      trailing: Icon(Icons.calendar_month, color: colors.accent),
                      onTap: () async {
                        final picked = await pickDateTime(context, dueAt);
                        if (picked != null) {
                          setSheetState(() {
                            dueAt = picked;
                            if (leadTime == ReminderLeadTime.none) {
                              leadTime = ReminderLeadTime.atDueTime;
                            }
                          });
                        }
                      },
                    ),
                    DropdownButtonFormField<ReminderLeadTime>(
                      key: ValueKey('list-reminder-$leadTime'),
                      initialValue: leadTime,
                      decoration: const InputDecoration(labelText: 'یادآور'),
                      items: ReminderLeadTime.values.map((item) => DropdownMenuItem(value: item, child: Text(item.title))).toList(),
                      onChanged: (value) => setSheetState(() => leadTime = value ?? ReminderLeadTime.none),
                    ),
                    const SizedBox(height: 18),
                    Row(
                      children: [
                        Expanded(
                          child: FilledButton(
                            onPressed: () {
                              if (title.text.trim().isEmpty) return;
                              if (leadTime != ReminderLeadTime.none && dueAt == null) {
                                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('برای فعال‌کردن یادآور، اول موعد پوشه را انتخاب کن')));
                                return;
                              }
                              Navigator.pop(
                                context,
                                CheckListModel(
                                  id: list?.id ?? makeId(),
                                  title: title.text.trim(),
                                  items: list?.items ?? [],
                                  createdAt: list?.createdAt,
                                  dueAt: dueAt,
                                  reminderLeadTime: leadTime,
                                  archived: list?.archived ?? false,
                                  pinned: list?.pinned ?? false,
                                  sortOrder: list?.sortOrder ?? 0,
                                  iconCodePoint: iconCodePoint,
                                  colorValue: colorValue,
                                ),
                              );
                            },
                            child: const Text('ذخیره'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      );
    },
  );
}

Future<CheckItem?> showItemEditor(BuildContext context, {CheckItem? item}) async {
  final title = TextEditingController(text: item?.title ?? '');
  final note = TextEditingController(text: item?.note ?? '');
  DateTime? dueAt = item?.dueAt;
  ItemPriority priority = item?.priority ?? ItemPriority.normal;
  RepeatRule repeatRule = item?.repeatRule ?? RepeatRule.none;
  String? imagePath = item?.imagePath;
  bool reminderEnabled = item?.reminderEnabled ?? false;

  return showModalBottomSheet<CheckItem>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) {
      final colors = context.appColors;
      return StatefulBuilder(
        builder: (context, setSheetState) {
          return SafeArea(
            child: Container(
              margin: const EdgeInsets.all(12),
              padding: EdgeInsets.only(left: 18, right: 18, top: 18, bottom: MediaQuery.of(context).viewInsets.bottom + 18),
              decoration: BoxDecoration(color: colors.card, borderRadius: BorderRadius.circular(30), border: Border.all(color: colors.border)),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item == null ? 'آیتم جدید' : 'ویرایش آیتم', style: TextStyle(color: colors.text, fontSize: 20, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 16),
                    TextField(controller: title, autofocus: true, decoration: const InputDecoration(labelText: 'عنوان آیتم')),
                    const SizedBox(height: 12),
                    TextField(controller: note, minLines: 2, maxLines: 4, decoration: const InputDecoration(labelText: 'یادداشت')),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: DropdownButtonFormField<ItemPriority>(
                            key: ValueKey('item-priority-$priority'),
                            initialValue: priority,
                            decoration: const InputDecoration(labelText: 'اولویت'),
                            items: ItemPriority.values.map((p) => DropdownMenuItem(value: p, child: Text(p.title))).toList(),
                            onChanged: (value) => setSheetState(() => priority = value ?? ItemPriority.normal),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: DropdownButtonFormField<RepeatRule>(
                            key: ValueKey('item-repeat-$repeatRule'),
                            initialValue: repeatRule,
                            decoration: const InputDecoration(labelText: 'تکرار'),
                            items: RepeatRule.values.map((r) => DropdownMenuItem(value: r, child: Text(r.title))).toList(),
                            onChanged: (value) => setSheetState(() => repeatRule = value ?? RepeatRule.none),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text('تاریخ و ساعت آیتم', style: TextStyle(color: colors.text, fontWeight: FontWeight.w800)),
                      subtitle: Text(formatDateTimeFa(dueAt), style: TextStyle(color: colors.muted)),
                      trailing: Icon(Icons.event_available, color: colors.accent),
                      onTap: () async {
                        final picked = await pickDateTime(context, dueAt);
                        if (picked != null) setSheetState(() => dueAt = picked);
                      },
                    ),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('یادآور در زمان آیتم'),
                      subtitle: Text(
                        dueAt == null ? 'ابتدا تاریخ و ساعت آیتم را انتخاب کن.' : 'در همان تاریخ و ساعت، یادآور خصوصی ثبت می‌شود.',
                        style: TextStyle(color: colors.muted, fontSize: 12),
                      ),
                      value: reminderEnabled,
                      onChanged: (value) {
                        if (value && dueAt == null) {
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('برای فعال‌کردن یادآور، ابتدا تاریخ آیتم را انتخاب کن.')));
                          return;
                        }
                        setSheetState(() => reminderEnabled = value);
                      },
                    ),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text('پیوست عکس', style: TextStyle(color: colors.text, fontWeight: FontWeight.w800)),
                      subtitle: Text(imagePath == null ? 'عکسی انتخاب نشده' : 'عکس انتخاب شد', style: TextStyle(color: colors.muted)),
                      trailing: Icon(Icons.image, color: colors.accent),
                      onTap: () async {
                        final picker = ImagePicker();
                        final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 82);
                        if (picked != null) setSheetState(() => imagePath = picked.path);
                      },
                    ),
                    const SizedBox(height: 16),
                    FilledButton(
                      onPressed: () async {
                        if (title.text.trim().isEmpty) return;
                        if (reminderEnabled && dueAt == null) {
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('برای فعال‌کردن یادآور، ابتدا تاریخ آیتم را انتخاب کن.')));
                          return;
                        }
                        var persistedImagePath = imagePath;
                        if (imagePath != null && imagePath != item?.imagePath) {
                          persistedImagePath = await CheckinoDataScope.of(context).persistImage(imagePath!) ?? item?.imagePath;
                        }
                        if (!context.mounted) return;
                        Navigator.pop(
                          context,
                          CheckItem(
                            id: item?.id ?? makeId(),
                            title: title.text.trim(),
                            note: note.text.trim().isEmpty ? null : note.text.trim(),
                            done: item?.done ?? false,
                            priority: priority,
                            repeatRule: repeatRule,
                            dueAt: dueAt,
                            reminderEnabled: reminderEnabled,
                            imagePath: persistedImagePath,
                            subTasks: item?.subTasks ?? [],
                            createdAt: item?.createdAt,
                            completedAt: item?.completedAt,
                          ),
                        );
                      },
                      child: const SizedBox(width: double.infinity, child: Center(child: Text('ذخیره آیتم'))),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      );
    },
  );
}
