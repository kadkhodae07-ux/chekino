import 'dart:async';

import 'package:flutter/material.dart';

import '../config/app_environment.dart';
import '../config/store_environment.dart';
import '../services/bazaar_billing_service.dart';
import '../services/myket_billing_service.dart';
import '../services/data_controller.dart';
import '../services/reminder_service.dart';
import '../services/remote_support_controller.dart';
import '../services/remote_api_client.dart';
import '../services/theme_settings_controller.dart';
import '../theme/app_theme.dart';
import '../utils/persian_numbers.dart';
import '../widgets/ad_widgets.dart';
import '../widgets/gradient_background.dart';
import '../widgets/premium_card.dart';
import 'special_access_login_screen.dart';
import 'support_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final TextEditingController _pinController = TextEditingController();
  bool _pinInitialized = false;
  int _specialTapCount = 0;
  DateTime? _lastSpecialTap;
  bool _billingBusy = false;
  String? _billingProgress;

  @override
  void dispose() {
    _pinController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final data = CheckinoDataScope.of(context);
    final theme = CheckinoSettings.of(context);
    final remote = RemoteSupportScope.of(context);
    final monetization = MonetizationScope.of(context);
    final isPro = monetization.isPro;
    final proUntil = monetization.settings.remoteProUntil;
    final colors = context.appColors;
    if (!_pinInitialized) {
      _pinController.text = data.lockSettings.pin;
      _pinInitialized = true;
    }

    return GradientBackground(
      child: Scaffold(
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('تنظیمات', style: TextStyle(color: colors.text, fontSize: 28, fontWeight: FontWeight.w900)),
              const SizedBox(height: 18),
              PremiumCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(color: colors.accent.withValues(alpha: 0.16), borderRadius: BorderRadius.circular(16)),
                      child: Icon(isPro ? Icons.workspace_premium_rounded : Icons.campaign_rounded, color: colors.accent),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        isPro ? 'حساب Pro چکینو' : 'نسخه رایگان چکینو',
                        style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 18),
                      ),
                    ),
                  ]),
                  const SizedBox(height: 10),
                  Text(
                    isPro
                        ? _subscriptionDescription(
                            proUntil: proUntil,
                            source: monetization.subscriptionSource,
                            inOfflineGrace: monetization.isWithinOfflineGrace,
                          )
                        : 'نسخه رایگان با تبلیغات اختیاری کار می‌کند. برای فعال‌شدن اشتراک ماهانه، خرید در برنامه ${StoreEnvironment.label} و تأیید اینترنتی لازم است؛ استفاده از چک‌لیست‌ها همچنان کاملاً آفلاین است.',
                    style: TextStyle(color: colors.muted),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      FilledButton.icon(
                        onPressed: _billingBusy || isPro ? null : () => _buyMonthlySubscription(remote),
                        icon: _billingBusy
                            ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Icon(Icons.workspace_premium_rounded),
                        label: Text(isPro ? 'اشتراک فعال است' : 'خرید اشتراک ماهانه'),
                      ),
                      OutlinedButton.icon(
                        onPressed: _billingBusy ? null : () => _restoreMonthlySubscription(remote),
                        icon: const Icon(Icons.restore_rounded),
                        label: Text('بازیابی خرید ${StoreEnvironment.label}'),
                      ),
                      OutlinedButton.icon(
                        onPressed: _billingBusy ? null : _checkStoreConnection,
                        icon: const Icon(Icons.wifi_tethering_rounded),
                        label: Text('بررسی اتصال ${StoreEnvironment.label}'),
                      ),
                    ],
                  ),
                  if (_billingBusy) ...[
                    const SizedBox(height: 10),
                    Row(children: [
                      const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _billingProgress ?? 'در حال آماده‌سازی خرید...',
                          style: TextStyle(color: colors.accent, fontSize: 12, fontWeight: FontWeight.w800),
                        ),
                      ),
                    ]),
                  ],
                  const SizedBox(height: 8),
                  Text(
                    'محصول ${StoreEnvironment.label}: اشتراک ماهانه چکینو Pro با شناسه ${StoreEnvironment.monthlyProductId}. اگر صفحه پرداخت باز نشد، ابتدا «بررسی اتصال ${StoreEnvironment.label}» را بزن؛ نتیجه مشخص می‌کند اتصال یا فعال‌بودن محصول مشکل دارد.',
                    style: TextStyle(color: colors.mutedDark, fontSize: 11),
                  ),
                ]),
              ),
              const SizedBox(height: 14),
              const AdBannerSlot(placement: 'settings_banner'),
              const SizedBox(height: 14),
              PremiumCard(
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SupportScreen())),
                child: Row(children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(color: colors.accent.withValues(alpha: 0.16), borderRadius: BorderRadius.circular(16)),
                    child: Icon(Icons.forum_rounded, color: colors.accent),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('پشتیبانی و پیام‌ها', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 17)),
                    const SizedBox(height: 4),
                    Text(
                      remote.unreadTicketCount > 0
                          ? '${toPersianDigits(remote.unreadTicketCount)} پاسخ یا پیام جدید داری.'
                          : 'ارسال درخواست و مشاهده تاریخچه پاسخ‌ها.',
                      style: TextStyle(color: remote.unreadTicketCount > 0 ? colors.accent : colors.muted, fontSize: 12),
                    ),
                  ])),
                  Icon(Icons.chevron_left_rounded, color: colors.muted),
                ]),
              ),
              const SizedBox(height: 14),
              PremiumCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('ظاهر برنامه', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 18)),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: CheckinoAppearance.values
                        .map((item) => ChoiceChip(selected: theme.settings.appearance == item, label: Text(item.title), onSelected: (_) => theme.setAppearance(item)))
                        .toList(),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: CheckinoAccent.values
                        .map((item) => ChoiceChip(
                              selected: theme.settings.accent == item,
                              label: Text(item.title),
                              avatar: CircleAvatar(backgroundColor: item.color),
                              onSelected: (_) => theme.setAccent(item),
                            ))
                        .toList(),
                  ),
                ]),
              ),
              const SizedBox(height: 14),
              PremiumCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('قفل برنامه', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 18)),
                  const SizedBox(height: 6),
                  Text('رمز در Android Keystore / iOS Keychain ذخیره می‌شود و به‌صورت متن ساده داخل تنظیمات برنامه نیست.', style: TextStyle(color: colors.muted, fontSize: 12)),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _pinController,
                    keyboardType: TextInputType.number,
                    obscureText: true,
                    maxLength: 12,
                    decoration: const InputDecoration(labelText: 'PIN چهار تا دوازده رقمی', counterText: ''),
                  ),
                  const SizedBox(height: 8),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('فعال‌سازی قفل'),
                    value: data.lockSettings.enabled,
                    onChanged: (value) => _setLockEnabled(data, value),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('اثر انگشت / تشخیص هویت دستگاه'),
                    value: data.lockSettings.biometricEnabled,
                    onChanged: (value) => _saveLock(data, biometricEnabled: value),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('قفل خودکار بعد از خروج از برنامه'),
                    subtitle: const Text('پس از رفتن به پس‌زمینه، برای ورود دوباره رمز لازم است.'),
                    value: data.lockSettings.autoLockOnBackground,
                    onChanged: (value) => _saveLock(data, autoLockOnBackground: value),
                  ),
                  FilledButton(onPressed: () => _saveLock(data), child: const Text('ذخیره تنظیمات قفل')),
                ]),
              ),
              const SizedBox(height: 14),
              PremiumCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('بکاپ و بازیابی', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 18)),
                  const SizedBox(height: 8),
                  Text('بکاپ کامل ZIP شامل چک‌لیست‌ها، قالب‌های شخصی و عکس‌های پیوست است. قبل از جایگزینی، تعداد داده‌های فایل نمایش داده می‌شود.', style: TextStyle(color: colors.muted)),
                  const SizedBox(height: 12),
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    FilledButton.icon(onPressed: () => _shareBackup(data), icon: const Icon(Icons.ios_share), label: const Text('بکاپ کامل')),
                    OutlinedButton.icon(onPressed: () => _pickAndRestore(data), icon: const Icon(Icons.restore), label: const Text('بازیابی فایل')),
                    OutlinedButton.icon(
                      onPressed: () async {
                        await data.copyBackupToClipboard();
                        if (!context.mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('JSON بکاپ برای استفاده فنی کپی شد')));
                      },
                      icon: const Icon(Icons.copy),
                      label: const Text('کپی JSON'),
                    ),
                  ]),
                ]),
              ),
              const SizedBox(height: 14),
              PremiumCard(
                child: FutureBuilder<ReminderPermissionStatus>(
                  future: ReminderService.instance.status(),
                  builder: (context, snapshot) {
                    final status = snapshot.data;
                    final enabled = status?.notificationsEnabled;
                    final statusText = enabled == true
                        ? 'نوتیفیکیشن فعال است'
                        : enabled == false
                            ? 'نوتیفیکیشن نیاز به اجازه دارد'
                            : 'وضعیت نوتیفیکیشن در حال بررسی است';
                    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('یادآورها و نوتیفیکیشن', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 18)),
                      const SizedBox(height: 8),
                      Text(statusText, style: TextStyle(color: enabled == false ? colors.danger : colors.muted, fontWeight: FontWeight.w800)),
                      if (status != null) ...[
                        const SizedBox(height: 6),
                        Text('یادآورهای ثبت‌شده: ${toPersianDigits(status.pendingCount)}', style: TextStyle(color: colors.muted)),
                      ],
                      const SizedBox(height: 12),
                      Wrap(spacing: 8, runSpacing: 8, children: [
                        FilledButton.icon(
                          onPressed: () async {
                            await ReminderService.instance.requestPermissions();
                            if (mounted) setState(() {});
                          },
                          icon: const Icon(Icons.notifications_active),
                          label: const Text('فعال‌سازی دسترسی'),
                        ),
                        OutlinedButton.icon(
                          onPressed: () async {
                            await ReminderService.instance.showTestNotification();
                            if (!context.mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('نوتیفیکیشن آزمایشی ارسال شد')));
                          },
                          icon: const Icon(Icons.notification_add),
                          label: const Text('تست فوری'),
                        ),
                        OutlinedButton.icon(
                          onPressed: () async {
                            await ReminderService.instance.syncLists(data.activeLists);
                            if (mounted) setState(() {});
                          },
                          icon: const Icon(Icons.sync),
                          label: const Text('همگام‌سازی یادآورها'),
                        ),
                      ]),
                      const SizedBox(height: 10),
                      ...ReminderService.instance.debugLinesForLists(data.activeLists).map(
                            (line) => Padding(
                              padding: const EdgeInsets.only(bottom: 4),
                              child: Text(line, style: TextStyle(color: colors.muted, fontSize: 12)),
                            ),
                          ),
                    ]);
                  },
                ),
              ),
              const SizedBox(height: 14),
              PremiumCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('ویجت صفحه اصلی', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 18)),
                  const SizedBox(height: 8),
                  Text('ویجت بلافاصله بعد از تغییر چک‌لیست تازه می‌شود. هنگام فعال‌بودن قفل برنامه، عنوان کارها روی صفحهٔ خانه نمایش داده نمی‌شود.', style: TextStyle(color: colors.muted)),
                ]),
              ),
              const SizedBox(height: 18),
              Center(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: _registerSpecialTap,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                    child: Text('چکینو ${AppEnvironment.appVersion}', style: TextStyle(color: colors.mutedDark, fontSize: 11)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _subscriptionDescription({
    required DateTime? proUntil,
    required String? source,
    required bool inOfflineGrace,
  }) {
    final sourceLabel = source == 'bazaar'
        ? 'اشتراک ماهانه بازار'
        : source == 'myket'
            ? 'اشتراک ماهانه مایکت'
            : source == 'admin'
            ? 'دسترسی ویژه'
            : 'حساب Pro';
    if (proUntil == null) {
      return '$sourceLabel فعال است. وضعیت آخر روی گوشی ذخیره شده و هنگام اتصال اینترنت به‌روز می‌شود.';
    }
    if (inOfflineGrace) {
      return '$sourceLabel در مهلت آفلاین است. برای ادامه دسترسی، اینترنت را وصل کن تا وضعیت ${StoreEnvironment.label} تأیید شود.';
    }
    return '$sourceLabel تا ${formatDateTimeCompactFa(proUntil)} فعال است. وضعیت آخر روی گوشی ذخیره شده و هنگام اتصال به‌روز می‌شود.';
  }

  Future<void> _buyMonthlySubscription(RemoteSupportController remote) async {
    if (!remote.remoteEnabled) {
      _showBillingMessage('سرویس تأیید اشتراک برای این نسخه تنظیم نشده است.');
      return;
    }
    _startBillingProgress('در حال اتصال به ${StoreEnvironment.label}...');
    try {
      if (StoreEnvironment.isMyket) {
        final receipt = await MyketBillingService.instance.purchaseMonthly(onProgress: _updateBillingProgress);
        _updateBillingProgress('در حال تأیید امن اشتراک مایکت...');
        final profile = await remote.verifyMyketMonthlySubscription(receipt);
        unawaited(MyketBillingService.instance.consumeMonthlyPurchase(receipt));
        if (!mounted) return;
        final until = profile.proUntil == null ? '' : ' تا ${formatDateTimeCompactFa(profile.proUntil)}';
        _showBillingMessage('اشتراک ماهانه مایکت با موفقیت فعال شد$until.');
      } else {
        final receipt = await BazaarBillingService.instance.purchaseMonthly(onProgress: _updateBillingProgress);
        _updateBillingProgress('در حال تأیید امن اشتراک بازار...');
        final profile = await remote.verifyBazaarMonthlySubscription(receipt);
        if (!mounted) return;
        final until = profile.proUntil == null ? '' : ' تا ${formatDateTimeCompactFa(profile.proUntil)}';
        _showBillingMessage('اشتراک ماهانه بازار با موفقیت فعال شد$until.');
      }
    } on BazaarBillingException catch (error) {
      _showBillingMessage(error.message);
    } on MyketBillingException catch (error) {
      _showBillingMessage(error.message);
    } on RemoteApiException catch (error) {
      _showBillingMessage(error.message);
    } catch (_) {
      _showBillingMessage('فعال‌سازی اشتراک انجام نشد. دوباره تلاش کن.');
    } finally {
      _finishBillingProgress();
    }
  }

  Future<void> _restoreMonthlySubscription(RemoteSupportController remote) async {
    if (!remote.remoteEnabled) {
      _showBillingMessage('سرویس تأیید اشتراک برای این نسخه تنظیم نشده است.');
      return;
    }
    _startBillingProgress('در حال اتصال به ${StoreEnvironment.label}...');
    try {
      if (StoreEnvironment.isMyket) {
        final receipts = await MyketBillingService.instance.restoreMonthlyPurchases(onProgress: _updateBillingProgress);
        _updateBillingProgress('در حال تأیید امن خریدهای قبلی مایکت...');
        final profile = await remote.restoreMyketMonthlySubscription(receipts);
        for (final receipt in receipts) {
          unawaited(MyketBillingService.instance.consumeMonthlyPurchase(receipt));
        }
        if (!mounted) return;
        final until = profile.proUntil == null ? '' : ' تا ${formatDateTimeCompactFa(profile.proUntil)}';
        _showBillingMessage('وضعیت خرید مایکت بازیابی شد$until.');
      } else {
        final receipts = await BazaarBillingService.instance.restoreMonthlyPurchases(onProgress: _updateBillingProgress);
        _updateBillingProgress('در حال تأیید امن خریدهای قبلی بازار...');
        final profile = await remote.restoreBazaarMonthlySubscription(receipts);
        if (!mounted) return;
        final until = profile.proUntil == null ? '' : ' تا ${formatDateTimeCompactFa(profile.proUntil)}';
        _showBillingMessage('وضعیت خرید بازار بازیابی شد$until.');
      }
    } on BazaarBillingException catch (error) {
      _showBillingMessage(error.message);
    } on MyketBillingException catch (error) {
      _showBillingMessage(error.message);
    } on RemoteApiException catch (error) {
      _showBillingMessage(error.message);
    } catch (_) {
      _showBillingMessage('بازیابی خرید انجام نشد. اینترنت و حساب ${StoreEnvironment.label} را بررسی کن.');
    } finally {
      _finishBillingProgress();
    }
  }

  Future<void> _checkStoreConnection() async {
    _startBillingProgress('در حال اتصال به ${StoreEnvironment.label}...');
    try {
      final dynamic product = StoreEnvironment.isMyket
          ? await MyketBillingService.instance.checkMonthlyProduct(onProgress: _updateBillingProgress)
          : await BazaarBillingService.instance.checkMonthlyProduct(onProgress: _updateBillingProgress);
      if (!mounted) return;
      final title = product.title.trim().isEmpty ? 'اشتراک ماهانه چکینو Pro' : product.title.trim();
      final price = product.price.trim();
      _showBillingMessage(
        price.isEmpty
            ? 'اتصال ${StoreEnvironment.label} برقرار است و محصول «$title» برای خرید آماده است.'
            : 'اتصال ${StoreEnvironment.label} برقرار است. «$title» با قیمت $price برای خرید آماده است.',
      );
    } on BazaarBillingException catch (error) {
      _showBillingMessage(error.message);
    } on MyketBillingException catch (error) {
      _showBillingMessage(error.message);
    } catch (_) {
      _showBillingMessage('بررسی اتصال ${StoreEnvironment.label} انجام نشد. دوباره تلاش کن.');
    } finally {
      _finishBillingProgress();
    }
  }

  void _startBillingProgress(String message) {
    if (!mounted) return;
    setState(() {
      _billingBusy = true;
      _billingProgress = message;
    });
  }

  void _updateBillingProgress(String message) {
    if (!mounted || !_billingBusy) return;
    setState(() => _billingProgress = message);
  }

  void _finishBillingProgress() {
    if (!mounted) return;
    setState(() {
      _billingBusy = false;
      _billingProgress = null;
    });
  }

  void _showBillingMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void _registerSpecialTap() {
    final now = DateTime.now();
    if (_lastSpecialTap == null || now.difference(_lastSpecialTap!) > const Duration(seconds: 2)) _specialTapCount = 0;
    _lastSpecialTap = now;
    _specialTapCount++;
    if (_specialTapCount < 7) return;
    _specialTapCount = 0;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SpecialAccessLoginScreen()));
  }

  Future<void> _setLockEnabled(CheckinoDataController data, bool value) async {
    if (value && !RegExp(r'^\d{4,12}$').hasMatch(_pinController.text.trim())) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('برای فعال‌کردن قفل، ابتدا یک PIN چهار تا دوازده رقمی وارد کن.')));
      return;
    }
    await _saveLock(data, enabled: value);
  }

  Future<void> _saveLock(
    CheckinoDataController data, {
    bool? enabled,
    bool? biometricEnabled,
    bool? autoLockOnBackground,
  }) async {
    try {
      await data.setLockSettings(
        data.lockSettings.copyWith(
          enabled: enabled,
          pin: _pinController.text.trim(),
          biometricEnabled: biometricEnabled,
          autoLockOnBackground: autoLockOnBackground,
        ),
      );
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تنظیمات قفل ذخیره شد')));
    } on FormatException catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.message)));
    }
  }

  Future<void> _shareBackup(CheckinoDataController data) async {
    try {
      await data.shareBackupFile();
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ساخت فایل بکاپ ناموفق بود')));
    }
  }

  Future<void> _pickAndRestore(CheckinoDataController data) async {
    try {
      final preview = await data.pickBackupPreview();
      if (!mounted || preview == null) return;
      final mode = await showDialog<BackupImportMode>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('بررسی بکاپ'),
          content: Text(
            'فایل: ${preview.sourceName}\n'
            '${toPersianDigits(preview.lists.length)} چک‌لیست، '
            '${toPersianDigits(preview.itemCount)} آیتم، '
            '${toPersianDigits(preview.templates.length)} قالب و '
            '${toPersianDigits(preview.imageCount)} عکس پیدا شد.',
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('لغو')),
            OutlinedButton(onPressed: () => Navigator.pop(context, BackupImportMode.merge), child: const Text('ادغام با داده‌ها')),
            FilledButton(onPressed: () => Navigator.pop(context, BackupImportMode.replace), child: const Text('جایگزینی کامل')),
          ],
        ),
      );
      if (mode == null || !mounted) return;
      await data.importBackupPreview(preview, mode: mode);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('بازیابی بکاپ انجام شد')));
    } on FormatException catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('فایل انتخاب‌شده بکاپ معتبر چکینو نیست')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('بازیابی بکاپ ناموفق بود')));
    }
  }
}
