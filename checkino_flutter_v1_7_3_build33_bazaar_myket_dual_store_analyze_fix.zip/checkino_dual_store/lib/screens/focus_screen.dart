import 'package:flutter/material.dart';

import '../services/data_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/gradient_background.dart';
import '../widgets/premium_card.dart';

class FocusScreen extends StatelessWidget {
  const FocusScreen({super.key, required this.listId});
  final String listId;

  @override
  Widget build(BuildContext context) {
    final data = CheckinoDataScope.of(context);
    final list = data.listById(listId);
    final colors = context.appColors;
    final next = list?.items.where((item) => !item.done).toList();
    final item = (next == null || next.isEmpty) ? null : next.first;
    return GradientBackground(
      child: Scaffold(
        appBar: AppBar(title: const Text('حالت تمرکز')),
        body: Padding(
          padding: const EdgeInsets.all(18),
          child: Center(
            child: item == null
                ? Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.celebration, color: colors.success, size: 80),
                      const SizedBox(height: 14),
                      Text('همه کارهای این پوشه انجام شده', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 22)),
                    ],
                  )
                : PremiumCard(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('فقط همین یک کار', style: TextStyle(color: colors.muted, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 12),
                        Text(item.title, textAlign: TextAlign.center, style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 28)),
                        if ((item.note ?? '').isNotEmpty) ...[
                          const SizedBox(height: 12),
                          Text(item.note!, textAlign: TextAlign.center, style: TextStyle(color: colors.muted)),
                        ],
                        const SizedBox(height: 24),
                        FilledButton.icon(
                          onPressed: () => data.toggleItem(listId, item.id),
                          icon: const Icon(Icons.check_circle),
                          label: const Text('انجام شد'),
                        ),
                      ],
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}
