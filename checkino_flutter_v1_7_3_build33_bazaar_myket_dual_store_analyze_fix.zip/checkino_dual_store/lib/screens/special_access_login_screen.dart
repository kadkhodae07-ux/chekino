import 'package:flutter/material.dart';

import '../services/remote_api_client.dart';
import '../services/remote_support_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/gradient_background.dart';
import 'management_dashboard_screen.dart';

class SpecialAccessLoginScreen extends StatefulWidget {
  const SpecialAccessLoginScreen({super.key});

  @override
  State<SpecialAccessLoginScreen> createState() => _SpecialAccessLoginScreenState();
}

class _SpecialAccessLoginScreenState extends State<SpecialAccessLoginScreen> {
  final _username = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  bool _obscure = true;

  @override
  void dispose() {
    _username.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    final username = _username.text.trim();
    final password = _password.text;
    if (username.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('نام کاربری و رمز را وارد کن.')));
      return;
    }
    setState(() => _busy = true);
    try {
      await RemoteSupportScope.of(context).loginSpecial(username: username, password: password);
      if (!mounted) return;
      await Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const ManagementDashboardScreen()));
    } on RemoteApiException catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.message)));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return GradientBackground(
      child: Scaffold(
        appBar: AppBar(),
        body: SafeArea(
          top: false,
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(26),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Container(
                    width: 76,
                    height: 76,
                    decoration: BoxDecoration(color: colors.accent.withValues(alpha: 0.16), shape: BoxShape.circle),
                    child: Icon(Icons.verified_user_rounded, color: colors.accent, size: 38),
                  ),
                  const SizedBox(height: 18),
                  Text('ورود ویژه', style: TextStyle(color: colors.text, fontSize: 25, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  Text('اطلاعات دسترسی مجاز را وارد کنید.', style: TextStyle(color: colors.muted)),
                  const SizedBox(height: 24),
                  TextField(
                    controller: _username,
                    autocorrect: false,
                    textInputAction: TextInputAction.next,
                    decoration: const InputDecoration(labelText: 'نام کاربری', prefixIcon: Icon(Icons.person_outline_rounded)),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _password,
                    obscureText: _obscure,
                    onSubmitted: (_) => _login(),
                    decoration: InputDecoration(
                      labelText: 'رمز عبور',
                      prefixIcon: const Icon(Icons.lock_outline_rounded),
                      suffixIcon: IconButton(
                        onPressed: () => setState(() => _obscure = !_obscure),
                        icon: Icon(_obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _busy ? null : _login,
                      icon: _busy ? const SizedBox.square(dimension: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.login_rounded),
                      label: Text(_busy ? 'در حال بررسی...' : 'ورود'),
                    ),
                  ),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
