import 'package:flutter/material.dart';

import '../services/data_controller.dart';
import '../theme/app_theme.dart';
import '../utils/persian_numbers.dart';
import '../widgets/ad_widgets.dart';
import '../widgets/gradient_background.dart';
import '../widgets/premium_card.dart';

class TemplatesScreen extends StatelessWidget {
  const TemplatesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final data = CheckinoDataScope.of(context);
    final colors = context.appColors;
    final templates = data.templates;
    return GradientBackground(
      child: Scaffold(
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('قالب‌ها', style: TextStyle(color: colors.text, fontSize: 28, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text('قالب آماده را سریع بساز یا از منوی هر چک‌لیست، قالب شخصی ذخیره کن.', style: TextStyle(color: colors.muted)),
              const SizedBox(height: 18),
              const AdBannerSlot(placement: 'templates_banner'),
              ...templates.map(
                (template) => PremiumCard(
                  margin: const EdgeInsets.only(bottom: 12),
                  onTap: () async {
                    await data.applyTemplate(template);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('قالب «${template.title}» ساخته شد')));
                    }
                  },
                  child: Row(children: [
                    Icon(template.icon, color: colors.accent, size: 30),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Expanded(child: Text(template.title, style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 17))),
                          if (!template.isBuiltIn) Icon(Icons.person_outline_rounded, color: colors.muted, size: 17),
                        ]),
                        const SizedBox(height: 5),
                        Text('${toPersianDigits(template.items.length)} آیتم آماده', style: TextStyle(color: colors.muted)),
                      ]),
                    ),
                    if (template.isBuiltIn)
                      Icon(Icons.add_circle, color: colors.accent)
                    else
                      PopupMenuButton<String>(
                        icon: Icon(Icons.more_vert, color: colors.muted),
                        onSelected: (value) async {
                          if (value != 'delete') return;
                          final confirmed = await showDialog<bool>(
                            context: context,
                            builder: (context) => AlertDialog(
                              title: const Text('حذف قالب شخصی؟'),
                              content: Text('قالب «${template.title}» حذف می‌شود؛ چک‌لیست‌های ساخته‌شده تغییری نمی‌کنند.'),
                              actions: [
                                TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لغو')),
                                FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
                              ],
                            ),
                          );
                          if (confirmed == true) await data.deleteCustomTemplate(template.id);
                        },
                        itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: Text('حذف قالب'))],
                      ),
                  ]),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
