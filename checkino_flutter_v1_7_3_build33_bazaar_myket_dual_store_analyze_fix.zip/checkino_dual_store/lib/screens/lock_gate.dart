import 'package:flutter/material.dart';

import '../services/data_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/gradient_background.dart';

class LockGate extends StatefulWidget {
  const LockGate({super.key, required this.child});
  final Widget child;

  @override
  State<LockGate> createState() => _LockGateState();
}

class _LockGateState extends State<LockGate> with WidgetsBindingObserver {
  final _pin = TextEditingController();
  bool _unlocked = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _pin.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final lock = CheckinoDataScope.of(context).lockSettings;
    if (!lock.enabled || !lock.autoLockOnBackground) return;

    if (state == AppLifecycleState.inactive || state == AppLifecycleState.paused || state == AppLifecycleState.hidden || state == AppLifecycleState.detached) {
      _lockSilently();
    }
  }

  void _lockSilently() {
    if (!_unlocked && _pin.text.isEmpty && _error == null) return;
    if (!mounted) return;
    setState(() {
      _unlocked = false;
      _pin.clear();
      _error = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final data = CheckinoDataScope.of(context);
    final lock = data.lockSettings;
    if (!lock.enabled || _unlocked) return widget.child;
    final colors = context.appColors;
    return GradientBackground(
      child: Scaffold(
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(26),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 86,
                    height: 86,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: colors.accent.withValues(alpha: 0.16),
                      border: Border.all(color: colors.accent.withValues(alpha: 0.36)),
                    ),
                    child: Icon(Icons.lock_rounded, color: colors.accent, size: 40),
                  ),
                  const SizedBox(height: 22),
                  Text('چکینو قفل است', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 24)),
                  const SizedBox(height: 8),
                  Text('برای ورود رمز برنامه را وارد کن.', style: TextStyle(color: colors.muted)),
                  const SizedBox(height: 22),
                  TextField(
                    controller: _pin,
                    keyboardType: TextInputType.number,
                    obscureText: true,
                    textAlign: TextAlign.center,
                    decoration: InputDecoration(labelText: 'رمز ورود', errorText: _error),
                    onSubmitted: (_) => _checkPin(lock.pin),
                  ),
                  const SizedBox(height: 14),
                  FilledButton(onPressed: () => _checkPin(lock.pin), child: const SizedBox(width: double.infinity, child: Center(child: Text('ورود')))),
                  if (lock.biometricEnabled) ...[
                    const SizedBox(height: 10),
                    TextButton.icon(
                      onPressed: () async {
                        final ok = await data.authenticateBiometric();
                        if (ok && mounted) {
                          setState(() {
                            _unlocked = true;
                            _error = null;
                            _pin.clear();
                          });
                        }
                      },
                      icon: const Icon(Icons.fingerprint),
                      label: const Text('ورود با اثر انگشت'),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _checkPin(String pin) {
    if (_pin.text == pin) {
      setState(() {
        _unlocked = true;
        _error = null;
        _pin.clear();
      });
    } else {
      setState(() => _error = 'رمز درست نیست');
    }
  }
}
