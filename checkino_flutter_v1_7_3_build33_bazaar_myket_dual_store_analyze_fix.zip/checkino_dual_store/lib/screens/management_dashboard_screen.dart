import 'package:flutter/material.dart';

import '../models/remote_models.dart';
import '../services/remote_api_client.dart';
import '../services/remote_support_controller.dart';
import '../theme/app_theme.dart';
import '../utils/persian_numbers.dart';
import '../widgets/gradient_background.dart';
import '../widgets/premium_card.dart';
import 'ticket_detail_screen.dart';

class ManagementDashboardScreen extends StatefulWidget {
  const ManagementDashboardScreen({super.key});

  @override
  State<ManagementDashboardScreen> createState() => _ManagementDashboardScreenState();
}

class _ManagementDashboardScreenState extends State<ManagementDashboardScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabs;
  int _refreshTick = 0;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 5, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _logout() async {
    await RemoteSupportScope.of(context).logoutSpecial();
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final session = RemoteSupportScope.of(context).adminSession;
    return GradientBackground(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('مدیریت چکینو'),
          bottom: TabBar(
            controller: _tabs,
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            tabs: const [
              Tab(icon: Icon(Icons.space_dashboard_rounded), text: 'نمای کلی'),
              Tab(icon: Icon(Icons.people_alt_rounded), text: 'کاربران'),
              Tab(icon: Icon(Icons.forum_rounded), text: 'تیکت‌ها'),
              Tab(icon: Icon(Icons.campaign_rounded), text: 'پیام‌ها'),
              Tab(icon: Icon(Icons.security_rounded), text: 'امنیت'),
            ],
          ),
          actions: [
            IconButton(onPressed: () => setState(() => _refreshTick++), icon: const Icon(Icons.refresh_rounded), tooltip: 'به‌روزرسانی'),
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'logout') _logout();
              },
              itemBuilder: (context) => [
                PopupMenuItem(enabled: false, child: Text(session?.username ?? '')),
                const PopupMenuDivider(),
                const PopupMenuItem(value: 'logout', child: Text('خروج از مدیریت')),
              ],
            ),
          ],
        ),
        body: SafeArea(
          top: false,
          child: TabBarView(
            controller: _tabs,
            children: [
              _DashboardTab(key: ValueKey('dashboard-$_refreshTick')),
              _UsersTab(key: ValueKey('users-$_refreshTick')),
              _TicketsTab(key: ValueKey('tickets-$_refreshTick')),
              _BroadcastsTab(key: ValueKey('broadcasts-$_refreshTick')),
              _SecurityTab(key: ValueKey('security-$_refreshTick')),
            ],
          ),
        ),
      ),
    );
  }
}

class _DashboardTab extends StatefulWidget {
  const _DashboardTab({super.key});

  @override
  State<_DashboardTab> createState() => _DashboardTabState();
}

class _DashboardTabState extends State<_DashboardTab> {
  Future<AdminDashboardStats>? _future;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _future ??= RemoteSupportScope.of(context).fetchAdminDashboard();
  }

  Future<void> _reload() async {
    setState(() => _future = RemoteSupportScope.of(context).fetchAdminDashboard());
    await _future;
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return FutureBuilder<AdminDashboardStats>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError) return _AdminError(error: snapshot.error, onRetry: _reload);
        final stats = snapshot.data!;
        return RefreshIndicator(
          onRefresh: _reload,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.all(16),
            children: [
              PremiumCard(
                child: Row(children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(color: colors.accent.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(17)),
                    child: Icon(Icons.insights_rounded, color: colors.accent),
                  ),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('نمای کلی سرویس', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 18)),
                    const SizedBox(height: 4),
                    Text('آمار کاربران بدون دریافت متن چک‌لیست‌های شخصی.', style: TextStyle(color: colors.muted, fontSize: 12)),
                  ])),
                ]),
              ),
              const SizedBox(height: 14),
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                childAspectRatio: 1.28,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                children: [
                  _MetricCard(title: 'کل کاربران', value: stats.totalUsers, icon: Icons.people_alt_rounded),
                  _MetricCard(title: 'فعال امروز', value: stats.activeToday, icon: Icons.bolt_rounded, color: colors.success),
                  _MetricCard(title: 'کاربران رایگان', value: stats.freeUsers, icon: Icons.person_outline_rounded),
                  _MetricCard(title: 'کاربران Pro', value: stats.proUsers, icon: Icons.workspace_premium_rounded, color: colors.warning),
                  _MetricCard(title: 'مسدودشده', value: stats.blockedUsers, icon: Icons.block_rounded, color: colors.danger),
                  _MetricCard(title: 'تیکت باز', value: stats.openTickets, icon: Icons.forum_rounded, color: colors.warning),
                  _MetricCard(title: 'ثبت‌نام ۷ روز', value: stats.newUsersWeek, icon: Icons.person_add_alt_rounded, color: colors.accent),
                ],
              ),
              const SizedBox(height: 14),
              PremiumCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('کنترل‌های این بخش', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 17)),
                  const SizedBox(height: 8),
                  Text('وضعیت Pro، محدودسازی کاربر، پاسخ به تیکت، پیام عمومی، نام کاربری و رمز ورود از تب‌های بالا مدیریت می‌شود.', style: TextStyle(color: colors.muted, height: 1.55)),
                ]),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({required this.title, required this.value, required this.icon, this.color});

  final String title;
  final int value;
  final IconData icon;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final tint = color ?? colors.accent;
    return PremiumCard(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: tint),
        const Spacer(),
        Text(toPersianDigits(value), style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 23)),
        Text(title, style: TextStyle(color: colors.muted, fontWeight: FontWeight.w800, fontSize: 12)),
      ]),
    );
  }
}

class _UsersTab extends StatefulWidget {
  const _UsersTab({super.key});

  @override
  State<_UsersTab> createState() => _UsersTabState();
}

class _UsersTabState extends State<_UsersTab> {
  final _search = TextEditingController();
  String _filter = 'all';
  Future<List<ManagedUser>>? _future;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _future ??= _fetch();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<List<ManagedUser>> _fetch() => RemoteSupportScope.of(context).fetchManagedUsers(query: _search.text, filter: _filter);

  Future<void> _reload() async {
    setState(() => _future = _fetch());
    await _future;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<ManagedUser>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError) return _AdminError(error: snapshot.error, onRetry: _reload);
        final users = snapshot.data ?? const [];
        return RefreshIndicator(
          onRefresh: _reload,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.all(16),
            children: [
              TextField(
                controller: _search,
                textInputAction: TextInputAction.search,
                onSubmitted: (_) => _reload(),
                decoration: InputDecoration(
                  labelText: 'جست‌وجوی شناسه کاربر',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: IconButton(onPressed: _reload, icon: const Icon(Icons.search_rounded)),
                ),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _FilterChip(title: 'همه', selected: _filter == 'all', onTap: () { setState(() => _filter = 'all'); _reload(); }),
                  _FilterChip(title: 'رایگان', selected: _filter == 'free', onTap: () { setState(() => _filter = 'free'); _reload(); }),
                  _FilterChip(title: 'Pro', selected: _filter == 'pro', onTap: () { setState(() => _filter = 'pro'); _reload(); }),
                  _FilterChip(title: 'مسدود', selected: _filter == 'blocked', onTap: () { setState(() => _filter = 'blocked'); _reload(); }),
                ],
              ),
              const SizedBox(height: 16),
              if (users.isEmpty)
                _EmptyAdmin(title: 'کاربری پیدا نشد', message: 'هنوز داده‌ای با این فیلتر ثبت نشده است.')
              else
                ...users.map(
                  (user) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: _ManagedUserCard(
                      user: user,
                      onTap: () async {
                        final changed = await showModalBottomSheet<bool>(
                          context: context,
                          isScrollControlled: true,
                          builder: (context) => _UserEditor(user: user),
                        );
                        if (changed == true && mounted) _reload();
                      },
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({required this.title, required this.selected, required this.onTap});
  final String title;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => ChoiceChip(label: Text(title), selected: selected, onSelected: (_) => onTap());
}

class _ManagedUserCard extends StatelessWidget {
  const _ManagedUserCard({required this.user, required this.onTap});

  final ManagedUser user;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final statusColor = user.isBlocked ? colors.danger : user.tier == 'pro' ? colors.warning : colors.accent;
    final status = user.isBlocked ? 'مسدود' : user.tier == 'pro' ? 'Pro' : 'رایگان';
    final trimmedId = user.id.length > 12 ? '${user.id.substring(0, 12)}…' : user.id;
    return PremiumCard(
      onTap: onTap,
      child: Row(children: [
        Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(15)),
          child: Icon(user.isBlocked ? Icons.block_rounded : user.tier == 'pro' ? Icons.workspace_premium_rounded : Icons.person_rounded, color: statusColor),
        ),
        const SizedBox(width: 11),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(trimmedId, style: TextStyle(color: colors.text, fontWeight: FontWeight.w900)),
          const SizedBox(height: 3),
          Text('${toPersianDigits(user.activeLists)} لیست • ${toPersianDigits(user.doneItems)}/${toPersianDigits(user.totalItems)} کار • ${toPersianDigits(user.ticketCount)} تیکت', style: TextStyle(color: colors.muted, fontSize: 11)),
          const SizedBox(height: 5),
          Text('$status${_subscriptionSourceLabel(user.subscriptionSource)} • آخرین فعالیت ${formatDateTimeCompactFa(user.lastSeenAt)}', style: TextStyle(color: statusColor, fontSize: 11, fontWeight: FontWeight.w800)),
        ])),
        Icon(Icons.chevron_left_rounded, color: colors.muted),
      ]),
    );
  }

  String _subscriptionSourceLabel(String? source) => switch (source) {
        'bazaar' => ' • بازار',
        'myket' => ' • مایکت',
        'admin' => ' • دستی',
        'legacy' => ' • قدیمی',
        _ => '',
      };
}

class _UserEditor extends StatefulWidget {
  const _UserEditor({required this.user});
  final ManagedUser user;

  @override
  State<_UserEditor> createState() => _UserEditorState();
}

class _UserEditorState extends State<_UserEditor> {
  late String _tier;
  late bool _blocked;
  DateTime? _proUntil;
  late final TextEditingController _reason;
  late final TextEditingController _note;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _tier = widget.user.tier;
    _blocked = widget.user.isBlocked;
    _proUntil = widget.user.proUntil;
    _reason = TextEditingController(text: widget.user.blockReason ?? '');
    _note = TextEditingController(text: widget.user.note ?? '');
  }

  @override
  void dispose() {
    _reason.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _pickProUntil() async {
    final date = await showDatePicker(
      context: context,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 3650)),
      initialDate: _proUntil ?? DateTime.now().add(const Duration(days: 30)),
    );
    if (date != null && mounted) setState(() => _proUntil = date);
  }

  Future<void> _save() async {
    if (_blocked && _reason.text.trim().length < 3) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('برای محدودسازی، دلیل کوتاه وارد کن.')));
      return;
    }
    setState(() => _saving = true);
    try {
      await RemoteSupportScope.of(context).updateManagedUser(
        userId: widget.user.id,
        tier: _tier,
        isBlocked: _blocked,
        proUntil: _tier == 'pro' ? _proUntil?.toUtc().toIso8601String() : null,
        blockReason: _blocked ? _reason.text : null,
        note: _note.text,
      );
      if (!mounted) return;
      Navigator.pop(context, true);
    } on RemoteApiException catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.message)));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, bottom + 16),
      child: Material(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('مدیریت کاربر', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
            const SizedBox(height: 4),
            Text(widget.user.id, style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 14),
            if (widget.user.subscriptionSource == 'bazaar' || widget.user.subscriptionSource == 'myket') ...[
              Text('این کاربر اشتراک مارکتی دارد؛ تغییر دستی فقط دسترسی دستی را تغییر می‌دهد و خرید معتبر بازار/مایکت در همگام‌سازی بعدی اولویت خواهد داشت.', style: TextStyle(color: context.appColors.muted, fontSize: 11, height: 1.45)),
              const SizedBox(height: 10),
            ],
            DropdownButtonFormField<String>(
              initialValue: _tier,
              decoration: const InputDecoration(labelText: 'نوع حساب'),
              items: const [DropdownMenuItem(value: 'free', child: Text('رایگان')), DropdownMenuItem(value: 'pro', child: Text('Pro'))],
              onChanged: (value) => setState(() => _tier = value ?? 'free'),
            ),
            if (_tier == 'pro') ...[
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: _pickProUntil,
                icon: const Icon(Icons.calendar_month_rounded),
                label: Text(_proUntil == null ? 'Pro دائمی' : 'اعتبار تا ${formatDateTimeCompactFa(_proUntil)}'),
              ),
              TextButton(onPressed: () => setState(() => _proUntil = null), child: const Text('حذف تاریخ پایان')),
            ],
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('غیرفعال‌کردن دسترسی آنلاین'),
              subtitle: const Text('چک‌لیست‌های محلی حذف نمی‌شوند؛ فقط امکانات آنلاین قطع می‌شود.'),
              value: _blocked,
              onChanged: (value) => setState(() => _blocked = value),
            ),
            if (_blocked) ...[
              const SizedBox(height: 8),
              TextField(controller: _reason, maxLength: 300, decoration: const InputDecoration(labelText: 'دلیل محدودسازی', counterText: '')),
            ],
            const SizedBox(height: 8),
            TextField(controller: _note, maxLines: 3, maxLength: 1000, decoration: const InputDecoration(labelText: 'یادداشت داخلی', alignLabelWithHint: true, counterText: '')),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, child: FilledButton(onPressed: _saving ? null : _save, child: Text(_saving ? 'در حال ذخیره...' : 'ذخیره تغییرات'))),
          ]),
        ),
      ),
    );
  }
}

class _TicketsTab extends StatefulWidget {
  const _TicketsTab({super.key});

  @override
  State<_TicketsTab> createState() => _TicketsTabState();
}

class _TicketsTabState extends State<_TicketsTab> {
  String _status = 'all';
  Future<List<SupportTicket>>? _future;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _future ??= _fetch();
  }

  Future<List<SupportTicket>> _fetch() => RemoteSupportScope.of(context).fetchAdminTickets(status: _status);

  Future<void> _reload() async {
    setState(() => _future = _fetch());
    await _future;
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return FutureBuilder<List<SupportTicket>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError) return _AdminError(error: snapshot.error, onRetry: _reload);
        final tickets = snapshot.data ?? const [];
        return RefreshIndicator(
          onRefresh: _reload,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.all(16),
            children: [
              Wrap(spacing: 8, runSpacing: 8, children: [
                _FilterChip(title: 'همه', selected: _status == 'all', onTap: () { setState(() => _status = 'all'); _reload(); }),
                _FilterChip(title: 'باز', selected: _status == 'open', onTap: () { setState(() => _status = 'open'); _reload(); }),
                _FilterChip(title: 'پاسخ‌داده‌شده', selected: _status == 'answered', onTap: () { setState(() => _status = 'answered'); _reload(); }),
                _FilterChip(title: 'بسته', selected: _status == 'closed', onTap: () { setState(() => _status = 'closed'); _reload(); }),
              ]),
              const SizedBox(height: 14),
              if (tickets.isEmpty)
                _EmptyAdmin(title: 'تیکتی پیدا نشد', message: 'در این وضعیت، تیکت ثبت‌شده‌ای وجود ندارد.')
              else
                ...tickets.map((ticket) {
                  final statusColor = ticket.status == 'closed' ? colors.muted : ticket.status == 'answered' ? colors.accent : colors.warning;
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: PremiumCard(
                      onTap: () async {
                        await Navigator.of(context).push(MaterialPageRoute(builder: (_) => TicketDetailScreen(ticketId: ticket.id, adminMode: true)));
                        if (mounted) _reload();
                      },
                      child: Row(children: [
                        Icon(ticket.status == 'closed' ? Icons.task_alt_rounded : Icons.forum_rounded, color: statusColor),
                        const SizedBox(width: 10),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(ticket.subject, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: colors.text, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 4),
                          Text('${_ticketStatus(ticket.status)} • ${formatDateTimeCompactFa(ticket.updatedAt)}', style: TextStyle(color: statusColor, fontSize: 11, fontWeight: FontWeight.w800)),
                        ])),
                        Icon(Icons.chevron_left_rounded, color: colors.muted),
                      ]),
                    ),
                  );
                }),
            ],
          ),
        );
      },
    );
  }

  String _ticketStatus(String value) => switch (value) {
        'open' => 'باز',
        'answered' => 'پاسخ داده شد',
        'closed' => 'بسته',
        _ => 'در حال بررسی',
      };
}

class _BroadcastsTab extends StatefulWidget {
  const _BroadcastsTab({super.key});

  @override
  State<_BroadcastsTab> createState() => _BroadcastsTabState();
}

class _BroadcastsTabState extends State<_BroadcastsTab> {
  Future<List<RemoteBroadcast>>? _future;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _future ??= _fetch();
  }

  Future<List<RemoteBroadcast>> _fetch() => RemoteSupportScope.of(context).fetchAdminBroadcasts();

  Future<void> _reload() async {
    setState(() => _future = _fetch());
    await _future;
  }

  Future<void> _compose() async {
    final sent = await showModalBottomSheet<bool>(context: context, isScrollControlled: true, builder: (_) => const _BroadcastComposer());
    if (sent == true && mounted) _reload();
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return FutureBuilder<List<RemoteBroadcast>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError) return _AdminError(error: snapshot.error, onRetry: _reload);
        final broadcasts = snapshot.data ?? const [];
        return Scaffold(
          backgroundColor: Colors.transparent,
          floatingActionButton: FloatingActionButton.extended(onPressed: _compose, icon: const Icon(Icons.campaign_rounded), label: const Text('پیام جدید')),
          body: RefreshIndicator(
            onRefresh: _reload,
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
              children: [
                PremiumCard(
                  child: Text('پیام همگانی هنگام باز شدن برنامه دریافت می‌شود. پیام‌های مهم را به شکل پنجرهٔ اطلاع‌رسانی نمایش بده.', style: TextStyle(color: colors.muted, height: 1.5)),
                ),
                const SizedBox(height: 14),
                if (broadcasts.isEmpty)
                  _EmptyAdmin(title: 'پیامی ثبت نشده است', message: 'اولین پیام همگانی را برای کاربران ارسال کن.')
                else
                  ...broadcasts.map((message) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: PremiumCard(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Row(children: [
                              Expanded(child: Text(message.title, style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 16))),
                              Switch(
                                value: message.active,
                                onChanged: (value) async {
                                  final messenger = ScaffoldMessenger.of(context);
                                  try {
                                    await RemoteSupportScope.of(context).setBroadcastActive(
                                      broadcastId: message.id,
                                      active: value,
                                    );
                                    if (!mounted) return;
                                    _reload();
                                  } on RemoteApiException catch (error) {
                                    messenger.showSnackBar(
                                      SnackBar(content: Text(error.message)),
                                    );
                                  }
                                },
                              ),
                            ]),
                            const SizedBox(height: 7),
                            Text(message.body, style: TextStyle(color: colors.muted, height: 1.45)),
                            const SizedBox(height: 8),
                            Text('${_audienceTitle(message.audience)} • ${message.popup ? 'نمایش پنجره‌ای' : 'فقط صندوق پیام'} • ${formatDateTimeCompactFa(message.createdAt)}', style: TextStyle(color: message.active ? colors.accent : colors.muted, fontSize: 11, fontWeight: FontWeight.w800)),
                          ]),
                        ),
                      )),
              ],
            ),
          ),
        );
      },
    );
  }

  String _audienceTitle(String audience) => switch (audience) {
        'free' => 'فقط رایگان',
        'pro' => 'فقط Pro',
        _ => 'همه کاربران',
      };
}

class _BroadcastComposer extends StatefulWidget {
  const _BroadcastComposer();

  @override
  State<_BroadcastComposer> createState() => _BroadcastComposerState();
}

class _BroadcastComposerState extends State<_BroadcastComposer> {
  final _title = TextEditingController();
  final _body = TextEditingController();
  String _audience = 'all';
  bool _popup = true;
  bool _sending = false;

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_title.text.trim().length < 3 || _body.text.trim().length < 3) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('عنوان و متن پیام را کامل وارد کن.')));
      return;
    }
    setState(() => _sending = true);
    try {
      await RemoteSupportScope.of(context).createBroadcast(title: _title.text, body: _body.text, audience: _audience, popup: _popup);
      if (!mounted) return;
      Navigator.pop(context, true);
    } on RemoteApiException catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.message)));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, bottom + 16),
      child: Material(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('ارسال پیام همگانی', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 14),
            TextField(controller: _title, maxLength: 120, decoration: const InputDecoration(labelText: 'عنوان پیام', counterText: '')),
            const SizedBox(height: 10),
            TextField(controller: _body, maxLength: 3000, minLines: 4, maxLines: 7, decoration: const InputDecoration(labelText: 'متن پیام', alignLabelWithHint: true, counterText: '')),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              initialValue: _audience,
              decoration: const InputDecoration(labelText: 'گیرندگان'),
              items: const [
                DropdownMenuItem(value: 'all', child: Text('همه کاربران')),
                DropdownMenuItem(value: 'free', child: Text('فقط کاربران رایگان')),
                DropdownMenuItem(value: 'pro', child: Text('فقط کاربران Pro')),
              ],
              onChanged: (value) => setState(() => _audience = value ?? 'all'),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('نمایش پنجره‌ای هنگام ورود'),
              subtitle: const Text('کاربر با باز کردن برنامه پیام را به‌صورت پنجره می‌بیند.'),
              value: _popup,
              onChanged: (value) => setState(() => _popup = value),
            ),
            const SizedBox(height: 12),
            SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _sending ? null : _submit, icon: const Icon(Icons.send_rounded), label: Text(_sending ? 'در حال ارسال...' : 'ارسال'))),
          ]),
        ),
      ),
    );
  }
}

class _SecurityTab extends StatefulWidget {
  const _SecurityTab({super.key});

  @override
  State<_SecurityTab> createState() => _SecurityTabState();
}

class _SecurityTabState extends State<_SecurityTab> {
  Future<List<AdminAuditEntry>>? _auditFuture;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _auditFuture ??= RemoteSupportScope.of(context).fetchAdminAudit();
  }

  Future<void> _reloadAudit() async {
    setState(() => _auditFuture = RemoteSupportScope.of(context).fetchAdminAudit());
    await _auditFuture;
  }

  Future<void> _changePassword() async {
    final changed = await showModalBottomSheet<bool>(context: context, isScrollControlled: true, builder: (_) => const _PasswordEditor());
    if (changed == true && mounted) _reloadAudit();
  }

  Future<void> _changeUsername() async {
    final changed = await showModalBottomSheet<bool>(context: context, isScrollControlled: true, builder: (_) => const _UsernameEditor());
    if (changed == true && mounted) _reloadAudit();
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return FutureBuilder<List<AdminAuditEntry>>(
      future: _auditFuture,
      builder: (context, snapshot) {
        final entries = snapshot.data ?? const [];
        return RefreshIndicator(
          onRefresh: _reloadAudit,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.all(16),
            children: [
              PremiumCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('حساب مدیریتی', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 18)),
                  const SizedBox(height: 8),
                  Text('رمز عبور هش‌شده در سرور ذخیره می‌شود. پس از تغییر رمز، نشست‌های قبلی به‌جز دستگاه فعلی منقضی می‌شوند.', style: TextStyle(color: colors.muted, height: 1.5)),
                  const SizedBox(height: 12),
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    FilledButton.icon(onPressed: _changePassword, icon: const Icon(Icons.password_rounded), label: const Text('تغییر رمز')), 
                    OutlinedButton.icon(onPressed: _changeUsername, icon: const Icon(Icons.person_rounded), label: const Text('تغییر نام کاربری')),
                  ]),
                ]),
              ),
              const SizedBox(height: 14),
              Text('سابقه عملیات', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 17)),
              const SizedBox(height: 8),
              if (snapshot.connectionState != ConnectionState.done)
                const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator()))
              else if (snapshot.hasError)
                _AdminError(error: snapshot.error, onRetry: _reloadAudit)
              else if (entries.isEmpty)
                _EmptyAdmin(title: 'سابقه‌ای ثبت نشده است', message: 'عملیات مهم از اینجا قابل پیگیری خواهد بود.')
              else
                ...entries.map((entry) => Padding(
                      padding: const EdgeInsets.only(bottom: 9),
                      child: PremiumCard(
                        child: Row(children: [
                          Icon(Icons.history_rounded, color: colors.accent),
                          const SizedBox(width: 10),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(entry.summary, style: TextStyle(color: colors.text, fontWeight: FontWeight.w800)),
                            const SizedBox(height: 4),
                            Text('${entry.action} • ${formatDateTimeCompactFa(entry.createdAt)}', style: TextStyle(color: colors.muted, fontSize: 11)),
                          ])),
                        ]),
                      ),
                    )),
            ],
          ),
        );
      },
    );
  }
}

class _PasswordEditor extends StatefulWidget {
  const _PasswordEditor();

  @override
  State<_PasswordEditor> createState() => _PasswordEditorState();
}

class _PasswordEditorState extends State<_PasswordEditor> {
  final _current = TextEditingController();
  final _next = TextEditingController();
  final _confirm = TextEditingController();
  bool _saving = false;

  @override
  void dispose() {
    _current.dispose();
    _next.dispose();
    _confirm.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_next.text.length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('رمز جدید حداقل ۱۰ کاراکتر باشد.')));
      return;
    }
    if (_next.text != _confirm.text) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تکرار رمز جدید یکسان نیست.')));
      return;
    }
    setState(() => _saving = true);
    try {
      await RemoteSupportScope.of(context).changeAdminPassword(currentPassword: _current.text, newPassword: _next.text);
      if (!mounted) return;
      Navigator.pop(context, true);
    } on RemoteApiException catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.message)));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, bottom + 16),
      child: Material(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('تغییر رمز ورود', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 14),
            TextField(controller: _current, obscureText: true, decoration: const InputDecoration(labelText: 'رمز فعلی')),
            const SizedBox(height: 10),
            TextField(controller: _next, obscureText: true, decoration: const InputDecoration(labelText: 'رمز جدید')),
            const SizedBox(height: 10),
            TextField(controller: _confirm, obscureText: true, onSubmitted: (_) => _save(), decoration: const InputDecoration(labelText: 'تکرار رمز جدید')),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, child: FilledButton(onPressed: _saving ? null : _save, child: Text(_saving ? 'در حال ذخیره...' : 'تغییر رمز'))),
          ]),
        ),
      ),
    );
  }
}

class _UsernameEditor extends StatefulWidget {
  const _UsernameEditor();

  @override
  State<_UsernameEditor> createState() => _UsernameEditorState();
}

class _UsernameEditorState extends State<_UsernameEditor> {
  final _username = TextEditingController();
  final _password = TextEditingController();
  bool _saving = false;

  @override
  void dispose() {
    _username.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_username.text.trim().length < 3 || _password.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('نام کاربری جدید و رمز فعلی را وارد کن.')));
      return;
    }
    setState(() => _saving = true);
    try {
      await RemoteSupportScope.of(context).changeAdminUsername(currentPassword: _password.text, username: _username.text);
      if (!mounted) return;
      Navigator.pop(context, true);
    } on RemoteApiException catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.message)));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, bottom + 16),
      child: Material(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('تغییر نام کاربری', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 14),
            TextField(controller: _username, decoration: const InputDecoration(labelText: 'نام کاربری جدید')),
            const SizedBox(height: 10),
            TextField(controller: _password, obscureText: true, onSubmitted: (_) => _save(), decoration: const InputDecoration(labelText: 'رمز فعلی')),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, child: FilledButton(onPressed: _saving ? null : _save, child: Text(_saving ? 'در حال ذخیره...' : 'تغییر نام کاربری'))),
          ]),
        ),
      ),
    );
  }
}

class _AdminError extends StatelessWidget {
  const _AdminError({required this.error, required this.onRetry});
  final Object? error;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final message = error is RemoteApiException ? (error as RemoteApiException).message : 'اتصال به سرویس مدیریت ناموفق بود.';
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.cloud_off_rounded, size: 55, color: colors.danger),
          const SizedBox(height: 12),
          Text(message, textAlign: TextAlign.center, style: TextStyle(color: colors.muted)),
          const SizedBox(height: 12),
          OutlinedButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh_rounded), label: const Text('تلاش دوباره')),
        ]),
      ),
    );
  }
}

class _EmptyAdmin extends StatelessWidget {
  const _EmptyAdmin({required this.title, required this.message});
  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return PremiumCard(
      margin: const EdgeInsets.only(top: 28),
      child: Column(children: [
        Icon(Icons.inbox_outlined, color: colors.accent, size: 54),
        const SizedBox(height: 12),
        Text(title, style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 17)),
        const SizedBox(height: 6),
        Text(message, textAlign: TextAlign.center, style: TextStyle(color: colors.muted)),
      ]),
    );
  }
}
