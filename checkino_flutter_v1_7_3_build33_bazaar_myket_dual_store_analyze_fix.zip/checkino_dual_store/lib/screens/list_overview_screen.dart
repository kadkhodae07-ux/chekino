import 'package:flutter/material.dart';

import '../models/check_list.dart';
import '../services/data_controller.dart';
import '../theme/app_theme.dart';
import '../utils/persian_numbers.dart';
import '../utils/checkino_icons.dart';
import '../widgets/gradient_background.dart';
import '../widgets/premium_card.dart';
import '../widgets/progress_line.dart';
import '../widgets/ad_widgets.dart';
import 'archive_screen.dart';
import 'checklist_detail_screen.dart';
import 'form_helpers.dart';

class ListOverviewScreen extends StatefulWidget {
  const ListOverviewScreen({super.key});

  @override
  State<ListOverviewScreen> createState() => _ListOverviewScreenState();
}

class _ListOverviewScreenState extends State<ListOverviewScreen> {
  final _search = TextEditingController();
  String _filter = 'all';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final data = CheckinoDataScope.of(context);
    final colors = context.appColors;
    final lists = _applyFilters(data.activeLists);
    final canReorder = _filter == 'all' && _search.text.trim().isEmpty;
    return GradientBackground(
      child: Scaffold(
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => _createList(context),
          icon: const Icon(Icons.add),
          label: const Text('پوشه'),
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(child: Text('چکینو', style: TextStyle(color: colors.text, fontSize: 30, fontWeight: FontWeight.w900))),
                    IconButton(
                      tooltip: 'آرشیو',
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ArchiveScreen())),
                      icon: Icon(Icons.inventory_2_rounded, color: colors.muted),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _search,
                  onChanged: (_) => setState(() {}),
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'جست‌وجو در پوشه‌ها و آیتم‌ها'),
                ),
                const SizedBox(height: 12),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  reverse: true,
                  child: Row(
                    children: [
                      _filterChip('all', 'همه'),
                      _filterChip('today', 'امروز'),
                      _filterChip('overdue', 'عقب‌افتاده'),
                      _filterChip('important', 'مهم'),
                      _filterChip('complete', 'کامل‌شده'),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                const AdiveryNativeAdSlot(),
                Expanded(
                  child: lists.isEmpty
                      ? _EmptyState(onCreate: () => _createList(context))
                      : canReorder
                          ? ReorderableListView.builder(
                              onReorderItem: (oldIndex, newIndex) => data.reorderActiveLists(oldIndex, newIndex),
                              itemCount: lists.length,
                              padding: const EdgeInsets.only(bottom: 100, top: 4),
                              itemBuilder: (context, index) {
                                final list = lists[index];
                                return _ListCard(key: ValueKey(list.id), list: list);
                              },
                            )
                          : ListView.builder(
                              itemCount: lists.length,
                              padding: const EdgeInsets.only(bottom: 100, top: 4),
                              itemBuilder: (context, index) => _ListCard(list: lists[index]),
                            ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }


  Future<void> _createList(BuildContext context) async {
    final data = CheckinoDataScope.of(context);
    final monetization = MonetizationScope.of(context);
    if (monetization.needsRewardForNewList(data.activeLists.length)) {
      final allowed = await showRewardedVideoGate(
        context,
        title: 'ساخت چک‌لیست جدید',
        message: monetization.rewardReasonForNewList(data.activeLists.length),
      );
      if (!allowed || !context.mounted) return;
    }
    final result = await showListEditor(context);
    if (result != null) {
      await data.addList(result);
      if (context.mounted && result.reminderEnabled) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('یادآور برای ${formatDateTimeFa(result.nextReminderAt)} ثبت شد')));
      }
    }
  }

  List<CheckListModel> _applyFilters(List<CheckListModel> input) {
    final q = _search.text.trim();
    return input.where((list) {
      final matchesSearch = q.isEmpty || list.title.contains(q) || list.items.any((item) => item.title.contains(q) || (item.note ?? '').contains(q));
      if (!matchesSearch) return false;
      if (_filter == 'today') return list.todayCount > 0;
      if (_filter == 'overdue') return list.overdueCount > 0;
      if (_filter == 'important') return list.highPriorityCount > 0;
      if (_filter == 'complete') return list.isComplete;
      return true;
    }).toList();
  }

  Widget _filterChip(String id, String title) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: ChoiceChip(selected: _filter == id, label: Text(title), onSelected: (_) => setState(() => _filter = id)),
    );
  }
}


class _ListCard extends StatelessWidget {
  const _ListCard({super.key, required this.list});
  final CheckListModel list;

  @override
  Widget build(BuildContext context) {
    final data = CheckinoDataScope.of(context);
    final colors = context.appColors;
    final accent = list.colorValue == null ? colors.accent : Color(list.colorValue!);
    return PremiumCard(
      margin: const EdgeInsets.only(bottom: 14),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChecklistDetailScreen(listId: list.id))),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), color: accent.withValues(alpha: 0.16)),
                child: Icon(checkinoIconFromCodePoint(list.iconCodePoint), color: accent),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      if (list.pinned) Icon(Icons.push_pin_rounded, color: colors.warning, size: 16),
                      if (list.pinned) const SizedBox(width: 4),
                      Expanded(child: Text(list.title, style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 17))),
                    ]),
                    const SizedBox(height: 5),
                    Text('${toPersianDigits(list.totalItems)} آیتم • ${toPersianDigits(list.completedItems)} انجام‌شده', style: TextStyle(color: colors.muted, fontSize: 12)),
                  ],
                ),
              ),
              PopupMenuButton<String>(
                icon: Icon(Icons.more_vert, color: colors.muted),
                onSelected: (value) async {
                  if (value == 'edit') {
                    final result = await showListEditor(context, list: list);
                    if (result != null) {
                      await data.updateList(result);
                      if (context.mounted && result.reminderEnabled) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('یادآور برای ${formatDateTimeFa(result.nextReminderAt)} ثبت شد')));
                      }
                    }
                  } else if (value == 'pin') {
                    data.togglePin(list.id);
                  } else if (value == 'archive') {
                    data.archiveList(list.id, true);
                  } else if (value == 'share') {
                    data.shareListText(list);
                  } else if (value == 'pdf') {
                    data.shareListPdf(list);
                  } else if (value == 'template') {
                    await data.createTemplateFromList(list);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('قالب شخصی ذخیره شد')));
                    }
                  } else if (value == 'delete') {
                    final confirmed = await showDialog<bool>(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: const Text('حذف چک‌لیست؟'),
                        content: Text('«${list.title}» و همه آیتم‌های آن حذف می‌شوند.'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لغو')),
                          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
                        ],
                      ),
                    );
                    if (confirmed == true) await data.deleteList(list.id);
                  }
                },
                itemBuilder: (_) => [
                  const PopupMenuItem(value: 'edit', child: Text('ویرایش')),
                  PopupMenuItem(value: 'pin', child: Text(list.pinned ? 'برداشتن سنجاق' : 'سنجاق کردن')),
                  const PopupMenuItem(value: 'archive', child: Text('انتقال به آرشیو')),
                  const PopupMenuItem(value: 'share', child: Text('اشتراک متنی')),
                  const PopupMenuItem(value: 'pdf', child: Text('خروجی PDF')),
                  const PopupMenuItem(value: 'template', child: Text('ذخیره به‌عنوان قالب')),
                  const PopupMenuItem(value: 'delete', child: Text('حذف')),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(children: [
            Text('${toPersianDigits(list.progressPercent)}٪', style: TextStyle(color: accent, fontWeight: FontWeight.w900)),
            const SizedBox(width: 10),
            Expanded(child: ProgressLine(value: list.progress)),
          ]),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: [
              if (list.reminderEnabled) _Badge(icon: Icons.notifications_active, text: 'یادآور ${formatDateTimeCompactFa(list.nextReminderAt)}'),
              if (list.todayCount > 0) _Badge(icon: Icons.today, text: '${toPersianDigits(list.todayCount)} امروز'),
              if (list.overdueCount > 0) _Badge(icon: Icons.warning_rounded, text: '${toPersianDigits(list.overdueCount)} عقب‌افتاده'),
              if (list.highPriorityCount > 0) _Badge(icon: Icons.priority_high, text: '${toPersianDigits(list.highPriorityCount)} مهم'),
            ],
          ),
        ],
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  const _Badge({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: colors.cardAlt, borderRadius: BorderRadius.circular(99), border: Border.all(color: colors.border)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 14, color: colors.accent), const SizedBox(width: 5), Text(text, style: TextStyle(color: colors.muted, fontSize: 11, fontWeight: FontWeight.w800))]),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.onCreate});
  final VoidCallback onCreate;
  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.checklist_rtl_rounded, color: colors.accent, size: 70),
          const SizedBox(height: 10),
          Text('هنوز چیزی پیدا نشد', style: TextStyle(color: colors.text, fontSize: 20, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text('یک پوشه جدید بساز یا فیلترها را تغییر بده.', style: TextStyle(color: colors.muted)),
          const SizedBox(height: 18),
          FilledButton.icon(onPressed: onCreate, icon: const Icon(Icons.add), label: const Text('ساخت پوشه')),
        ],
      ),
    );
  }
}
