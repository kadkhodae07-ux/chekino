import 'package:flutter/material.dart';

import '../services/data_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/gradient_background.dart';
import '../widgets/premium_card.dart';

class ArchiveScreen extends StatelessWidget {
  const ArchiveScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final data = CheckinoDataScope.of(context);
    final colors = context.appColors;
    final lists = data.archivedLists;
    return GradientBackground(
      child: Scaffold(
        appBar: AppBar(title: const Text('آرشیو')),
        body: lists.isEmpty
            ? Center(child: Text('آرشیو خالی است', style: TextStyle(color: colors.muted, fontWeight: FontWeight.w800)))
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: lists.length,
                itemBuilder: (context, index) {
                  final list = lists[index];
                  return PremiumCard(
                    margin: const EdgeInsets.only(bottom: 12),
                    child: Row(children: [
                      Icon(Icons.inventory_2_rounded, color: colors.accent),
                      const SizedBox(width: 12),
                      Expanded(child: Text(list.title, style: TextStyle(color: colors.text, fontWeight: FontWeight.w900))),
                      TextButton(onPressed: () => data.archiveList(list.id, false), child: const Text('بازیابی')),
                      IconButton(onPressed: () => data.deleteList(list.id), icon: Icon(Icons.delete_outline, color: colors.danger)),
                    ]),
                  );
                },
              ),
      ),
    );
  }
}
