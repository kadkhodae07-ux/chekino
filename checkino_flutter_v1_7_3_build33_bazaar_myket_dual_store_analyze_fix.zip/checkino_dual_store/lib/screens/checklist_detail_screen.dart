import 'dart:io';

import 'package:flutter/material.dart';

import '../models/check_item.dart';
import '../services/data_controller.dart';
import '../services/reminder_service.dart';
import '../theme/app_theme.dart';
import '../utils/persian_numbers.dart';
import '../widgets/gradient_background.dart';
import '../widgets/premium_card.dart';
import '../widgets/progress_line.dart';
import '../widgets/section_title.dart';
import '../widgets/ad_widgets.dart';
import 'focus_screen.dart';
import 'form_helpers.dart';

class ChecklistDetailScreen extends StatefulWidget {
  const ChecklistDetailScreen({super.key, required this.listId});
  final String listId;

  @override
  State<ChecklistDetailScreen> createState() => _ChecklistDetailScreenState();
}

class _ChecklistDetailScreenState extends State<ChecklistDetailScreen> {
  bool _completedExpanded = true;
  String _filter = 'all';

  @override
  Widget build(BuildContext context) {
    final data = CheckinoDataScope.of(context);
    final list = data.listById(widget.listId);
    final colors = context.appColors;
    if (list == null) {
      return Scaffold(appBar: AppBar(title: const Text('پوشه پیدا نشد')));
    }
    final remaining = _filterItems(list.items.where((item) => !item.done).toList());
    final canReorder = _filter == 'all';
    final completed = list.items.where((item) => item.done).toList()..sort((a, b) => (b.completedAt ?? b.createdAt).compareTo(a.completedAt ?? a.createdAt));

    return GradientBackground(
      child: Scaffold(
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () async {
            final item = await showItemEditor(context);
            if (item != null) data.addItem(list.id, item);
          },
          icon: const Icon(Icons.add),
          label: const Text('آیتم'),
        ),
        body: SafeArea(
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          IconButton(onPressed: () => Navigator.pop(context), icon: Icon(Icons.arrow_back_rounded, color: colors.text)),
                          Expanded(child: Text(list.title, style: TextStyle(color: colors.text, fontSize: 24, fontWeight: FontWeight.w900))),
                          IconButton(
                            tooltip: 'حالت تمرکز',
                            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FocusScreen(listId: list.id))),
                            icon: Icon(Icons.center_focus_strong_rounded, color: colors.accent),
                          ),
                        ],
                      ),
                      PremiumCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(children: [
                              Expanded(child: Text('پیشرفت پوشه', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900))),
                              Text('${toPersianDigits(list.progressPercent)}٪', style: TextStyle(color: colors.accent, fontWeight: FontWeight.w900, fontSize: 20)),
                            ]),
                            const SizedBox(height: 12),
                            ProgressLine(value: list.progress, height: 10),
                            const SizedBox(height: 12),
                            Text('${toPersianDigits(list.completedItems)} از ${toPersianDigits(list.totalItems)} انجام شده', style: TextStyle(color: colors.muted)),
                            if (list.reminderEnabled) ...[
                              const SizedBox(height: 8),
                              Text('موعد: ${formatDateTimeFa(list.dueAt)}', style: TextStyle(color: colors.accent, fontWeight: FontWeight.w800)),
                              const SizedBox(height: 4),
                              Text('یادآور بعدی: ${formatDateTimeFa(list.nextReminderAt)}', style: TextStyle(color: colors.muted, fontWeight: FontWeight.w700)),
                              const SizedBox(height: 10),
                              Wrap(
                                spacing: 8,
                                runSpacing: 8,
                                children: [
                                  OutlinedButton.icon(
                                    onPressed: () async {
                                      await ReminderService.instance.scheduleForList(list);
                                      if (context.mounted) {
                                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('یادآور پوشه برای ${formatDateTimeFa(list.nextReminderAt)} دوباره ثبت شد')));
                                      }
                                    },
                                    icon: const Icon(Icons.sync),
                                    label: const Text('ثبت دوباره همین یادآور'),
                                  ),
                                  OutlinedButton.icon(
                                    onPressed: () async {
                                      await ReminderService.instance.scheduleQuickTestForList(list);
                                      if (context.mounted) {
                                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تست یادآور همین پوشه برای ۳۰ ثانیه بعد ثبت شد')));
                                      }
                                    },
                                    icon: const Icon(Icons.alarm_add),
                                    label: const Text('تست همین پوشه'),
                                  ),
                                ],
                              ),
                            ],
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      const AdBannerSlot(placement: 'checklist_detail_banner'),
                      const SizedBox(height: 12),
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        reverse: true,
                        child: Row(children: [
                          _filterChip('all', 'همه'),
                          _filterChip('today', 'امروز'),
                          _filterChip('overdue', 'عقب‌افتاده'),
                          _filterChip('important', 'مهم'),
                        ]),
                      ),
                      SectionTitle(title: 'باقیمانده', count: remaining.length),
                    ],
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                sliver: remaining.isEmpty
                    ? SliverToBoxAdapter(child: _SoftMessage(text: 'کار باقی‌مانده‌ای در این فیلتر نیست.'))
                    : canReorder
                        ? SliverReorderableList(
                            itemCount: remaining.length,
                            onReorderItem: (oldIndex, newIndex) => data.reorderItems(list.id, oldIndex, newIndex),
                            itemBuilder: (context, index) => _ItemTile(
                              key: ValueKey(remaining[index].id),
                              listId: list.id,
                              item: remaining[index],
                              index: index,
                              reorderable: true,
                            ),
                          )
                        : SliverList.builder(
                            itemCount: remaining.length,
                            itemBuilder: (context, index) => _ItemTile(listId: list.id, item: remaining[index], index: index),
                          ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                  child: SectionTitle(
                    title: 'انجام‌شده',
                    count: completed.length,
                    trailing: IconButton(
                      onPressed: () => setState(() => _completedExpanded = !_completedExpanded),
                      icon: Icon(_completedExpanded ? Icons.expand_less : Icons.expand_more, color: colors.muted),
                    ),
                  ),
                ),
              ),
              if (_completedExpanded)
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                  sliver: SliverList.builder(
                    itemCount: completed.length,
                    itemBuilder: (context, index) => _ItemTile(listId: list.id, item: completed[index], index: index),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  List<CheckItem> _filterItems(List<CheckItem> items) {
    return items.where((item) {
      if (_filter == 'today') return item.hasDueToday;
      if (_filter == 'overdue') return item.isOverdue;
      if (_filter == 'important') return item.priority == ItemPriority.high;
      return true;
    }).toList();
  }

  Widget _filterChip(String id, String title) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: ChoiceChip(selected: _filter == id, label: Text(title), onSelected: (_) => setState(() => _filter = id)),
    );
  }
}

class _ItemTile extends StatelessWidget {
  const _ItemTile({super.key, required this.listId, required this.item, required this.index, this.reorderable = false});
  final String listId;
  final CheckItem item;
  final int index;
  final bool reorderable;

  @override
  Widget build(BuildContext context) {
    final data = CheckinoDataScope.of(context);
    final colors = context.appColors;
    final lineStyle = TextStyle(
      color: item.done ? colors.mutedDark : colors.text,
      fontWeight: FontWeight.w900,
      decoration: item.done ? TextDecoration.lineThrough : null,
    );
    return PremiumCard(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      onTap: () => _showItemDetails(context),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Checkbox(value: item.done, onChanged: (_) => data.toggleItem(listId, item.id)),
          const SizedBox(width: 8),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(item.title, style: lineStyle)),
                _PriorityBadge(priority: item.priority),
              ]),
              const SizedBox(height: 6),
              Wrap(
                spacing: 7,
                runSpacing: 6,
                children: [
                  if (item.dueAt != null) _TinyInfo(icon: Icons.event, text: formatDateTimeFa(item.dueAt)),
                  if (item.repeatRule != RepeatRule.none) _TinyInfo(icon: Icons.repeat, text: item.repeatRule.title),
                  if (item.subTasks.isNotEmpty) _TinyInfo(icon: Icons.account_tree, text: '${toPersianDigits(item.completedSubTasks)}/${toPersianDigits(item.totalSubTasks)} زیرکار'),
                  if (item.imagePath != null) const _TinyInfo(icon: Icons.image, text: 'عکس'),
                  if (item.reminderEnabled) const _TinyInfo(icon: Icons.notifications_active, text: 'یادآور'),
                  if (item.isOverdue) const _TinyInfo(icon: Icons.warning, text: 'عقب‌افتاده'),
                ],
              ),
              if ((item.note ?? '').isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(item.note!, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: colors.muted, fontSize: 12)),
              ],
            ]),
          ),
          PopupMenuButton<String>(
            icon: Icon(Icons.more_vert, color: colors.muted),
            onSelected: (value) async {
              if (value == 'edit') {
                final result = await showItemEditor(context, item: item);
                if (result != null) data.updateItem(listId, result);
              } else if (value == 'delete') {
                final confirmed = await showDialog<bool>(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text('حذف آیتم؟'),
                    content: Text('«${item.title}» حذف می‌شود.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لغو')),
                      FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
                    ],
                  ),
                );
                if (confirmed == true) await data.deleteItem(listId, item.id);
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'edit', child: Text('ویرایش')),
              PopupMenuItem(value: 'delete', child: Text('حذف')),
            ],
          ),
          if (!item.done && reorderable) ReorderableDragStartListener(index: index, child: Icon(Icons.drag_indicator, color: colors.mutedDark)),
        ],
      ),
    );
  }

  CheckItem? _findCurrentItem(dynamic list, String id) {
    if (list == null) return null;
    for (final candidate in list.items) {
      if (candidate.id == id) return candidate;
    }
    return null;
  }

  void _showItemDetails(BuildContext context) {
    final data = CheckinoDataScope.of(context);
    final colors = context.appColors;
    final subTitle = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return StatefulBuilder(builder: (context, setSheetState) {
          final currentList = data.listById(listId);
          final currentItem = _findCurrentItem(currentList, item.id) ?? item;
          return SafeArea(
            child: Container(
              margin: const EdgeInsets.all(12),
              padding: EdgeInsets.only(left: 18, right: 18, top: 18, bottom: MediaQuery.of(context).viewInsets.bottom + 18),
              decoration: BoxDecoration(color: colors.card, borderRadius: BorderRadius.circular(30), border: Border.all(color: colors.border)),
              child: SingleChildScrollView(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                  Text(currentItem.title, style: TextStyle(color: colors.text, fontSize: 21, fontWeight: FontWeight.w900)),
                  if ((currentItem.note ?? '').isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Text(currentItem.note!, style: TextStyle(color: colors.muted)),
                  ],
                  if (currentItem.imagePath != null) ...[
                    const SizedBox(height: 14),
                    ClipRRect(borderRadius: BorderRadius.circular(18), child: Image.file(File(currentItem.imagePath!), height: 150, width: double.infinity, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(height: 100, color: colors.cardAlt, child: const Center(child: Text('عکس پیدا نشد'))))),
                  ],
                  const SizedBox(height: 18),
                  Text('زیرکارها', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 17)),
                  const SizedBox(height: 8),
                  ...currentItem.subTasks.map((sub) => CheckboxListTile(
                        value: sub.done,
                        onChanged: (_) async {
                          await data.toggleSubTask(listId, currentItem.id, sub.id);
                          setSheetState(() {});
                        },
                        title: Text(sub.title, style: TextStyle(decoration: sub.done ? TextDecoration.lineThrough : null)),
                        secondary: IconButton(
                          icon: Icon(Icons.delete_outline, color: colors.danger),
                          onPressed: () async {
                            await data.deleteSubTask(listId, currentItem.id, sub.id);
                            setSheetState(() {});
                          },
                        ),
                      )),
                  Row(children: [
                    Expanded(child: TextField(controller: subTitle, decoration: const InputDecoration(hintText: 'زیرکار جدید'))),
                    const SizedBox(width: 8),
                    FilledButton(
                      onPressed: () async {
                        await data.addSubTask(listId, currentItem.id, subTitle.text);
                        subTitle.clear();
                        setSheetState(() {});
                      },
                      child: const Text('افزودن'),
                    ),
                  ]),
                ]),
              ),
            ),
          );
        });
      },
    );
  }
}

class _PriorityBadge extends StatelessWidget {
  const _PriorityBadge({required this.priority});
  final ItemPriority priority;
  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final color = priority == ItemPriority.high ? colors.danger : priority == ItemPriority.low ? colors.success : colors.accent;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(99)),
      child: Text(priority.title, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 10)),
    );
  }
}

class _TinyInfo extends StatelessWidget {
  const _TinyInfo({required this.icon, required this.text});
  final IconData icon;
  final String text;
  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, color: colors.mutedDark, size: 13), const SizedBox(width: 4), Text(text, style: TextStyle(color: colors.mutedDark, fontSize: 11, fontWeight: FontWeight.w700))]);
  }
}

class _SoftMessage extends StatelessWidget {
  const _SoftMessage({required this.text});
  final String text;
  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: colors.cardAlt, borderRadius: BorderRadius.circular(22), border: Border.all(color: colors.border)),
      child: Center(child: Text(text, style: TextStyle(color: colors.muted, fontWeight: FontWeight.w800))),
    );
  }
}
