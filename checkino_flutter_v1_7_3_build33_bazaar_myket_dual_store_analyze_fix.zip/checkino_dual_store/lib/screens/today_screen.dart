import 'package:flutter/material.dart';

import '../services/data_controller.dart';
import '../theme/app_theme.dart';
import '../utils/persian_numbers.dart';
import '../widgets/gradient_background.dart';
import '../widgets/premium_card.dart';
import 'checklist_detail_screen.dart';

class TodayScreen extends StatelessWidget {
  const TodayScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final data = CheckinoDataScope.of(context);
    final colors = context.appColors;
    final tasks = data.todayTasks;
    final overdue = tasks.where((task) => task.item.isOverdue).toList();
    final today = tasks.where((task) => !task.item.isOverdue).toList();

    return GradientBackground(
      child: Scaffold(
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            children: [
              Text('امروز', style: TextStyle(color: colors.text, fontSize: 30, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text('کارهای زمان‌دار امروز و کارهای عقب‌افتاده را یکجا مدیریت کن.', style: TextStyle(color: colors.muted)),
              const SizedBox(height: 16),
              PremiumCard(
                child: Row(
                  children: [
                    Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(color: colors.accent.withValues(alpha: 0.16), borderRadius: BorderRadius.circular(18)),
                      child: Icon(Icons.today_rounded, color: colors.accent),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${toPersianDigits(tasks.length)} کار نیازمند توجه', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 18)),
                        const SizedBox(height: 4),
                        Text(
                          overdue.isEmpty ? 'همه‌چیز طبق برنامه است.' : '${toPersianDigits(overdue.length)} مورد از موعد گذشته است.',
                          style: TextStyle(color: overdue.isEmpty ? colors.success : colors.danger, fontWeight: FontWeight.w800),
                        ),
                      ]),
                    ),
                  ],
                ),
              ),
              if (tasks.isEmpty) ...[
                const SizedBox(height: 52),
                Icon(Icons.task_alt_rounded, color: colors.success, size: 76),
                const SizedBox(height: 14),
                Center(child: Text('برای امروز کار زمان‌داری نداری.', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 19))),
                const SizedBox(height: 8),
                Center(child: Text('برای نمایش در این بخش، برای آیتم تاریخ انتخاب کن.', style: TextStyle(color: colors.muted))),
              ] else ...[
                if (overdue.isNotEmpty) ...[
                  const SizedBox(height: 22),
                  _Heading(title: 'عقب‌افتاده', count: overdue.length, danger: true),
                  const SizedBox(height: 8),
                  ...overdue.map((task) => _TodayTaskCard(task: task)),
                ],
                if (today.isNotEmpty) ...[
                  const SizedBox(height: 18),
                  _Heading(title: 'امروز', count: today.length),
                  const SizedBox(height: 8),
                  ...today.map((task) => _TodayTaskCard(task: task)),
                ],
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _Heading extends StatelessWidget {
  const _Heading({required this.title, required this.count, this.danger = false});

  final String title;
  final int count;
  final bool danger;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final color = danger ? colors.danger : colors.accent;
    return Row(
      children: [
        Expanded(child: Text(title, style: TextStyle(color: colors.text, fontSize: 18, fontWeight: FontWeight.w900))),
        Text(toPersianDigits(count), style: TextStyle(color: color, fontWeight: FontWeight.w900)),
      ],
    );
  }
}

class _TodayTaskCard extends StatelessWidget {
  const _TodayTaskCard({required this.task});

  final TodayTask task;

  @override
  Widget build(BuildContext context) {
    final data = CheckinoDataScope.of(context);
    final colors = context.appColors;
    final item = task.item;
    final dueText = item.isOverdue ? 'عقب‌افتاده • ${formatDateTimeCompactFa(item.dueAt)}' : formatDateTimeCompactFa(item.dueAt);
    return PremiumCard(
      margin: const EdgeInsets.only(bottom: 10),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChecklistDetailScreen(listId: task.listId))),
      child: Row(
        children: [
          Checkbox(value: item.done, onChanged: (_) => data.toggleItem(task.listId, item.id)),
          const SizedBox(width: 6),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(item.title, style: TextStyle(color: colors.text, fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              Text(task.listTitle, style: TextStyle(color: colors.muted, fontSize: 12)),
              const SizedBox(height: 3),
              Text(dueText, style: TextStyle(color: item.isOverdue ? colors.danger : colors.accent, fontWeight: FontWeight.w800, fontSize: 12)),
            ]),
          ),
          Icon(Icons.chevron_left_rounded, color: colors.muted),
        ],
      ),
    );
  }
}
