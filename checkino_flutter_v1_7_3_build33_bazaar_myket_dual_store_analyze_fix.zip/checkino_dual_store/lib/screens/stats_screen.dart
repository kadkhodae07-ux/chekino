import 'package:flutter/material.dart';

import '../services/data_controller.dart';
import '../theme/app_theme.dart';
import '../utils/persian_numbers.dart';
import '../widgets/gradient_background.dart';
import '../widgets/premium_card.dart';
import '../widgets/progress_line.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final data = CheckinoDataScope.of(context);
    final colors = context.appColors;
    final stats = data.stats;
    final total = stats['total'] ?? 0;
    final done = stats['done'] ?? 0;
    final progress = total == 0 ? 0.0 : done / total;
    return GradientBackground(
      child: Scaffold(
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('آمار پیشرفت', style: TextStyle(color: colors.text, fontSize: 28, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text('نمای کلی از عملکرد و کارهای مهم.', style: TextStyle(color: colors.muted)),
              const SizedBox(height: 18),
              PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: Text('پیشرفت کل', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900))),
                  Text('${toPersianDigits((progress * 100).round())}٪', style: TextStyle(color: colors.accent, fontWeight: FontWeight.w900, fontSize: 22)),
                ]),
                const SizedBox(height: 12),
                ProgressLine(value: progress, height: 12),
              ])),
              const SizedBox(height: 14),
              GridView.count(
                shrinkWrap: true,
                crossAxisCount: 2,
                physics: const NeverScrollableScrollPhysics(),
                childAspectRatio: 1.25,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                children: [
                  _StatCard(title: 'کل کارها', value: total, icon: Icons.checklist),
                  _StatCard(title: 'انجام‌شده', value: done, icon: Icons.done_all),
                  _StatCard(title: 'امروز', value: stats['completedToday'] ?? 0, icon: Icons.today),
                  _StatCard(title: 'عقب‌افتاده', value: stats['overdue'] ?? 0, icon: Icons.warning),
                  _StatCard(title: 'مهم', value: stats['high'] ?? 0, icon: Icons.priority_high),
                  _StatCard(title: 'آرشیو', value: data.archivedLists.length, icon: Icons.inventory_2),
                ],
              ),
              const SizedBox(height: 14),
              PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('سیستم انگیزشی', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 18)),
                const SizedBox(height: 8),
                Text(done >= 10 ? 'عالیه؛ امروز خیلی جلو افتادی.' : 'چند کار کوچک انجام بده تا زنجیره‌ات قوی‌تر شود.', style: TextStyle(color: colors.muted)),
              ])),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.title, required this.value, required this.icon});
  final String title;
  final int value;
  final IconData icon;
  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return PremiumCard(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: colors.accent),
        const Spacer(),
        Text(toPersianDigits(value), style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 24)),
        Text(title, style: TextStyle(color: colors.muted, fontWeight: FontWeight.w800)),
      ]),
    );
  }
}
