import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MonetizationSettings {
  const MonetizationSettings({
    this.appOpenCount = 0,
    this.remotePro = false,
    this.remoteProUntil,
    this.remoteSubscriptionVerifiedAt,
    this.subscriptionSource,
  });

  final int appOpenCount;
  final bool remotePro;
  final DateTime? remoteProUntil;
  final DateTime? remoteSubscriptionVerifiedAt;
  final String? subscriptionSource;

  MonetizationSettings copyWith({
    int? appOpenCount,
    bool? remotePro,
    DateTime? remoteProUntil,
    DateTime? remoteSubscriptionVerifiedAt,
    String? subscriptionSource,
    bool clearRemoteProUntil = false,
    bool clearSubscriptionSource = false,
  }) {
    return MonetizationSettings(
      appOpenCount: appOpenCount ?? this.appOpenCount,
      remotePro: remotePro ?? this.remotePro,
      remoteProUntil: clearRemoteProUntil ? null : remoteProUntil ?? this.remoteProUntil,
      remoteSubscriptionVerifiedAt: remoteSubscriptionVerifiedAt ?? this.remoteSubscriptionVerifiedAt,
      subscriptionSource: clearSubscriptionSource ? null : subscriptionSource ?? this.subscriptionSource,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'appOpenCount': appOpenCount,
        'remotePro': remotePro,
        'remoteProUntil': remoteProUntil?.toUtc().toIso8601String(),
        'remoteSubscriptionVerifiedAt': remoteSubscriptionVerifiedAt?.toUtc().toIso8601String(),
        'subscriptionSource': subscriptionSource,
      };

  factory MonetizationSettings.fromJson(Map<String, dynamic> json) {
    final rawUntil = json['remoteProUntil'] as String?;
    final rawVerified = json['remoteSubscriptionVerifiedAt'] as String?;
    return MonetizationSettings(
      appOpenCount: json['appOpenCount'] as int? ?? 0,
      remotePro: json['remotePro'] as bool? ?? false,
      remoteProUntil: rawUntil == null ? null : DateTime.tryParse(rawUntil)?.toLocal(),
      remoteSubscriptionVerifiedAt: rawVerified == null ? null : DateTime.tryParse(rawVerified)?.toLocal(),
      subscriptionSource: json['subscriptionSource']?.toString(),
    );
  }
}

/// Stores only the most recently server-verified entitlement locally. The app
/// can therefore remain usable offline, while a monthly Bazaar subscription is
/// still confirmed by the backend whenever the device connects.
class MonetizationController extends ChangeNotifier {
  static const String _key = 'checkino_monetization_v3';
  static const String _legacyKey = 'checkino_monetization_v2';
  static const Duration offlineSubscriptionGrace = Duration(days: 7);

  MonetizationSettings _settings = const MonetizationSettings();
  bool _loaded = false;
  bool _pendingOpenInterstitial = false;

  bool get loaded => _loaded;
  MonetizationSettings get settings => _settings;
  bool get hasPendingOpenInterstitial => _pendingOpenInterstitial;
  String? get subscriptionSource => _settings.subscriptionSource;

  bool get isWithinOfflineGrace {
    final until = _settings.remoteProUntil;
    if (!_settings.remotePro || until == null || until.isAfter(DateTime.now())) return false;
    return DateTime.now().isBefore(until.add(offlineSubscriptionGrace));
  }

  bool get isPro {
    if (!_settings.remotePro) return false;
    final until = _settings.remoteProUntil;
    if (until == null || until.isAfter(DateTime.now())) return true;
    return isWithinOfflineGrace;
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key) ?? prefs.getString(_legacyKey);
    if (raw != null && raw.trim().isNotEmpty) {
      try {
        _settings = MonetizationSettings.fromJson(Map<String, dynamic>.from(jsonDecode(raw) as Map));
      } catch (_) {
        _settings = const MonetizationSettings();
      }
    }
    _loaded = true;
    if (prefs.containsKey(_legacyKey)) await prefs.remove(_legacyKey);
    notifyListeners();
  }

  Future<void> recordAppOpen() async {
    final nextCount = _settings.appOpenCount + 1;
    _settings = _settings.copyWith(appOpenCount: nextCount);
    _pendingOpenInterstitial = nextCount % 5 == 0;
    await _save();
  }

  Future<void> consumeOpenInterstitial() async {
    _pendingOpenInterstitial = false;
    notifyListeners();
  }

  bool needsRewardForNewList(int activeListCount) => false;

  String rewardReasonForNewList(int activeListCount) => '';

  Future<void> markRewardedListAllowed() async {
    // Kept as a no-op to preserve callers from older UI paths.
  }

  /// Applies the status returned by Checkino's backend after it has verified a
  /// Bazaar purchase token or performed a normal device sync.
  Future<void> setRemoteSubscription({
    required bool isPro,
    DateTime? expiresAt,
    String? source,
  }) async {
    final now = DateTime.now();
    final next = _settings.copyWith(
      remotePro: isPro,
      remoteProUntil: expiresAt,
      remoteSubscriptionVerifiedAt: now,
      subscriptionSource: source,
      clearRemoteProUntil: !isPro && expiresAt == null,
      clearSubscriptionSource: !isPro && (source == null || source.trim().isEmpty),
    );
    if (next.remotePro == _settings.remotePro &&
        next.remoteProUntil == _settings.remoteProUntil &&
        next.subscriptionSource == _settings.subscriptionSource) {
      return;
    }
    _settings = next;
    await _save();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(_settings.toJson()));
    notifyListeners();
  }
}
