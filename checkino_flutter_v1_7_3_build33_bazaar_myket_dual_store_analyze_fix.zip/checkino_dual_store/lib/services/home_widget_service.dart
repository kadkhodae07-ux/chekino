import 'package:flutter/services.dart';

class HomeWidgetService {
  HomeWidgetService._();

  static const MethodChannel _channel = MethodChannel('mk.kadkhodai.chekino/widget');

  static Future<void> refresh() async {
    try {
      await _channel.invokeMethod<void>('refreshWidget');
    } on MissingPluginException {
      // Non-Android platforms and debug environments can safely ignore this.
    } on PlatformException {
      // Widget refresh must never block saving a checklist item.
    }
  }
}
