import 'dart:async';
import 'dart:math';

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

import '../models/check_item.dart';
import '../models/check_list.dart';
import '../utils/persian_numbers.dart';

typedef NotificationTapHandler = void Function(String payload);

class ReminderPermissionStatus {
  const ReminderPermissionStatus({required this.notificationsEnabled, required this.pendingCount});

  final bool? notificationsEnabled;
  final int pendingCount;
}

class ReminderService {
  ReminderService._();
  static final ReminderService instance = ReminderService._();

  static const String _channelId = 'checkino_task_reminders_v4';
  static const String _channelName = 'یادآورهای چکینو';
  static const String _channelDescription = 'یادآورهای زمان‌دار برای چک‌لیست‌ها و کارهای چکینو';

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;
  NotificationTapHandler? _tapHandler;
  String? _pendingPayload;

  Future<void> initialize() async {
    if (_initialized) return;

    tz.initializeTimeZones();
    await _configureLocalTimezone();

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const ios = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    const settings = InitializationSettings(android: android, iOS: ios);

    await _plugin.initialize(settings, onDidReceiveNotificationResponse: _onNotificationResponse);
    final launchDetails = await _plugin.getNotificationAppLaunchDetails();
    if (launchDetails?.didNotificationLaunchApp ?? false) {
      _pendingPayload = launchDetails?.notificationResponse?.payload;
    }
    await _createAndroidChannel();
    await requestPermissions();
    _initialized = true;
  }

  void setNotificationTapHandler(NotificationTapHandler handler) {
    _tapHandler = handler;
    final pending = _pendingPayload;
    if (pending != null && pending.isNotEmpty) {
      _pendingPayload = null;
      Future.microtask(() => handler(pending));
    }
  }

  void _onNotificationResponse(NotificationResponse response) {
    final payload = response.payload;
    if (payload == null || payload.isEmpty) return;
    final handler = _tapHandler;
    if (handler == null) {
      _pendingPayload = payload;
    } else {
      handler(payload);
    }
  }

  Future<void> _configureLocalTimezone() async {
    try {
      final name = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(name));
    } catch (_) {
      tz.setLocalLocation(tz.getLocation('Asia/Tehran'));
    }
  }

  Future<void> _createAndroidChannel() async {
    const channel = AndroidNotificationChannel(
      _channelId,
      _channelName,
      description: _channelDescription,
      importance: Importance.max,
      playSound: true,
      enableVibration: true,
      showBadge: true,
    );

    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
  }

  Future<void> requestPermissions() async {
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    final ios = _plugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();
    final mac = _plugin.resolvePlatformSpecificImplementation<MacOSFlutterLocalNotificationsPlugin>();

    await android?.requestNotificationsPermission();
    try {
      await (android as dynamic)?.requestExactAlarmsPermission();
    } catch (_) {
      // Exact alarm permission does not exist on some Android/plugin versions.
    }

    await ios?.requestPermissions(alert: true, badge: true, sound: true);
    await mac?.requestPermissions(alert: true, badge: true, sound: true);
  }

  Future<ReminderPermissionStatus> status() async {
    await initialize();
    bool? enabled;
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    try {
      enabled = await (android as dynamic)?.areNotificationsEnabled();
    } catch (_) {
      enabled = null;
    }
    final pending = await _plugin.pendingNotificationRequests();
    return ReminderPermissionStatus(notificationsEnabled: enabled, pendingCount: pending.length);
  }

  List<String> debugLinesForLists(List<CheckListModel> lists) {
    final lines = <String>[];
    for (final list in lists.where((list) => list.reminderEnabled)) {
      lines.add('${list.title} | ${formatDateTimeFa(list.nextReminderAt)}');
    }
    final itemCount = lists.expand((list) => list.items).where((item) => item.canScheduleReminder).length;
    if (itemCount > 0) lines.add('${toPersianDigits(itemCount)} یادآور آیتمی فعال است.');
    return lines.isEmpty ? ['هیچ یادآور فعالی ثبت نشده است.'] : lines;
  }

  Future<void> syncLists(List<CheckListModel> lists) async {
    await initialize();
    final activeIds = <int>{};
    for (final list in lists) {
      activeIds.add(list.reminderNotificationId);
      await scheduleForList(list, cancelPrevious: true);
      for (final item in list.items) {
        activeIds.add(item.reminderNotificationId);
        await scheduleForItem(list, item, cancelPrevious: true);
      }
    }
    await _cancelStaleManagedNotifications(activeIds);
  }

  Future<void> _cancelStaleManagedNotifications(Set<int> activeIds) async {
    final pending = await _plugin.pendingNotificationRequests();
    for (final request in pending) {
      if (_isManagedId(request.id) && !activeIds.contains(request.id)) {
        await _plugin.cancel(request.id);
      }
    }
  }

  bool _isManagedId(int id) => id >= 100000000 && id < 300000000;

  Future<bool> scheduleForList(CheckListModel list, {bool cancelPrevious = true}) async {
    await initialize();
    if (cancelPrevious) await _plugin.cancel(list.reminderNotificationId);
    if (list.archived || !list.reminderEnabled) return false;

    final dueAt = list.dueAt;
    final scheduledAt = list.nextReminderAt;
    if (dueAt == null || scheduledAt == null) return false;

    final body = 'موعد «${list.title}» ${formatDateTimeFa(dueAt)} است.';
    return _zonedScheduleWithFallback(
      id: list.reminderNotificationId,
      title: 'یادآور چک‌لیست',
      body: body,
      when: scheduledAt,
      payload: 'list:${list.id}',
    );
  }

  Future<bool> scheduleForItem(CheckListModel list, CheckItem item, {bool cancelPrevious = true}) async {
    await initialize();
    if (cancelPrevious) await _plugin.cancel(item.reminderNotificationId);
    if (list.archived || !item.canScheduleReminder || item.dueAt == null) return false;
    return _zonedScheduleWithFallback(
      id: item.reminderNotificationId,
      title: 'یادآور کار',
      body: '«${item.title}» در چک‌لیست «${list.title}» موعد دارد.',
      when: item.dueAt!,
      payload: 'item:${list.id}:${item.id}',
    );
  }

  Future<void> cancelForList(CheckListModel list) async {
    await initialize();
    await _plugin.cancel(list.reminderNotificationId);
    await _plugin.cancel(_testNotificationIdForList(list));
    for (final item in list.items) {
      await cancelForItem(item);
    }
  }

  Future<void> cancelForItem(CheckItem item) async {
    await initialize();
    await _plugin.cancel(item.reminderNotificationId);
  }

  Future<void> showTestNotification() async {
    await initialize();
    await _plugin.show(
      900000 + Random().nextInt(99999),
      'تست نوتیفیکیشن چکینو',
      'اگر این پیام را می‌بینی، نوتیفیکیشن برنامه فعال است.',
      _notificationDetails(),
      payload: 'test',
    );
  }

  Future<void> scheduleTestNotification() async {
    await initialize();
    final when = DateTime.now().add(const Duration(seconds: 10));
    await _zonedScheduleWithFallback(
      id: 990001,
      title: 'تست یادآور چکینو',
      body: 'این یادآور آزمایشی ۱۰ ثانیه قبل ثبت شد.',
      when: when,
      payload: 'scheduled_test',
    );
  }

  Future<void> scheduleQuickTestForList(CheckListModel list) async {
    await initialize();
    final when = DateTime.now().add(const Duration(seconds: 30));
    await _zonedScheduleWithFallback(
      id: _testNotificationIdForList(list),
      title: 'تست یادآور پوشه',
      body: 'یادآور آزمایشی برای «${list.title}» با زمان‌بندی واقعی ثبت شد.',
      when: when,
      payload: 'list:${list.id}',
    );
  }

  Future<bool> _zonedScheduleWithFallback({
    required int id,
    required String title,
    required String body,
    required DateTime when,
    String? payload,
  }) async {
    final safeWhen = when.isAfter(DateTime.now().add(const Duration(seconds: 3)))
        ? when
        : DateTime.now().add(const Duration(seconds: 8));
    final tzWhen = tz.TZDateTime.from(safeWhen, tz.local);

    try {
      await _plugin.zonedSchedule(
        id,
        title,
        body,
        tzWhen,
        _notificationDetails(),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        payload: payload,
      );
      return true;
    } catch (_) {
      try {
        await _plugin.zonedSchedule(
          id,
          title,
          body,
          tzWhen,
          _notificationDetails(),
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
          payload: payload,
        );
        return true;
      } catch (_) {
        return false;
      }
    }
  }

  NotificationDetails _notificationDetails() {
    const android = AndroidNotificationDetails(
      _channelId,
      _channelName,
      channelDescription: _channelDescription,
      importance: Importance.max,
      priority: Priority.max,
      visibility: NotificationVisibility.private,
      category: AndroidNotificationCategory.reminder,
      playSound: true,
      enableVibration: true,
      ticker: 'checkino_reminder',
    );
    const ios = DarwinNotificationDetails(presentAlert: true, presentBadge: true, presentSound: true);
    return const NotificationDetails(android: android, iOS: ios);
  }

  int _testNotificationIdForList(CheckListModel list) {
    return 700000000 + (list.reminderNotificationId % 100000000);
  }
}
