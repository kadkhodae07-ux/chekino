import 'dart:async';
import 'dart:io';

import 'package:myket_iap/myket_iap.dart';
import 'package:myket_iap/util/iab_result.dart';
import 'package:myket_iap/util/inventory.dart';
import 'package:myket_iap/util/purchase.dart';
import 'package:myket_iap/util/sku_details.dart';

import '../config/store_environment.dart';

/// Android-only adapter around Myket's official Flutter IAP bridge.
///
/// Myket's public RSA key must be injected only into the Myket build through:
/// --dart-define=CHECKINO_MYKET_RSA_KEY=<public key from Myket panel>
class MyketBillingService {
  MyketBillingService._();

  static final MyketBillingService instance = MyketBillingService._();

  /// Create this exact product id in Myket developer panel.
  ///
  /// Myket IAP uses `inapp` products. For monthly access, Checkino's server
  /// must verify the token, grant 30 days of Pro, then the app consumes the
  /// purchase so the user can renew next month.
  static const String monthlyProductId = StoreEnvironment.myketProductId;

  static const String publicRsaKey = StoreEnvironment.myketPublicRsaKey;

  static const Duration _connectTimeout = Duration(seconds: 12);
  static const Duration _purchaseUiTimeout = Duration(seconds: 25);
  static const Duration _inventoryTimeout = Duration(seconds: 15);
  static const Duration _consumeTimeout = Duration(seconds: 12);

  bool _connected = false;
  Future<void>? _connecting;
  final Map<String, Purchase> _pendingPurchasesByToken = <String, Purchase>{};

  bool get isAndroid => Platform.isAndroid;
  bool get isConnected => _connected;

  Future<void> connect({void Function(String message)? onProgress}) {
    if (!Platform.isAndroid) {
      return Future<void>.error(
        const MyketBillingException('خرید مایکت فقط در نسخه اندروید قابل استفاده است.'),
      );
    }
    if (publicRsaKey.trim().isEmpty) {
      return Future<void>.error(
        const MyketBillingException('کلید عمومی پرداخت مایکت در این خروجی تنظیم نشده است.'),
      );
    }
    if (_connected) {
      onProgress?.call('اتصال به مایکت برقرار است.');
      return Future<void>.value();
    }
    onProgress?.call('در حال اتصال به برنامه مایکت...');
    return _connecting ??= _connectInternal();
  }

  Future<void> _connectInternal() async {
    try {
      final IabResult? result = await MyketIAP
          .init(rsaKey: publicRsaKey, enableDebugLogging: false)
          .timeout(
            _connectTimeout,
            onTimeout: () => throw const MyketBillingException(
              'مایکت در زمان مقرر پاسخ نداد. مایکت را باز و به‌روز کن، با حساب خود وارد شو و دوباره تلاش کن.',
            ),
          );
      if (result?.isFailure() == true) {
        throw MyketBillingException(_friendlyResult(result));
      }
      _connected = true;
    } on MyketBillingException {
      _connected = false;
      rethrow;
    } on TimeoutException {
      _connected = false;
      throw const MyketBillingException('زمان اتصال به مایکت تمام شد. از نصب و به‌روز بودن مایکت مطمئن شو.');
    } catch (error) {
      _connected = false;
      throw MyketBillingException(_friendlyError(error));
    } finally {
      _connecting = null;
    }
  }

  Future<MyketProductInfo> checkMonthlyProduct({void Function(String message)? onProgress}) async {
    await connect(onProgress: onProgress);
    onProgress?.call('در حال بررسی محصول اشتراک در مایکت...');
    return _loadMonthlyProduct();
  }

  Future<MyketPurchaseReceipt> purchaseMonthly({void Function(String message)? onProgress}) async {
    await connect(onProgress: onProgress);
    onProgress?.call('در حال بررسی محصول اشتراک در مایکت...');
    await _loadMonthlyProduct();
    onProgress?.call('در حال باز کردن صفحه پرداخت مایکت...');

    try {
      final resultMap = await MyketIAP
          .launchPurchaseFlow(
            sku: monthlyProductId,
            payload: 'checkino_myket_monthly_access',
          )
          .timeout(
            _purchaseUiTimeout,
            onTimeout: () => throw const MyketBillingException(
              'صفحه پرداخت مایکت باز نشد. مایکت را باز و به‌روز کن، با همان حساب وارد شو و دوباره تلاش کن.',
            ),
          );
      final IabResult? result = resultMap[MyketIAP.RESULT] as IabResult?;
      if (result?.isFailure() == true) throw MyketBillingException(_friendlyResult(result));
      final Purchase? purchase = resultMap[MyketIAP.PURCHASE] as Purchase?;
      final receipt = _receiptFrom(purchase);
      if (purchase != null && receipt.purchaseToken.isNotEmpty) {
        _pendingPurchasesByToken[receipt.purchaseToken] = purchase;
      }
      return receipt;
    } on MyketBillingException {
      rethrow;
    } on TimeoutException {
      throw const MyketBillingException('مایکت تا ۲۵ ثانیه پاسخ نداد. اتصال اینترنت و برنامه مایکت را بررسی کن.');
    } catch (error) {
      throw MyketBillingException(_friendlyError(error));
    }
  }

  Future<List<MyketPurchaseReceipt>> restoreMonthlyPurchases({void Function(String message)? onProgress}) async {
    await connect(onProgress: onProgress);
    onProgress?.call('در حال بررسی خریدهای قبلی در مایکت...');
    try {
      final Inventory? inventory = await _queryInventory(querySkuDetails: false);
      final Purchase? purchase = inventory?.mPurchaseMap[monthlyProductId];
      if (purchase == null) return const <MyketPurchaseReceipt>[];
      final receipt = _receiptFrom(purchase, allowMissingToken: true);
      if (receipt.productId != monthlyProductId || receipt.purchaseToken.isEmpty) return const <MyketPurchaseReceipt>[];
      _pendingPurchasesByToken[receipt.purchaseToken] = purchase;
      return <MyketPurchaseReceipt>[receipt];
    } on MyketBillingException {
      rethrow;
    } on TimeoutException {
      throw const MyketBillingException('زمان بررسی خریدهای مایکت تمام شد.');
    } catch (error) {
      throw MyketBillingException(_friendlyError(error));
    }
  }

  Future<void> consumeMonthlyPurchase(MyketPurchaseReceipt receipt) async {
    if (receipt.purchaseToken.trim().isEmpty) return;
    await connect();
    Purchase? purchase = _pendingPurchasesByToken.remove(receipt.purchaseToken);
    purchase ??= await _lookupOwnedMonthlyPurchase();
    if (purchase == null) return;
    final purchaseToken = purchase.mToken.trim();
    if (purchaseToken.isNotEmpty && purchaseToken != receipt.purchaseToken) return;

    try {
      final resultMap = await MyketIAP
          .consume(purchase: purchase)
          .timeout(
            _consumeTimeout,
            onTimeout: () => throw const MyketBillingException('مایکت در مصرف خرید پاسخ نداد.'),
          );
      final IabResult? result = resultMap[MyketIAP.RESULT] as IabResult?;
      if (result?.isFailure() == true) throw MyketBillingException(_friendlyResult(result));
    } on MyketBillingException {
      rethrow;
    } catch (error) {
      throw MyketBillingException(_friendlyError(error));
    }
  }

  Future<MyketProductInfo> _loadMonthlyProduct() async {
    try {
      final Inventory? inventory = await _queryInventory(querySkuDetails: true);
      final SkuDetails? details = inventory?.mSkuMap[monthlyProductId];
      if (details == null) {
        throw const MyketBillingException(
          'محصول اشتراک ماهانه در مایکت پیدا نشد. فعال بودن محصول و انتشار یا کانال تست این نسخه را بررسی کن.',
        );
      }
      return MyketProductInfo(
        productId: details.mSku,
        title: details.mTitle,
        price: details.mPrice,
      );
    } on MyketBillingException {
      rethrow;
    } on TimeoutException {
      throw const MyketBillingException('زمان دریافت اطلاعات محصول مایکت تمام شد.');
    } catch (error) {
      throw MyketBillingException(_friendlyError(error));
    }
  }

  Future<Inventory?> _queryInventory({required bool querySkuDetails}) async {
    final resultMap = await MyketIAP
        .queryInventory(querySkuDetails: querySkuDetails, skus: <String>[monthlyProductId])
        .timeout(
          _inventoryTimeout,
          onTimeout: () => throw const MyketBillingException('مایکت در بررسی محصول پاسخ نداد.'),
        );
    final IabResult? result = resultMap[MyketIAP.RESULT] as IabResult?;
    if (result?.isFailure() == true) throw MyketBillingException(_friendlyResult(result));
    return resultMap[MyketIAP.INVENTORY] as Inventory?;
  }

  Future<Purchase?> _lookupOwnedMonthlyPurchase() async {
    final inventory = await _queryInventory(querySkuDetails: false);
    return inventory?.mPurchaseMap[monthlyProductId];
  }

  MyketPurchaseReceipt _receiptFrom(Purchase? value, {bool allowMissingToken = false}) {
    if (value == null) throw const MyketBillingException('رسید خرید از مایکت دریافت نشد.');
    final productId = value.mSku.trim();
    final purchaseToken = value.mToken.trim();
    if (productId != monthlyProductId) {
      throw const MyketBillingException('محصول بازگشتی مایکت با اشتراک ماهانه چکینو یکسان نیست.');
    }
    if (!allowMissingToken && purchaseToken.isEmpty) {
      throw const MyketBillingException('توکن معتبر خرید از مایکت دریافت نشد.');
    }
    return MyketPurchaseReceipt(
      productId: productId,
      purchaseToken: purchaseToken,
      orderId: value.mOrderId,
      purchaseTime: value.mPurchaseTime == 0 ? null : value.mPurchaseTime.toString(),
      packageName: value.mPackageName,
      developerPayload: value.mDeveloperPayload,
      signature: value.mSignature,
      originalJson: value.mOriginalJson,
    );
  }

  String _friendlyResult(IabResult? result) {
    final message = result?.mMessage.trim() ?? '';
    switch (result?.mResponse) {
      case 1:
        return 'پرداخت توسط کاربر لغو شد.';
      case 3:
        return 'خرید درون‌برنامه‌ای روی این نسخه مایکت پشتیبانی نمی‌شود.';
      case 4:
        return 'محصول اشتراک برای این نسخه در مایکت در دسترس نیست. فعال بودن محصول و کانال تست/انتشار را بررسی کن.';
      case 5:
        return 'پارامترهای پرداخت مایکت معتبر نیست. شناسه محصول و کلید عمومی مایکت را بررسی کن.';
      case 6:
        return 'مایکت خطای ارتباطی یا داخلی برگرداند. اینترنت و برنامه مایکت را بررسی کن.';
      case 7:
        return 'این خرید در حساب مایکت قبلاً ثبت شده است. گزینه بازیابی خرید را بزن.';
      case 8:
        return 'این محصول در حساب مایکت خریداری نشده است.';
    }
    return message.isEmpty ? 'خرید مایکت انجام نشد. دوباره تلاش کن.' : message;
  }

  String _friendlyError(Object error) {
    final raw = error.toString();
    final normalized = raw.toLowerCase();
    if (normalized.contains('cancel')) return 'پرداخت توسط کاربر لغو شد.';
    if (normalized.contains('not installed') || normalized.contains('market not found')) {
      return 'برنامه مایکت روی گوشی پیدا نشد. ابتدا مایکت را نصب یا به‌روز کن.';
    }
    if (normalized.contains('connection') || normalized.contains('billing unavailable')) {
      return 'اتصال به مایکت برقرار نشد. اینترنت، نصب بودن مایکت و ورود به حساب مایکت را بررسی کن.';
    }
    if (normalized.contains('item unavailable') || normalized.contains('sku') || normalized.contains('product not found')) {
      return 'محصول اشتراک برای این نسخه در مایکت در دسترس نیست. فعال بودن محصول و کانال تست/انتشار را بررسی کن.';
    }
    if (normalized.contains('signature')) return 'اعتبارسنجی رسید خرید مایکت ناموفق بود.';
    return raw.isEmpty || raw == 'Exception' ? 'خرید مایکت انجام نشد. دوباره تلاش کن.' : raw;
  }
}

class MyketProductInfo {
  const MyketProductInfo({required this.productId, required this.title, required this.price});

  final String productId;
  final String title;
  final String price;
}

class MyketPurchaseReceipt {
  const MyketPurchaseReceipt({
    required this.productId,
    required this.purchaseToken,
    this.orderId,
    this.purchaseTime,
    this.packageName,
    this.developerPayload,
    this.signature,
    this.originalJson,
  });

  final String productId;
  final String purchaseToken;
  final String? orderId;
  final String? purchaseTime;
  final String? packageName;
  final String? developerPayload;
  final String? signature;
  final String? originalJson;

  Map<String, dynamic> toServerJson() => <String, dynamic>{
        'store': 'myket',
        'productId': productId,
        'purchaseToken': purchaseToken,
        if (orderId != null && orderId!.isNotEmpty) 'orderId': orderId,
        if (purchaseTime != null && purchaseTime!.isNotEmpty) 'purchaseTime': purchaseTime,
        if (packageName != null && packageName!.isNotEmpty) 'packageName': packageName,
        if (developerPayload != null && developerPayload!.isNotEmpty) 'developerPayload': developerPayload,
        if (signature != null && signature!.isNotEmpty) 'signature': signature,
        if (originalJson != null && originalJson!.isNotEmpty) 'originalJson': originalJson,
      };
}

class MyketBillingException implements Exception {
  const MyketBillingException(this.message);

  final String message;

  @override
  String toString() => message;
}
