import 'dart:async';

import 'package:adivery/adivery.dart';
import 'package:flutter/foundation.dart';

class AdiveryAdConfig {
  const AdiveryAdConfig._();

  static const String appId = 'b30e3139-2c31-4d91-827b-e129bd2c2505';
  static const String bannerPlacementId = '0aae1ee2-0edd-4dcb-b1b2-682355bd727d';
  static const String interstitialPlacementId = 'd6075646-b4c1-44e0-8dff-40bd57ddc6fa';
  static const String nativePlacementId = '18939eee-007d-4fac-a7ed-8617a34e6ce9';
  static const String rewardedPlacementId = 'ec3b7137-bba1-4e25-a923-a6455f0b4398';
}

class AdiveryAdsService {
  AdiveryAdsService._();

  static final AdiveryAdsService instance = AdiveryAdsService._();

  bool _initialized = false;
  Completer<bool>? _rewardedCompleter;

  bool get isInitialized => _initialized;

  Future<void> initialize() async {
    if (_initialized) return;
    try {
      AdiveryPlugin.initialize(AdiveryAdConfig.appId);
      AdiveryPlugin.setLoggingEnabled(kDebugMode);
      AdiveryPlugin.addListener(
        onInterstitialClosed: (placement) {
          if (placement == AdiveryAdConfig.interstitialPlacementId) {
            prepareInterstitial();
          }
        },
        onRewardedClosed: (placement, isRewarded) {
          if (placement == AdiveryAdConfig.rewardedPlacementId) {
            _completeRewarded(isRewarded);
            prepareRewarded();
          }
        },
        onError: (placement, reason) {
          if (kDebugMode) {
            debugPrint('Adivery error [$placement]: $reason');
          }
          if (placement == AdiveryAdConfig.rewardedPlacementId) {
            _completeRewarded(false);
          }
        },
      );
      _initialized = true;
      prepareInterstitial();
      prepareRewarded();
    } catch (error, stackTrace) {
      if (kDebugMode) {
        debugPrint('Adivery initialize failed: $error');
        debugPrintStack(stackTrace: stackTrace);
      }
    }
  }

  void prepareInterstitial() {
    if (!_initialized) return;
    try {
      AdiveryPlugin.prepareInterstitialAd(AdiveryAdConfig.interstitialPlacementId);
    } catch (error) {
      if (kDebugMode) debugPrint('Adivery prepare interstitial failed: $error');
    }
  }

  void prepareRewarded() {
    if (!_initialized) return;
    try {
      AdiveryPlugin.prepareRewardedAd(AdiveryAdConfig.rewardedPlacementId);
    } catch (error) {
      if (kDebugMode) debugPrint('Adivery prepare rewarded failed: $error');
    }
  }

  Future<bool> showInterstitial() async {
    if (!_initialized) return false;
    try {
      final loaded = await AdiveryPlugin.isLoaded(AdiveryAdConfig.interstitialPlacementId) == true;
      if (!loaded) {
        prepareInterstitial();
        return false;
      }
      AdiveryPlugin.show(AdiveryAdConfig.interstitialPlacementId);
      return true;
    } catch (error) {
      if (kDebugMode) debugPrint('Adivery show interstitial failed: $error');
      return false;
    }
  }

  Future<bool> showRewarded() async {
    if (!_initialized) return false;
    try {
      final loaded = await AdiveryPlugin.isLoaded(AdiveryAdConfig.rewardedPlacementId) == true;
      if (!loaded) {
        prepareRewarded();
        return false;
      }

      _rewardedCompleter?.complete(false);
      _rewardedCompleter = Completer<bool>();
      AdiveryPlugin.show(AdiveryAdConfig.rewardedPlacementId);
      return _rewardedCompleter!.future.timeout(
        const Duration(minutes: 3),
        onTimeout: () {
          _rewardedCompleter = null;
          return false;
        },
      );
    } catch (error) {
      if (kDebugMode) debugPrint('Adivery show rewarded failed: $error');
      _completeRewarded(false);
      return false;
    }
  }

  void _completeRewarded(bool value) {
    final completer = _rewardedCompleter;
    if (completer != null && !completer.isCompleted) {
      completer.complete(value);
    }
    _rewardedCompleter = null;
  }
}
