import 'dart:convert';

import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../theme/app_theme.dart';

class ThemeSettingsController extends ChangeNotifier {
  static const String _key = 'checkino_theme_settings_v1';

  CheckinoThemeSettings _settings = const CheckinoThemeSettings();
  CheckinoThemeSettings get settings => _settings;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw != null && raw.trim().isNotEmpty) {
      try {
        _settings = CheckinoThemeSettings.fromJson(Map<String, dynamic>.from(jsonDecode(raw) as Map));
      } catch (_) {
        _settings = const CheckinoThemeSettings();
      }
    }
    notifyListeners();
  }

  Future<void> setAppearance(CheckinoAppearance appearance) async {
    _settings = _settings.copyWith(appearance: appearance);
    notifyListeners();
    await _save();
  }

  Future<void> setAccent(CheckinoAccent accent) async {
    _settings = _settings.copyWith(accent: accent);
    notifyListeners();
    await _save();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(_settings.toJson()));
  }
}

class CheckinoSettings extends InheritedNotifier<ThemeSettingsController> {
  const CheckinoSettings({super.key, required ThemeSettingsController controller, required super.child}) : super(notifier: controller);

  static ThemeSettingsController of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<CheckinoSettings>();
    assert(scope != null, 'CheckinoSettings not found');
    return scope!.notifier!;
  }
}
