import 'dart:async';
import 'dart:io';

import 'package:flutter_poolakey/flutter_poolakey.dart';

import '../config/store_environment.dart';

/// Android-only adapter around Cafe Bazaar's Poolakey Flutter bridge.
///
/// The RSA key is public and is used by Bazaar's client SDK. Subscription
/// access is still granted only after server-side verification succeeds.
class BazaarBillingService {
  BazaarBillingService._();

  static final BazaarBillingService instance = BazaarBillingService._();

  static const String monthlyProductId = StoreEnvironment.bazaarProductId;
  static const String publicRsaKey = StoreEnvironment.bazaarPublicRsaKey;

  static const Duration _connectTimeout = Duration(seconds: 12);
  static const Duration _productLookupTimeout = Duration(seconds: 12);
  static const Duration _purchaseUiTimeout = Duration(seconds: 25);
  static const Duration _inventoryTimeout = Duration(seconds: 15);

  bool _connected = false;
  Future<void>? _connecting;

  bool get isAndroid => Platform.isAndroid;
  bool get isConnected => _connected;

  /// Connects to the Bazaar app. Poolakey can occasionally leave its connect
  /// Future pending, so the callback and the initial call are deliberately
  /// guarded by one deterministic timeout.
  Future<void> connect({void Function(String message)? onProgress}) {
    if (!Platform.isAndroid) {
      return Future<void>.error(
        const BazaarBillingException('خرید بازار فقط در نسخه اندروید قابل استفاده است.'),
      );
    }
    if (_connected) {
      onProgress?.call('اتصال به بازار برقرار است.');
      return Future<void>.value();
    }
    onProgress?.call('در حال اتصال به برنامه بازار...');
    return _connecting ??= _connectInternal();
  }

  Future<void> _connectInternal() async {
    final completer = Completer<void>();
    var acceptCallbacks = true;

    Future<void> invokeConnection() async {
      try {
        await FlutterPoolakey.connect(
          publicRsaKey,
          onSucceed: () {
            if (!acceptCallbacks) return;
            _connected = true;
            if (!completer.isCompleted) completer.complete();
          },
          onFailed: () {
            if (!acceptCallbacks) return;
            _connected = false;
            if (!completer.isCompleted) {
              completer.completeError(
                const BazaarBillingException('ارتباط با برنامه بازار برقرار نشد.'),
              );
            }
          },
          onDisconnected: () {
            if (!acceptCallbacks) return;
            _connected = false;
          },
        );
      } catch (error) {
        if (!acceptCallbacks) return;
        _connected = false;
        if (!completer.isCompleted) {
          completer.completeError(BazaarBillingException(_friendlyError(error)));
        }
      }
    }

    try {
      // Do not await this call before starting the timeout. Some Poolakey
      // versions can keep the returned Future pending without invoking a
      // callback; waiting on the completer gives the user a deterministic exit.
      unawaited(invokeConnection());
      await completer.future.timeout(
        _connectTimeout,
        onTimeout: () => throw const BazaarBillingException(
          'بازار در زمان مقرر پاسخ نداد. بازار را باز و به‌روز کن، با حساب خود وارد شو و دوباره تلاش کن.',
        ),
      );
    } on BazaarBillingException {
      rethrow;
    } on TimeoutException {
      throw const BazaarBillingException(
        'زمان اتصال به بازار تمام شد. از نصب و به‌روز بودن بازار مطمئن شو.',
      );
    } catch (error) {
      throw BazaarBillingException(_friendlyError(error));
    } finally {
      acceptCallbacks = false;
      _connecting = null;
    }
  }

  /// Checks the product visibility before opening Bazaar's purchase sheet.
  /// This turns a silent spinner into a concrete error when the product is not
  /// active, the signed build does not match Bazaar's listing, or Bazaar cannot
  /// provide the subscription SKU to this device.
  Future<BazaarProductInfo> checkMonthlyProduct({
    void Function(String message)? onProgress,
  }) async {
    await connect(onProgress: onProgress);
    onProgress?.call('در حال بررسی محصول اشتراک در بازار...');
    return _loadMonthlyProduct();
  }

  Future<BazaarSubscriptionReceipt> purchaseMonthly({
    void Function(String message)? onProgress,
  }) async {
    await connect(onProgress: onProgress);
    onProgress?.call('در حال بررسی محصول اشتراک در بازار...');
    await _loadMonthlyProduct();
    onProgress?.call('در حال باز کردن صفحه پرداخت بازار...');

    try {
      final dynamic result = await FlutterPoolakey
          .subscribe(
            monthlyProductId,
            payload: 'checkino_monthly_subscription',
            dynamicPriceToken: '',
          )
          .timeout(
            _purchaseUiTimeout,
            onTimeout: () => throw const BazaarBillingException(
              'صفحه پرداخت بازار باز نشد. بازار را باز و به‌روز کن، با همان حساب وارد شو و دوباره تلاش کن.',
            ),
          );
      return _receiptFrom(result);
    } on BazaarBillingException {
      rethrow;
    } on TimeoutException {
      throw const BazaarBillingException(
        'بازار تا ۲۵ ثانیه پاسخ نداد. اتصال اینترنت و برنامه بازار را بررسی کن.',
      );
    } catch (error) {
      throw BazaarBillingException(_friendlyError(error));
    }
  }

  Future<List<BazaarSubscriptionReceipt>> restoreMonthlyPurchases({
    void Function(String message)? onProgress,
  }) async {
    await connect(onProgress: onProgress);
    onProgress?.call('در حال بررسی خریدهای قبلی در بازار...');
    try {
      final dynamic raw = await FlutterPoolakey
          .getAllSubscribedProducts()
          .timeout(
            _inventoryTimeout,
            onTimeout: () => throw const BazaarBillingException(
              'بازار در بررسی خریدهای قبلی پاسخ نداد. دوباره تلاش کن.',
            ),
          );
      final items = raw is Iterable ? raw.cast<dynamic>() : const <dynamic>[];
      final receipts = <BazaarSubscriptionReceipt>[];
      for (final item in items) {
        final receipt = _receiptFrom(item, allowMissingToken: true);
        if (receipt.productId == monthlyProductId && receipt.purchaseToken.isNotEmpty) {
          receipts.add(receipt);
        }
      }
      return receipts;
    } on BazaarBillingException {
      rethrow;
    } on TimeoutException {
      throw const BazaarBillingException('زمان بررسی خریدهای بازار تمام شد.');
    } catch (error) {
      throw BazaarBillingException(_friendlyError(error));
    }
  }

  Future<BazaarProductInfo> _loadMonthlyProduct() async {
    try {
      final dynamic raw = await FlutterPoolakey
          .getSubscriptionSkuDetails(<String>[monthlyProductId])
          .timeout(
            _productLookupTimeout,
            onTimeout: () => throw const BazaarBillingException(
              'بازار محصول اشتراک را در زمان مقرر برنگرداند. اینترنت و وضعیت محصول را بررسی کن.',
            ),
          );
      final items = raw is Iterable ? raw.cast<dynamic>() : const <dynamic>[];
      dynamic matched;
      for (final item in items) {
        if (_read(item, 'sku') == monthlyProductId) {
          matched = item;
          break;
        }
      }
      if (matched == null) {
        throw const BazaarBillingException(
          'محصول اشتراک ماهانه در بازار پیدا نشد. فعال بودن محصول و انتشار یا کانال تست این نسخه را بررسی کن.',
        );
      }
      return BazaarProductInfo(
        productId: monthlyProductId,
        title: _read(matched, 'title'),
        price: _read(matched, 'price'),
      );
    } on BazaarBillingException {
      rethrow;
    } on TimeoutException {
      throw const BazaarBillingException('زمان دریافت اطلاعات محصول بازار تمام شد.');
    } catch (error) {
      throw BazaarBillingException(_friendlyError(error));
    }
  }

  BazaarSubscriptionReceipt _receiptFrom(dynamic value, {bool allowMissingToken = false}) {
    if (value == null) {
      throw const BazaarBillingException('رسید خرید از بازار دریافت نشد.');
    }
    final productId = _read(value, 'productId');
    final purchaseToken = _read(value, 'purchaseToken');
    final orderId = _read(value, 'orderId');
    final purchaseTime = _read(value, 'purchaseTime');
    if (productId != monthlyProductId) {
      throw const BazaarBillingException('محصول بازگشتی بازار با اشتراک ماهانه چکینو یکسان نیست.');
    }
    if (!allowMissingToken && purchaseToken.isEmpty) {
      throw const BazaarBillingException('توکن معتبر خرید از بازار دریافت نشد.');
    }
    return BazaarSubscriptionReceipt(
      productId: productId,
      purchaseToken: purchaseToken,
      orderId: orderId,
      purchaseTime: purchaseTime,
    );
  }

  String _read(dynamic value, String property) {
    try {
      final dynamic dynamicValue = value;
      switch (property) {
        case 'productId':
          return dynamicValue.productId?.toString() ?? '';
        case 'purchaseToken':
          return dynamicValue.purchaseToken?.toString() ?? '';
        case 'orderId':
          return dynamicValue.orderId?.toString() ?? '';
        case 'purchaseTime':
          return dynamicValue.purchaseTime?.toString() ?? '';
        case 'sku':
          return dynamicValue.sku?.toString() ?? '';
        case 'title':
          return dynamicValue.title?.toString() ?? '';
        case 'price':
          return dynamicValue.price?.toString() ?? '';
      }
    } catch (_) {
      return '';
    }
    return '';
  }

  String _friendlyError(Object error) {
    final raw = error.toString();
    final normalized = raw.toLowerCase();
    if (normalized.contains('cancel')) return 'پرداخت توسط کاربر لغو شد.';
    if (normalized.contains('not connected') || normalized.contains('connection')) {
      return 'اتصال به بازار برقرار نشد. اینترنت، نصب بودن بازار و ورود به حساب بازار را بررسی کن.';
    }
    if (normalized.contains('not installed') || normalized.contains('market not found')) {
      return 'برنامه بازار روی گوشی پیدا نشد. ابتدا بازار را نصب یا به‌روز کن.';
    }
    if (normalized.contains('item unavailable') || normalized.contains('sku') || normalized.contains('product not found')) {
      return 'محصول اشتراک برای این نسخه در بازار در دسترس نیست. فعال بودن محصول و کانال تست/انتشار را بررسی کن.';
    }
    if (normalized.contains('purchase_failed') || normalized.contains('purchase flow')) {
      return 'بازار نتوانست صفحه پرداخت را باز کند. بازار را باز و دوباره تلاش کن.';
    }
    if (normalized.contains('signature')) {
      return 'اعتبارسنجی رسید خرید بازار ناموفق بود.';
    }
    return raw.isEmpty || raw == 'Exception' ? 'خرید بازار انجام نشد. دوباره تلاش کن.' : raw;
  }
}

class BazaarProductInfo {
  const BazaarProductInfo({
    required this.productId,
    required this.title,
    required this.price,
  });

  final String productId;
  final String title;
  final String price;
}

class BazaarSubscriptionReceipt {
  const BazaarSubscriptionReceipt({
    required this.productId,
    required this.purchaseToken,
    this.orderId,
    this.purchaseTime,
  });

  final String productId;
  final String purchaseToken;
  final String? orderId;
  final String? purchaseTime;

  Map<String, dynamic> toServerJson() => <String, dynamic>{
        'productId': productId,
        'purchaseToken': purchaseToken,
        if (orderId != null && orderId!.isNotEmpty) 'orderId': orderId,
        if (purchaseTime != null && purchaseTime!.isNotEmpty) 'purchaseTime': purchaseTime,
      };
}

class BazaarBillingException implements Exception {
  const BazaarBillingException(this.message);

  final String message;

  @override
  String toString() => message;
}
