import 'dart:async';
import 'dart:convert';
import 'dart:io';

import '../config/app_environment.dart';

class RemoteApiException implements Exception {
  const RemoteApiException(this.message, {this.code, this.statusCode});

  final String message;
  final String? code;
  final int? statusCode;

  @override
  String toString() => message;
}

class RemoteApiClient {
  RemoteApiClient({HttpClient? httpClient}) : _httpClient = httpClient ?? HttpClient();

  final HttpClient _httpClient;

  Future<Map<String, dynamic>> post(
    String action,
    Map<String, dynamic> payload, {
    String? bearerToken,
  }) async {
    final endpoint = AppEnvironment.apiUri;
    if (endpoint == null) {
      throw const RemoteApiException('ارتباط آنلاین این نسخه هنوز تنظیم نشده است.', code: 'api_not_configured');
    }

    final requestBody = <String, dynamic>{'action': action, ...payload};
    HttpClientRequest request;
    try {
      request = await _httpClient.postUrl(endpoint).timeout(const Duration(seconds: 15));
      request.headers.contentType = ContentType.json;
      request.headers.set(HttpHeaders.acceptHeader, 'application/json');
      request.headers.set('X-Checkino-App-Version', AppEnvironment.appVersion);
      if (bearerToken != null && bearerToken.trim().isNotEmpty) {
        request.headers.set(HttpHeaders.authorizationHeader, 'Bearer ${bearerToken.trim()}');
      }
      request.add(utf8.encode(jsonEncode(requestBody)));
    } on TimeoutException {
      throw const RemoteApiException('زمان پاسخ‌گویی سرویس تمام شد.', code: 'timeout');
    } on SocketException {
      throw const RemoteApiException('اتصال اینترنت برقرار نیست.', code: 'network');
    } on HttpException {
      throw const RemoteApiException('اتصال به سرویس پشتیبانی ناموفق بود.', code: 'network');
    }

    HttpClientResponse response;
    String body;
    try {
      response = await request.close().timeout(const Duration(seconds: 20));
      body = await utf8.decoder.bind(response).join();
    } on TimeoutException {
      throw const RemoteApiException('زمان پاسخ‌گویی سرویس تمام شد.', code: 'timeout');
    } on SocketException {
      throw const RemoteApiException('اتصال اینترنت برقرار نیست.', code: 'network');
    } on HttpException {
      throw const RemoteApiException('پاسخ سرویس دریافت نشد.', code: 'network');
    }

    Map<String, dynamic> decoded = <String, dynamic>{};
    try {
      final raw = jsonDecode(body);
      if (raw is Map) decoded = Map<String, dynamic>.from(raw);
    } catch (_) {
      throw RemoteApiException('پاسخ سرویس معتبر نیست.', code: 'invalid_response', statusCode: response.statusCode);
    }

    if (response.statusCode < 200 || response.statusCode >= 300 || decoded['ok'] != true) {
      final error = decoded['error'] is Map ? Map<String, dynamic>.from(decoded['error'] as Map) : <String, dynamic>{};
      throw RemoteApiException(
        error['message']?.toString() ?? 'درخواست انجام نشد.',
        code: error['code']?.toString(),
        statusCode: response.statusCode,
      );
    }

    final data = decoded['data'];
    return data is Map ? Map<String, dynamic>.from(data) : <String, dynamic>{};
  }

  /// Performs a short reachability probe against this app's own health endpoint.
  /// It prevents normal offline usage from waiting for the longer API request
  /// timeout before deciding to queue a sync operation locally.
  Future<bool> canReachService() async {
    final endpoint = AppEnvironment.apiUri;
    if (endpoint == null) return false;
    final path = endpoint.path;
    final healthPath = path.endsWith('/api.php')
        ? '${path.substring(0, path.length - 'api.php'.length)}health.php'
        : path.endsWith('api.php')
            ? '${path.substring(0, path.length - 'api.php'.length)}health.php'
            : '$path/health.php';
    final healthEndpoint = endpoint.replace(path: healthPath);

    try {
      final request = await _httpClient.getUrl(healthEndpoint).timeout(const Duration(seconds: 3));
      request.headers.set(HttpHeaders.acceptHeader, 'application/json');
      final response = await request.close().timeout(const Duration(seconds: 3));
      await response.drain<void>();
      return response.statusCode >= 200 && response.statusCode < 300;
    } on TimeoutException {
      return false;
    } on SocketException {
      return false;
    } on HttpException {
      return false;
    } catch (_) {
      return false;
    }
  }

  void close() => _httpClient.close(force: true);
}
