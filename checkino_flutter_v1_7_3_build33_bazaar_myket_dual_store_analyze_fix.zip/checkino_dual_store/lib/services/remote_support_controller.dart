import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../config/app_environment.dart';
import '../models/remote_models.dart';
import 'bazaar_billing_service.dart';
import 'myket_billing_service.dart';
import 'data_controller.dart';
import 'monetization_controller.dart';
import 'remote_api_client.dart';
import 'secure_local_store.dart';

/// Local-first gateway for the optional online support service.
///
/// Checklist data never waits for this controller. Aggregate analytics, support
/// tickets, broadcasts, and subscription updates are cached locally and only
/// exchanged after the app verifies reachability of its own HTTPS endpoint.
class RemoteSupportController extends ChangeNotifier {
  RemoteSupportController({RemoteApiClient? apiClient, SecureLocalStore? secureStore})
      : _api = apiClient ?? RemoteApiClient(),
        _secureStore = secureStore ?? SecureLocalStore();

  static const String _cacheKey = 'checkino_remote_support_cache_v2';
  static const String _legacyCacheKey = 'checkino_remote_support_cache_v1';
  static const String _deviceTokenKey = 'remote_device_token_v1';
  static const String _installationIdKey = 'remote_installation_id_v1';
  static const String _adminSessionKey = 'remote_admin_session_v1';
  static const Duration _connectionCacheTtl = Duration(seconds: 25);
  static const Duration _storeInventoryCheckInterval = Duration(hours: 6);

  final RemoteApiClient _api;
  final SecureLocalStore _secureStore;

  bool _loaded = false;
  bool _syncing = false;
  bool _isOnline = false;
  bool _usageDirty = false;
  String? _lastError;
  DateTime? _lastConnectionCheck;
  DateTime? _lastSuccessfulSync;
  DateTime? _lastStoreInventoryCheck;
  RemoteUserProfile? _profile;
  List<RemoteBroadcast> _pendingBroadcasts = const [];
  List<SupportTicket> _cachedTickets = const [];
  final Map<String, SupportTicket> _ticketDetails = <String, SupportTicket>{};
  final Map<String, String> _ticketAliases = <String, String>{};
  final List<_QueuedRemoteOperation> _outbox = <_QueuedRemoteOperation>[];
  AdminSession? _adminSession;
  CheckinoDataController? _observedDataController;
  MonetizationController? _observedMonetizationController;
  Timer? _usageSyncTimer;

  bool get loaded => _loaded;
  bool get syncing => _syncing;
  bool get remoteEnabled => AppEnvironment.remoteEnabled;
  bool get isOnline => remoteEnabled && _isOnline;
  bool get hasPendingSync => _usageDirty || _outbox.isNotEmpty;
  int get queuedOperationCount => _outbox.length;
  String? get lastError => _lastError;
  DateTime? get lastSuccessfulSync => _lastSuccessfulSync;
  RemoteUserProfile? get profile => _profile;
  bool get isPro => _profile?.isPro ?? false;
  bool get isBlocked => _profile?.isBlocked ?? false;
  List<RemoteBroadcast> get pendingBroadcasts => List.unmodifiable(_pendingBroadcasts);
  List<SupportTicket> get cachedTickets => List.unmodifiable(_sortedTickets(_cachedTickets));
  int get unreadTicketCount => _profile?.unreadTicketCount ?? 0;
  AdminSession? get adminSession => _adminSession;
  bool get hasAdminSession => _adminSession != null && !_adminSession!.isExpired;

  String get offlineStatusLabel {
    if (!remoteEnabled) return 'اتصال آنلاین این نسخه تنظیم نشده است.';
    if (isOnline) {
      return hasPendingSync ? 'اتصال برقرار است؛ همگام‌سازی در حال تکمیل است.' : 'اتصال برقرار است.';
    }
    if (hasPendingSync) return 'آفلاین هستی؛ تغییرات برای ارسال بعدی روی گوشی نگه‌داری می‌شوند.';
    return 'آفلاین هستی؛ اطلاعات اصلی برنامه روی گوشی در دسترس‌اند.';
  }

  /// Keeps aggregate usage fresh without transmitting checklist titles, notes,
  /// attachments, or task content. Network work is skipped while offline.
  void observeUsage({
    required CheckinoDataController dataController,
    required MonetizationController monetizationController,
  }) {
    if (identical(_observedDataController, dataController) && identical(_observedMonetizationController, monetizationController)) return;
    _observedDataController?.removeListener(_scheduleObservedUsageSync);
    _observedDataController = dataController;
    _observedMonetizationController = monetizationController;
    dataController.addListener(_scheduleObservedUsageSync);
  }

  void _scheduleObservedUsageSync() {
    _usageDirty = true;
    unawaited(_saveCache());
    _usageSyncTimer?.cancel();
    _usageSyncTimer = Timer(const Duration(seconds: 8), () {
      final data = _observedDataController;
      final monetization = _observedMonetizationController;
      if (data != null && monetization != null) {
        unawaited(syncWithData(dataController: data, monetizationController: monetization));
      }
    });
    notifyListeners();
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_cacheKey) ?? prefs.getString(_legacyCacheKey);
    if (raw != null && raw.isNotEmpty) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is Map) _restoreCache(Map<String, dynamic>.from(decoded));
      } catch (_) {
        // A corrupted optional online cache must never affect local checklist data.
      }
    }

    final sessionRaw = await _secureStore.readSecret(_adminSessionKey);
    if (sessionRaw != null && sessionRaw.isNotEmpty) {
      try {
        final parsed = jsonDecode(sessionRaw);
        if (parsed is Map) {
          final session = AdminSession.fromJson(Map<String, dynamic>.from(parsed));
          if (!session.isExpired && session.token.isNotEmpty) _adminSession = session;
        }
      } catch (_) {
        await _secureStore.deleteSecret(_adminSessionKey);
      }
    }

    _loaded = true;
    if (prefs.containsKey(_legacyCacheKey)) await prefs.remove(_legacyCacheKey);
    await _saveCache();
    notifyListeners();
  }

  /// Checks only the service endpoint, with a short timeout. It does not block
  /// any local feature and is cached briefly to prevent unnecessary probes.
  Future<bool> refreshConnection({bool force = false}) async {
    if (!remoteEnabled) {
      if (_isOnline) {
        _isOnline = false;
        notifyListeners();
      }
      return false;
    }
    final now = DateTime.now();
    if (!force && _lastConnectionCheck != null && now.difference(_lastConnectionCheck!) < _connectionCacheTtl) {
      return _isOnline;
    }

    final before = _isOnline;
    _isOnline = await _api.canReachService();
    _lastConnectionCheck = now;
    if (before != _isOnline) notifyListeners();
    return _isOnline;
  }

  /// Attempts a safe online sync. Returning false means the app remains fully
  /// usable locally and any queued online work stays on the device.
  Future<bool> syncWithData({
    required CheckinoDataController dataController,
    required MonetizationController monetizationController,
    bool forceConnectionCheck = false,
  }) async {
    _usageDirty = true;
    if (!remoteEnabled || _syncing) {
      await _saveCache();
      return false;
    }

    final available = await refreshConnection(force: forceConnectionCheck);
    if (!available) {
      await _saveCache();
      notifyListeners();
      return false;
    }

    _syncing = true;
    _lastError = null;
    notifyListeners();
    var succeeded = false;
    try {
      final activeSource = _profile?.subscriptionSource ?? monetizationController.subscriptionSource;
      final wasMarketplaceSubscription = activeSource == 'bazaar' || activeSource == 'myket';
      final response = await _syncDevice(dataController);
      await _applyDeviceResponse(response, monetizationController);
      await _refreshStoreSubscriptionFromInventoryIfDue(
        monetizationController,
        wasMarketplaceSubscription: wasMarketplaceSubscription,
      );
      await _flushOutbox();
      _usageDirty = false;
      _lastSuccessfulSync = DateTime.now();
      succeeded = true;
    } on RemoteApiException catch (error) {
      _handleRemoteFailure(error);
    } catch (_) {
      _isOnline = false;
      _lastConnectionCheck = DateTime.now();
      _lastError = null;
    } finally {
      _syncing = false;
      await _saveCache();
      notifyListeners();
    }
    return succeeded;
  }

  Future<bool> syncPendingNow({bool forceConnectionCheck = true}) async {
    final data = _observedDataController;
    final monetization = _observedMonetizationController;
    if (data == null || monetization == null) return false;
    return syncWithData(
      dataController: data,
      monetizationController: monetization,
      forceConnectionCheck: forceConnectionCheck,
    );
  }

  /// Acknowledgements are local-first too, preventing an already-read popup
  /// from appearing again while the device is offline.
  Future<void> acknowledgeBroadcast(String broadcastId) async {
    if (broadcastId.trim().isEmpty) return;
    _pendingBroadcasts = _pendingBroadcasts.where((item) => item.id != broadcastId).toList();
    _queue(_QueuedRemoteOperation(
      id: _localId('broadcast-ack'),
      type: _QueuedOperationType.broadcastAck,
      payload: {'broadcastId': broadcastId},
      createdAt: DateTime.now(),
    ));
    await _saveCache();
    notifyListeners();
    unawaited(syncPendingNow());
  }

  /// Returns cached tickets immediately when offline, while refreshing the
  /// cache in the background as soon as the online endpoint is reachable.
  Future<List<SupportTicket>> fetchTickets({bool refresh = true}) async {
    if (refresh) await syncPendingNow();
    if (!isOnline) return cachedTickets;

    final token = await _readDeviceToken();
    if (token == null) return cachedTickets;
    try {
      final response = await _api.post('ticket_list', const {}, bearerToken: token);
      final raw = response['tickets'];
      if (raw is List) {
        final fromServer = raw
            .whereType<Map>()
            .map((item) => SupportTicket.fromJson(Map<String, dynamic>.from(item)))
            .where((item) => item.id.isNotEmpty)
            .toList();
        _mergeTicketList(fromServer);
        await _saveCache();
        notifyListeners();
      }
    } on RemoteApiException catch (error) {
      _handleRemoteFailure(error);
      await _saveCache();
      notifyListeners();
    }
    return cachedTickets;
  }

  Future<SupportTicket> fetchTicket(String ticketId) async {
    final resolvedId = _resolveTicketId(ticketId);
    final cached = _ticketDetails[ticketId] ?? _ticketDetails[resolvedId] ?? _findCachedTicket(ticketId) ?? _findCachedTicket(resolvedId);
    // Never delay an already cached conversation just to probe the network.
    // A background sync may refresh it later, while the local timeline opens now.
    if (cached != null && !isOnline) {
      unawaited(syncPendingNow());
      return cached;
    }
    await syncPendingNow();

    if (!isOnline || resolvedId.startsWith('local-')) {
      if (cached != null) return cached;
      throw const RemoteApiException('این گفتگو هنوز روی دستگاه ذخیره نشده است.', code: 'ticket_not_cached');
    }

    final token = await _readDeviceToken();
    if (token == null) {
      if (cached != null) return cached;
      throw const RemoteApiException('اتصال امن دستگاه هنوز آماده نشده است.', code: 'device_not_registered');
    }

    try {
      final response = await _api.post('ticket_get', {'ticketId': resolvedId}, bearerToken: token);
      final raw = response['ticket'];
      if (raw is! Map) throw const RemoteApiException('تاریخچه درخواست پیدا نشد.', code: 'ticket_missing');
      final ticket = SupportTicket.fromJson(Map<String, dynamic>.from(raw));
      final merged = _mergeServerTicket(ticket, localReference: ticketId);
      await _saveCache();
      notifyListeners();
      return merged;
    } on RemoteApiException catch (error) {
      _handleRemoteFailure(error);
      if (cached != null) return cached;
      rethrow;
    }
  }

  /// Persists a new ticket to the device first. It is sent automatically as
  /// soon as a verified connection becomes available.
  Future<SupportTicket> createTicket({required String subject, required String message}) async {
    if (!remoteEnabled) {
      throw const RemoteApiException('پشتیبانی آنلاین این نسخه هنوز تنظیم نشده است.', code: 'api_not_configured');
    }
    if (isBlocked) {
      throw RemoteApiException(_profile?.blockReason ?? 'ارسال درخواست آنلاین برای این حساب غیرفعال شده است.', code: 'blocked');
    }

    final now = DateTime.now();
    final id = _localId('ticket');
    final initial = SupportTicketMessage(
      id: _localId('message'),
      sender: 'user',
      body: message.trim(),
      createdAt: now,
      pending: true,
    );
    final ticket = SupportTicket(
      id: id,
      subject: subject.trim(),
      status: 'open',
      createdAt: now,
      updatedAt: now,
      lastMessage: initial.body,
      messages: [initial],
      syncState: TicketSyncState.pending,
    );
    _putTicket(ticket);
    _queue(_QueuedRemoteOperation(
      id: _localId('ticket-create'),
      type: _QueuedOperationType.ticketCreate,
      payload: {'localTicketId': id, 'subject': ticket.subject, 'message': initial.body},
      createdAt: now,
    ));
    await _saveCache();
    notifyListeners();
    unawaited(syncPendingNow());
    return ticket;
  }

  /// Stores a reply locally regardless of connectivity. The message bubble is
  /// marked pending until the backend confirms delivery.
  Future<SupportTicket> replyToTicket({required String ticketId, required String message}) async {
    if (!remoteEnabled) {
      throw const RemoteApiException('پشتیبانی آنلاین این نسخه هنوز تنظیم نشده است.', code: 'api_not_configured');
    }
    if (isBlocked) {
      throw RemoteApiException(_profile?.blockReason ?? 'ارسال درخواست آنلاین برای این حساب غیرفعال شده است.', code: 'blocked');
    }

    final current = _ticketDetails[ticketId] ?? _findCachedTicket(ticketId);
    if (current == null) throw const RemoteApiException('گفتگو روی دستگاه پیدا نشد.', code: 'ticket_not_cached');
    if (current.isClosed) throw const RemoteApiException('این درخواست بسته شده است.', code: 'ticket_closed');

    final now = DateTime.now();
    final localMessage = SupportTicketMessage(
      id: _localId('message'),
      sender: 'user',
      body: message.trim(),
      createdAt: now,
      pending: true,
    );
    final updated = current.copyWith(
      updatedAt: now,
      lastMessage: localMessage.body,
      messages: [...current.messages, localMessage],
      syncState: TicketSyncState.pending,
    );
    _putTicket(updated);
    _queue(_QueuedRemoteOperation(
      id: _localId('ticket-reply'),
      type: _QueuedOperationType.ticketReply,
      payload: {'ticketId': ticketId, 'message': localMessage.body},
      createdAt: now,
    ));
    await _saveCache();
    notifyListeners();
    unawaited(syncPendingNow());
    return updated;
  }

  /// Special access remains network-only. Failure here must never affect normal
  /// checklist navigation or locally stored data.
  Future<void> loginSpecial({required String username, required String password}) async {
    if (!remoteEnabled) {
      throw const RemoteApiException('آدرس سرویس آنلاین در فایل build تنظیم نشده است.', code: 'api_not_configured');
    }
    if (!await refreshConnection(force: true)) {
      throw const RemoteApiException('برای ورود ویژه اتصال اینترنت لازم است.', code: 'network');
    }
    final response = await _api.post('admin_login', {'username': username.trim(), 'password': password});
    final raw = response['session'];
    if (raw is! Map) throw const RemoteApiException('ورود انجام نشد.', code: 'login_failed');
    final session = AdminSession.fromJson(Map<String, dynamic>.from(raw));
    if (session.token.isEmpty) throw const RemoteApiException('نشست امن ایجاد نشد.', code: 'session_missing');
    _adminSession = session;
    await _secureStore.writeSecret(_adminSessionKey, jsonEncode(session.toJson()));
    notifyListeners();
  }

  Future<void> logoutSpecial() async {
    final session = _adminSession;
    _adminSession = null;
    await _secureStore.deleteSecret(_adminSessionKey);
    notifyListeners();
    if (session == null || !await refreshConnection()) return;
    try {
      await _api.post('admin_logout', const {}, bearerToken: session.token);
    } on RemoteApiException {
      // Local logout is already complete.
    }
  }

  Future<AdminDashboardStats> fetchAdminDashboard() async {
    final response = await _adminPost('admin_dashboard', const {});
    final raw = response['stats'];
    if (raw is! Map) throw const RemoteApiException('آمار مدیریتی دریافت نشد.', code: 'dashboard_missing');
    return AdminDashboardStats.fromJson(Map<String, dynamic>.from(raw));
  }

  Future<List<ManagedUser>> fetchManagedUsers({String query = '', String filter = 'all', int page = 1}) async {
    final response = await _adminPost('admin_users', {'query': query.trim(), 'filter': filter, 'page': page});
    final raw = response['users'];
    if (raw is! List) return const [];
    return raw.whereType<Map>().map((item) => ManagedUser.fromJson(Map<String, dynamic>.from(item))).toList();
  }

  Future<ManagedUser> updateManagedUser({
    required String userId,
    required String tier,
    required bool isBlocked,
    String? proUntil,
    String? blockReason,
    String? note,
  }) async {
    final response = await _adminPost('admin_user_update', {
      'userId': userId,
      'tier': tier,
      'isBlocked': isBlocked,
      'proUntil': proUntil,
      'blockReason': blockReason?.trim(),
      'note': note?.trim(),
    });
    final raw = response['user'];
    if (raw is! Map) throw const RemoteApiException('اطلاعات کاربر ذخیره نشد.', code: 'user_update_failed');
    return ManagedUser.fromJson(Map<String, dynamic>.from(raw));
  }

  Future<List<SupportTicket>> fetchAdminTickets({String status = 'all'}) async {
    final response = await _adminPost('admin_tickets', {'status': status});
    final raw = response['tickets'];
    if (raw is! List) return const [];
    return raw.whereType<Map>().map((item) => SupportTicket.fromJson(Map<String, dynamic>.from(item))).toList();
  }

  Future<SupportTicket> fetchAdminTicket(String ticketId) async {
    final response = await _adminPost('admin_ticket_get', {'ticketId': ticketId});
    final raw = response['ticket'];
    if (raw is! Map) throw const RemoteApiException('تیکت پیدا نشد.', code: 'ticket_missing');
    return SupportTicket.fromJson(Map<String, dynamic>.from(raw));
  }

  Future<SupportTicket> replyAdminTicket({required String ticketId, required String message, String status = 'answered'}) async {
    final response = await _adminPost('admin_ticket_reply', {'ticketId': ticketId, 'message': message.trim(), 'status': status});
    final raw = response['ticket'];
    if (raw is! Map) throw const RemoteApiException('پاسخ ذخیره نشد.', code: 'ticket_reply_failed');
    return SupportTicket.fromJson(Map<String, dynamic>.from(raw));
  }

  Future<void> setAdminTicketStatus({required String ticketId, required String status}) async {
    await _adminPost('admin_ticket_status', {'ticketId': ticketId, 'status': status});
  }

  Future<List<RemoteBroadcast>> fetchAdminBroadcasts() async {
    final response = await _adminPost('admin_broadcasts', const {});
    final raw = response['broadcasts'];
    if (raw is! List) return const [];
    return raw.whereType<Map>().map((item) => RemoteBroadcast.fromJson(Map<String, dynamic>.from(item))).toList();
  }

  Future<RemoteBroadcast> createBroadcast({
    required String title,
    required String body,
    required String audience,
    required bool popup,
  }) async {
    final response = await _adminPost('admin_broadcast_create', {
      'title': title.trim(),
      'body': body.trim(),
      'audience': audience,
      'popup': popup,
    });
    final raw = response['broadcast'];
    if (raw is! Map) throw const RemoteApiException('پیام همگانی ثبت نشد.', code: 'broadcast_failed');
    return RemoteBroadcast.fromJson(Map<String, dynamic>.from(raw));
  }

  Future<void> setBroadcastActive({required String broadcastId, required bool active}) async {
    await _adminPost('admin_broadcast_toggle', {'broadcastId': broadcastId, 'active': active});
  }

  Future<void> changeAdminPassword({required String currentPassword, required String newPassword}) async {
    await _adminPost('admin_change_password', {'currentPassword': currentPassword, 'newPassword': newPassword});
  }

  Future<void> changeAdminUsername({required String currentPassword, required String username}) async {
    final response = await _adminPost('admin_change_username', {'currentPassword': currentPassword, 'username': username.trim()});
    final raw = response['session'];
    if (raw is Map) {
      final session = AdminSession.fromJson(Map<String, dynamic>.from(raw));
      if (session.token.isNotEmpty) {
        _adminSession = session;
        await _secureStore.writeSecret(_adminSessionKey, jsonEncode(session.toJson()));
        notifyListeners();
      }
    }
  }

  /// Sends only the Bazaar product id and purchase token to Checkino's server.
  /// The server must validate the token against Bazaar before it marks the
  /// account as Pro; the app never activates a subscription by itself.
  Future<RemoteUserProfile> verifyBazaarMonthlySubscription(
    BazaarSubscriptionReceipt receipt,
  ) async {
    if (receipt.productId != BazaarBillingService.monthlyProductId) {
      throw const RemoteApiException('محصول پرداخت معتبر نیست.', code: 'invalid_product');
    }
    if (receipt.purchaseToken.trim().isEmpty) {
      throw const RemoteApiException('توکن خرید بازار دریافت نشد.', code: 'missing_purchase_token');
    }
    final data = _observedDataController;
    final monetization = _observedMonetizationController;
    if (data == null || monetization == null) {
      throw const RemoteApiException('برنامه برای همگام‌سازی اشتراک آماده نیست. یک‌بار دوباره بازش کن.', code: 'sync_not_ready');
    }
    if (!await syncWithData(
      dataController: data,
      monetizationController: monetization,
      forceConnectionCheck: true,
    )) {
      throw const RemoteApiException('برای تأیید اشتراک بازار، اتصال اینترنت لازم است.', code: 'network');
    }
    final token = await _readDeviceToken();
    if (token == null) {
      throw const RemoteApiException('شناسه امن دستگاه آماده نشد. دوباره تلاش کن.', code: 'device_not_registered');
    }
    try {
      final response = await _api.post(
        'bazaar_subscription_verify',
        receipt.toServerJson(),
        bearerToken: token,
      );
      await _applyDeviceResponse(response, monetization);
      await _saveCache();
      notifyListeners();
      final profile = _profile;
      if (profile == null || profile.tier != 'pro') {
        throw const RemoteApiException('تأیید اشتراک از بازار دریافت نشد. چند دقیقه بعد بازیابی خرید را امتحان کن.', code: 'subscription_inactive');
      }
      return profile;
    } on RemoteApiException catch (error) {
      _handleRemoteFailure(error);
      rethrow;
    }
  }


  /// Sends Myket product id, purchase token, original purchase JSON and signature
  /// to Checkino's server. The server must validate the token/signature against
  /// Myket before it marks the account as Pro; the app never activates a
  /// subscription by itself.
  Future<RemoteUserProfile> verifyMyketMonthlySubscription(
    MyketPurchaseReceipt receipt,
  ) async {
    if (receipt.productId != MyketBillingService.monthlyProductId) {
      throw const RemoteApiException('محصول پرداخت معتبر نیست.', code: 'invalid_product');
    }
    if (receipt.purchaseToken.trim().isEmpty) {
      throw const RemoteApiException('توکن خرید مایکت دریافت نشد.', code: 'missing_purchase_token');
    }
    final data = _observedDataController;
    final monetization = _observedMonetizationController;
    if (data == null || monetization == null) {
      throw const RemoteApiException('برنامه برای همگام‌سازی اشتراک آماده نیست. یک‌بار دوباره بازش کن.', code: 'sync_not_ready');
    }
    if (!await syncWithData(
      dataController: data,
      monetizationController: monetization,
      forceConnectionCheck: true,
    )) {
      throw const RemoteApiException('برای تأیید اشتراک مایکت، اتصال اینترنت لازم است.', code: 'network');
    }
    final token = await _readDeviceToken();
    if (token == null) {
      throw const RemoteApiException('شناسه امن دستگاه آماده نشد. دوباره تلاش کن.', code: 'device_not_registered');
    }
    try {
      final response = await _api.post(
        'myket_subscription_verify',
        receipt.toServerJson(),
        bearerToken: token,
      );
      await _applyDeviceResponse(response, monetization);
      await _saveCache();
      notifyListeners();
      final profile = _profile;
      if (profile == null || profile.tier != 'pro') {
        throw const RemoteApiException('تأیید اشتراک از مایکت دریافت نشد. چند دقیقه بعد بازیابی خرید را امتحان کن.', code: 'subscription_inactive');
      }
      return profile;
    } on RemoteApiException catch (error) {
      _handleRemoteFailure(error);
      rethrow;
    }
  }

  /// Checks the local marketplace inventory at a limited cadence when this
  /// device already has a marketplace subscription. Bazaar can renew
  /// automatically; Myket is verified only when an unconsumed monthly product
  /// is present. Offline checklist usage never depends on marketplace IAP.
  Future<void> _refreshStoreSubscriptionFromInventoryIfDue(
    MonetizationController monetizationController, {
    required bool wasMarketplaceSubscription,
  }) async {
    final source = _profile?.subscriptionSource ?? monetizationController.subscriptionSource;
    if (!wasMarketplaceSubscription && source != 'bazaar' && source != 'myket') return;
    final now = DateTime.now();
    if (_lastStoreInventoryCheck != null &&
        now.difference(_lastStoreInventoryCheck!) < _storeInventoryCheckInterval) {
      return;
    }
    _lastStoreInventoryCheck = now;

    try {
      final token = await _readDeviceToken();
      if (token == null) return;
      if (source == 'myket') {
        final receipts = await MyketBillingService.instance.restoreMonthlyPurchases();
        final receipt = receipts.where((item) => item.productId == MyketBillingService.monthlyProductId).firstOrNull;
        if (receipt == null || receipt.purchaseToken.trim().isEmpty) return;
        final response = await _api.post(
          'myket_subscription_verify',
          receipt.toServerJson(),
          bearerToken: token,
        );
        await _applyDeviceResponse(response, monetizationController);
        await MyketBillingService.instance.consumeMonthlyPurchase(receipt);
        return;
      }

      final receipts = await BazaarBillingService.instance.restoreMonthlyPurchases();
      final receipt = receipts.where((item) => item.productId == BazaarBillingService.monthlyProductId).firstOrNull;
      if (receipt == null || receipt.purchaseToken.trim().isEmpty) return;
      final response = await _api.post(
        'bazaar_subscription_verify',
        receipt.toServerJson(),
        bearerToken: token,
      );
      await _applyDeviceResponse(response, monetizationController);
    } catch (_) {
      // A missing marketplace app, temporary marketplace error, or no
      // connectivity must never prevent the primary local-first sync.
    }
  }

  Future<RemoteUserProfile> restoreBazaarMonthlySubscription(
    List<BazaarSubscriptionReceipt> receipts,
  ) async {
    if (receipts.isEmpty) {
      throw const RemoteApiException('اشتراک فعال چکینو در حساب بازار پیدا نشد.', code: 'subscription_not_found');
    }
    RemoteApiException? latestError;
    for (final receipt in receipts) {
      try {
        return await verifyBazaarMonthlySubscription(receipt);
      } on RemoteApiException catch (error) {
        latestError = error;
      }
    }
    throw latestError ?? const RemoteApiException('بازیابی اشتراک انجام نشد.', code: 'restore_failed');
  }

  Future<RemoteUserProfile> restoreMyketMonthlySubscription(
    List<MyketPurchaseReceipt> receipts,
  ) async {
    if (receipts.isEmpty) {
      throw const RemoteApiException('خرید فعال چکینو در حساب مایکت پیدا نشد.', code: 'subscription_not_found');
    }
    RemoteApiException? latestError;
    for (final receipt in receipts) {
      try {
        return await verifyMyketMonthlySubscription(receipt);
      } on RemoteApiException catch (error) {
        latestError = error;
      }
    }
    throw latestError ?? const RemoteApiException('بازیابی خرید مایکت انجام نشد.', code: 'restore_failed');
  }


  Future<List<AdminAuditEntry>> fetchAdminAudit() async {
    final response = await _adminPost('admin_audit', const {});
    final raw = response['entries'];
    if (raw is! List) return const [];
    return raw.whereType<Map>().map((item) => AdminAuditEntry.fromJson(Map<String, dynamic>.from(item))).toList();
  }

  Future<Map<String, dynamic>> _syncDevice(CheckinoDataController dataController) async {
    final payload = await _usagePayload(dataController);
    final deviceToken = await _readDeviceToken();
    if (deviceToken == null) {
      final response = await _api.post('device_register', payload);
      final token = response['deviceToken']?.toString() ?? response['device_token']?.toString() ?? '';
      if (token.isEmpty) throw const RemoteApiException('شناسه امن دستگاه دریافت نشد.', code: 'missing_device_token');
      await _secureStore.writeSecret(_deviceTokenKey, token);
      return response;
    }
    return _api.post('device_sync', payload, bearerToken: deviceToken);
  }

  Future<Map<String, dynamic>> _usagePayload(CheckinoDataController dataController) async {
    final stats = dataController.stats;
    return {
      'installationId': await _installationId(),
      'platform': Platform.isAndroid ? 'android' : 'unknown',
      'appVersion': AppEnvironment.appVersion,
      'usage': {
        'activeLists': dataController.activeLists.length,
        'archivedLists': dataController.archivedLists.length,
        'totalItems': stats['total'] ?? 0,
        'doneItems': stats['done'] ?? 0,
        'completedToday': stats['completedToday'] ?? 0,
      },
    };
  }

  Future<void> _applyDeviceResponse(Map<String, dynamic> response, MonetizationController monetizationController) async {
    final rawProfile = response['profile'];
    if (rawProfile is Map) {
      _profile = RemoteUserProfile.fromJson(Map<String, dynamic>.from(rawProfile));
      await monetizationController.setRemoteSubscription(
        isPro: _profile!.tier == 'pro',
        expiresAt: _profile!.proUntil,
        source: _profile!.subscriptionSource,
      );
    }
    final rawBroadcasts = response['broadcasts'];
    if (rawBroadcasts is List) {
      _pendingBroadcasts = rawBroadcasts
          .whereType<Map>()
          .map((item) => RemoteBroadcast.fromJson(Map<String, dynamic>.from(item)))
          .where((item) => item.id.isNotEmpty)
          .toList();
    }
  }

  Future<void> _flushOutbox() async {
    if (_outbox.isEmpty) return;
    final token = await _readDeviceToken();
    if (token == null) return;

    while (_outbox.isNotEmpty && _isOnline) {
      final operation = _outbox.first;
      try {
        switch (operation.type) {
          case _QueuedOperationType.ticketCreate:
            await _flushTicketCreate(operation, token);
            break;
          case _QueuedOperationType.ticketReply:
            await _flushTicketReply(operation, token);
            break;
          case _QueuedOperationType.broadcastAck:
            await _api.post('broadcast_ack', {'broadcastId': operation.payload['broadcastId']?.toString() ?? ''}, bearerToken: token);
            break;
        }
        _outbox.removeAt(0);
        await _saveCache();
      } on RemoteApiException catch (error) {
        operation.attempts += 1;
        operation.lastError = error.message;
        _handleRemoteFailure(error);
        break;
      } catch (_) {
        operation.attempts += 1;
        operation.lastError = 'ارسال در انتظار اتصال است.';
        _isOnline = false;
        _lastConnectionCheck = DateTime.now();
        break;
      }
    }
  }

  Future<void> _flushTicketCreate(_QueuedRemoteOperation operation, String token) async {
    final localId = operation.payload['localTicketId']?.toString() ?? '';
    final response = await _api.post(
      'ticket_create',
      {'subject': operation.payload['subject']?.toString() ?? '', 'message': operation.payload['message']?.toString() ?? ''},
      bearerToken: token,
    );
    final raw = response['ticket'];
    if (raw is! Map) throw const RemoteApiException('درخواست ثبت نشد.', code: 'ticket_create_failed');
    final remoteTicket = SupportTicket.fromJson(Map<String, dynamic>.from(raw));
    if (remoteTicket.id.isEmpty) throw const RemoteApiException('شناسه درخواست ثبت‌شده دریافت نشد.', code: 'ticket_create_failed');
    _replaceLocalTicket(localId, remoteTicket);
  }

  Future<void> _flushTicketReply(_QueuedRemoteOperation operation, String token) async {
    final requestedId = operation.payload['ticketId']?.toString() ?? '';
    final ticketId = _resolveTicketId(requestedId);
    if (ticketId.isEmpty || ticketId.startsWith('local-')) {
      throw const RemoteApiException('درخواست اصلی هنوز در صف ارسال است.', code: 'ticket_parent_pending');
    }
    final response = await _api.post(
      'ticket_reply',
      {'ticketId': ticketId, 'message': operation.payload['message']?.toString() ?? ''},
      bearerToken: token,
    );
    final raw = response['ticket'];
    if (raw is! Map) throw const RemoteApiException('پاسخ ارسال نشد.', code: 'ticket_reply_failed');
    _mergeServerTicket(SupportTicket.fromJson(Map<String, dynamic>.from(raw)), localReference: requestedId);
  }

  Future<Map<String, dynamic>> _adminPost(String action, Map<String, dynamic> payload) async {
    final session = _adminSession;
    if (session == null || session.isExpired || session.token.isEmpty) {
      await logoutSpecial();
      throw const RemoteApiException('نشست ورود ویژه منقضی شده است. دوباره وارد شوید.', code: 'admin_session_expired');
    }
    if (!await refreshConnection(force: true)) {
      throw const RemoteApiException('برای دریافت اطلاعات آنلاین اتصال اینترنت لازم است.', code: 'network');
    }
    try {
      return await _api.post(action, payload, bearerToken: session.token);
    } on RemoteApiException catch (error) {
      if (error.code == 'admin_session_invalid' || error.code == 'unauthorized') await logoutSpecial();
      _handleRemoteFailure(error);
      rethrow;
    }
  }

  Future<String?> _readDeviceToken() async {
    final token = await _secureStore.readSecret(_deviceTokenKey);
    return token == null || token.isEmpty ? null : token;
  }

  Future<String> _installationId() async {
    final existing = await _secureStore.readSecret(_installationIdKey);
    if (existing != null && existing.isNotEmpty) return existing;
    final random = Random.secure();
    final parts = List<String>.generate(4, (_) => random.nextInt(1 << 32).toRadixString(16).padLeft(8, '0'));
    final generated = '${parts[0]}-${parts[1]}-${parts[2]}-${parts[3]}';
    await _secureStore.writeSecret(_installationIdKey, generated);
    return generated;
  }

  void _handleRemoteFailure(RemoteApiException error) {
    if (error.code == 'device_session_invalid' || error.code == 'unauthorized') {
      unawaited(_secureStore.deleteSecret(_deviceTokenKey));
    }
    if (_isNetworkError(error)) {
      _isOnline = false;
      _lastConnectionCheck = DateTime.now();
      _lastError = null;
      return;
    }
    _lastError = error.message;
  }

  bool _isNetworkError(RemoteApiException error) {
    return error.code == 'network' || error.code == 'timeout' || error.code == 'api_not_configured';
  }

  void _queue(_QueuedRemoteOperation operation) {
    _outbox.add(operation);
  }

  String _localId(String prefix) {
    final random = Random.secure().nextInt(1 << 32).toRadixString(16).padLeft(8, '0');
    return '$prefix-${DateTime.now().microsecondsSinceEpoch}-$random';
  }

  String _resolveTicketId(String id) {
    var value = id;
    final seen = <String>{};
    while (_ticketAliases.containsKey(value) && seen.add(value)) {
      value = _ticketAliases[value] ?? value;
    }
    return value;
  }

  SupportTicket? _findCachedTicket(String id) {
    for (final ticket in _cachedTickets) {
      if (ticket.id == id) return ticket;
    }
    return null;
  }

  void _putTicket(SupportTicket ticket) {
    final resolved = _resolveTicketId(ticket.id);
    final normalized = resolved == ticket.id ? ticket : ticket.copyWith(id: resolved);
    _ticketDetails[normalized.id] = normalized;
    final index = _cachedTickets.indexWhere((item) => item.id == normalized.id);
    if (index >= 0) {
      _cachedTickets[index] = normalized;
    } else {
      _cachedTickets = [normalized, ..._cachedTickets];
    }
  }

  void _replaceLocalTicket(String localId, SupportTicket remoteTicket) {
    if (localId.isEmpty) {
      _putTicket(remoteTicket);
      return;
    }
    final local = _ticketDetails[localId] ?? _findCachedTicket(localId);
    _ticketAliases[localId] = remoteTicket.id;
    final merged = _mergeServerTicket(remoteTicket, existing: local, localReference: localId);
    _ticketDetails.remove(localId);
    _ticketDetails[remoteTicket.id] = merged;
    // _mergeServerTicket updates the cache for the remote ID. Replace the old
    // local placeholder and de-duplicate so one conversation has one card.
    _cachedTickets = _sortedTickets([
      ..._cachedTickets.where((item) => item.id != localId && item.id != remoteTicket.id),
      merged,
    ]);
    for (final operation in _outbox) {
      if (operation.type == _QueuedOperationType.ticketReply && operation.payload['ticketId']?.toString() == localId) {
        operation.payload['ticketId'] = remoteTicket.id;
      }
    }
  }

  SupportTicket _mergeServerTicket(
    SupportTicket server, {
    SupportTicket? existing,
    String? localReference,
  }) {
    final reference = localReference == null ? null : _findCachedTicket(localReference) ?? _ticketDetails[localReference];
    final local = existing ?? _ticketDetails[server.id] ?? _findCachedTicket(server.id) ?? reference;
    final pendingMessages = local?.messages.where((item) => item.pending).toList() ?? const <SupportTicketMessage>[];
    final mergedMessages = <SupportTicketMessage>[...server.messages];
    final stillPending = <SupportTicketMessage>[];
    for (final message in pendingMessages) {
      final confirmed = mergedMessages.any((item) => item.id == message.id || (item.body == message.body && item.sender == message.sender));
      if (!confirmed) {
        mergedMessages.add(message);
        stillPending.add(message);
      }
    }
    final merged = server.copyWith(
      messages: mergedMessages,
      lastMessage: stillPending.isNotEmpty ? stillPending.last.body : server.lastMessage,
      syncState: stillPending.isEmpty ? TicketSyncState.synced : TicketSyncState.pending,
    );
    _putTicket(merged);
    return merged;
  }

  void _mergeTicketList(List<SupportTicket> serverTickets) {
    final localPending = _cachedTickets.where((item) => item.hasPendingSync || item.isLocalOnly).toList();
    final merged = <String, SupportTicket>{for (final ticket in serverTickets) ticket.id: ticket};
    for (final local in localPending) {
      final resolved = _resolveTicketId(local.id);
      final server = merged[resolved];
      if (server == null) {
        merged[local.id] = local;
      } else {
        merged[resolved] = _mergeServerTicket(server, existing: local, localReference: local.id);
      }
    }
    _cachedTickets = _sortedTickets(merged.values.toList());
  }

  List<SupportTicket> _sortedTickets(List<SupportTicket> tickets) {
    final sorted = [...tickets];
    sorted.sort((a, b) {
      final aTime = a.updatedAt ?? a.createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);
      final bTime = b.updatedAt ?? b.createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);
      return bTime.compareTo(aTime);
    });
    return sorted;
  }

  void _restoreCache(Map<String, dynamic> map) {
    final profile = map['profile'];
    if (profile is Map) _profile = RemoteUserProfile.fromJson(Map<String, dynamic>.from(profile));

    final broadcasts = map['pendingBroadcasts'];
    if (broadcasts is List) {
      _pendingBroadcasts = broadcasts
          .whereType<Map>()
          .map((item) => RemoteBroadcast.fromJson(Map<String, dynamic>.from(item)))
          .where((item) => item.id.isNotEmpty)
          .toList();
    }

    final tickets = map['cachedTickets'];
    if (tickets is List) {
      _cachedTickets = tickets
          .whereType<Map>()
          .map((item) => SupportTicket.fromJson(Map<String, dynamic>.from(item)))
          .where((item) => item.id.isNotEmpty)
          .toList();
    }

    final details = map['ticketDetails'];
    if (details is Map) {
      for (final entry in details.entries) {
        if (entry.value is Map) {
          final ticket = SupportTicket.fromJson(Map<String, dynamic>.from(entry.value as Map));
          if (ticket.id.isNotEmpty) _ticketDetails[entry.key.toString()] = ticket;
        }
      }
    }

    final aliases = map['ticketAliases'];
    if (aliases is Map) {
      for (final entry in aliases.entries) {
        final key = entry.key.toString();
        final value = entry.value?.toString() ?? '';
        if (key.isNotEmpty && value.isNotEmpty) _ticketAliases[key] = value;
      }
    }

    final outbox = map['outbox'];
    if (outbox is List) {
      _outbox.addAll(outbox.whereType<Map>().map((item) => _QueuedRemoteOperation.fromJson(Map<String, dynamic>.from(item))));
    }

    _usageDirty = map['usageDirty'] == true || map['usageDirty'] == 1 || map['usageDirty'] == '1';
    final lastSync = map['lastSuccessfulSync']?.toString();
    _lastSuccessfulSync = lastSync == null ? null : DateTime.tryParse(lastSync)?.toLocal();
    final lastStoreCheck =
        (map['lastStoreInventoryCheck'] ?? map['lastBazaarInventoryCheck'])
            ?.toString();
    _lastStoreInventoryCheck = lastStoreCheck == null
        ? null
        : DateTime.tryParse(lastStoreCheck)?.toLocal();
  }

  Future<void> _saveCache() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _cacheKey,
      jsonEncode({
        'profile': _profile?.toJson(),
        'pendingBroadcasts': _pendingBroadcasts.map((item) => item.toJson()).toList(),
        'cachedTickets': _cachedTickets.map((item) => item.toJson()).toList(),
        'ticketDetails': _ticketDetails.map((key, value) => MapEntry(key, value.toJson())),
        'ticketAliases': _ticketAliases,
        'outbox': _outbox.map((item) => item.toJson()).toList(),
        'usageDirty': _usageDirty,
        'lastSuccessfulSync': _lastSuccessfulSync?.toUtc().toIso8601String(),
        'lastStoreInventoryCheck':
            _lastStoreInventoryCheck?.toUtc().toIso8601String(),
      }),
    );
  }

  @override
  void dispose() {
    _usageSyncTimer?.cancel();
    _observedDataController?.removeListener(_scheduleObservedUsageSync);
    _api.close();
    super.dispose();
  }
}

enum _QueuedOperationType { ticketCreate, ticketReply, broadcastAck }

class _QueuedRemoteOperation {
  _QueuedRemoteOperation({
    required this.id,
    required this.type,
    required this.payload,
    required this.createdAt,
    this.attempts = 0,
    this.lastError,
  });

  final String id;
  final _QueuedOperationType type;
  final Map<String, dynamic> payload;
  final DateTime createdAt;
  int attempts;
  String? lastError;

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type.name,
        'payload': payload,
        'createdAt': createdAt.toUtc().toIso8601String(),
        'attempts': attempts,
        'lastError': lastError,
      };

  factory _QueuedRemoteOperation.fromJson(Map<String, dynamic> json) {
    final rawType = json['type']?.toString();
    final type = _QueuedOperationType.values.where((item) => item.name == rawType).firstOrNull ?? _QueuedOperationType.ticketReply;
    final rawPayload = json['payload'];
    return _QueuedRemoteOperation(
      id: json['id']?.toString() ?? '',
      type: type,
      payload: rawPayload is Map ? Map<String, dynamic>.from(rawPayload) : <String, dynamic>{},
      createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? '')?.toLocal() ?? DateTime.now(),
      attempts: int.tryParse(json['attempts']?.toString() ?? '') ?? 0,
      lastError: json['lastError']?.toString(),
    );
  }
}

class RemoteSupportScope extends InheritedNotifier<RemoteSupportController> {
  const RemoteSupportScope({super.key, required RemoteSupportController controller, required super.child}) : super(notifier: controller);

  static RemoteSupportController of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<RemoteSupportScope>();
    assert(scope != null, 'RemoteSupportScope not found');
    return scope!.notifier!;
  }
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
