import 'dart:convert';
import 'dart:math';

import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Stores encryption keys in the platform keystore/keychain and encrypted
/// payloads in SharedPreferences. The encrypted payload itself is not useful
/// without the key kept by the OS-backed secure store.
class SecureLocalStore {
  SecureLocalStore();

  static const _encryptionKeyName = 'checkino.local_data_key.v1';
  static const _jsonPrefix = 'checkino.encrypted.';

  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
    iOptions: IOSOptions(accessibility: KeychainAccessibility.first_unlock_this_device),
  );
  final AesGcm _cipher = AesGcm.with256bits();

  Future<dynamic> readJson(String name) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('$_jsonPrefix$name');
    if (raw == null || raw.trim().isEmpty) return null;

    final envelope = jsonDecode(raw);
    if (envelope is! Map) {
      throw const FormatException('Encrypted data envelope is invalid.');
    }

    final key = await _getOrCreateKey();
    final secretBox = SecretBox(
      base64Decode(envelope['cipherText'] as String),
      nonce: base64Decode(envelope['nonce'] as String),
      mac: Mac(base64Decode(envelope['mac'] as String)),
    );
    final clearBytes = await _cipher.decrypt(secretBox, secretKey: key);
    return jsonDecode(utf8.decode(clearBytes));
  }

  Future<void> writeJson(String name, Object value) async {
    final key = await _getOrCreateKey();
    final secretBox = await _cipher.encrypt(utf8.encode(jsonEncode(value)), secretKey: key);
    final envelope = <String, dynamic>{
      'v': 1,
      'nonce': base64Encode(secretBox.nonce),
      'cipherText': base64Encode(secretBox.cipherText),
      'mac': base64Encode(secretBox.mac.bytes),
    };
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('$_jsonPrefix$name', jsonEncode(envelope));
  }

  Future<void> deleteJson(String name) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('$_jsonPrefix$name');
  }

  Future<String?> readSecret(String name) => _secureStorage.read(key: 'checkino.secret.$name');

  Future<void> writeSecret(String name, String value) {
    return _secureStorage.write(key: 'checkino.secret.$name', value: value);
  }

  Future<void> deleteSecret(String name) => _secureStorage.delete(key: 'checkino.secret.$name');

  Future<SecretKey> _getOrCreateKey() async {
    var encoded = await _secureStorage.read(key: _encryptionKeyName);
    if (encoded == null || encoded.isEmpty) {
      final random = Random.secure();
      final bytes = List<int>.generate(32, (_) => random.nextInt(256));
      encoded = base64Encode(bytes);
      await _secureStorage.write(key: _encryptionKeyName, value: encoded);
    }
    return SecretKey(base64Decode(encoded));
  }
}
