import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/check_item.dart';
import '../models/check_list.dart';
import '../utils/persian_numbers.dart';
import '../utils/checkino_icons.dart';
import 'home_widget_service.dart';
import 'reminder_service.dart';
import 'secure_local_store.dart';

String makeId() => '${DateTime.now().microsecondsSinceEpoch}-${Random.secure().nextInt(1 << 30)}';

class AppLockSettings {
  const AppLockSettings({
    this.enabled = false,
    this.pin = '',
    this.biometricEnabled = false,
    this.autoLockOnBackground = true,
  });

  final bool enabled;
  final String pin;
  final bool biometricEnabled;
  final bool autoLockOnBackground;

  AppLockSettings copyWith({bool? enabled, String? pin, bool? biometricEnabled, bool? autoLockOnBackground}) {
    return AppLockSettings(
      enabled: enabled ?? this.enabled,
      pin: pin ?? this.pin,
      biometricEnabled: biometricEnabled ?? this.biometricEnabled,
      autoLockOnBackground: autoLockOnBackground ?? this.autoLockOnBackground,
    );
  }

  /// PIN is intentionally omitted. It is stored by [SecureLocalStore].
  Map<String, dynamic> toJson() => {
        'enabled': enabled,
        'biometricEnabled': biometricEnabled,
        'autoLockOnBackground': autoLockOnBackground,
      };

  factory AppLockSettings.fromJson(Map<String, dynamic> json, {String? pin}) {
    return AppLockSettings(
      enabled: json['enabled'] as bool? ?? false,
      pin: pin ?? (json['pin'] as String? ?? ''),
      biometricEnabled: json['biometricEnabled'] as bool? ?? false,
      autoLockOnBackground: json['autoLockOnBackground'] as bool? ?? true,
    );
  }
}

enum BackupImportMode { replace, merge }

class BackupPreview {
  const BackupPreview({
    required this.sourceName,
    required this.lists,
    required this.templates,
    required this.attachments,
  });

  final String sourceName;
  final List<CheckListModel> lists;
  final List<CheckinoTemplate> templates;
  final Map<String, List<int>> attachments;

  int get itemCount => lists.fold(0, (sum, list) => sum + list.items.length);
  int get imageCount => attachments.length;
}

class TodayTask {
  const TodayTask({required this.listId, required this.listTitle, required this.item});

  final String listId;
  final String listTitle;
  final CheckItem item;
}

class CheckinoDataController extends ChangeNotifier {
  static const String _legacyListsKey = 'checkino_lists_v3';
  static const String _secureDataKey = 'checkino_data_v1';
  static const String _lockKey = 'checkino_lock_v1';
  static const String _pinSecretKey = 'app_lock_pin_v1';
  static const String _homeWidgetKey = 'home_widget_payload';

  final SecureLocalStore _secureStore = SecureLocalStore();

  List<CheckListModel> _lists = <CheckListModel>[];
  List<CheckinoTemplate> _customTemplates = <CheckinoTemplate>[];
  AppLockSettings _lockSettings = const AppLockSettings();
  bool _loaded = false;

  List<CheckListModel> get lists => List.unmodifiable(_lists);
  List<CheckListModel> get activeLists => List.unmodifiable(_sorted(_lists.where((item) => !item.archived).toList()));
  List<CheckListModel> get archivedLists => List.unmodifiable(_sorted(_lists.where((item) => item.archived).toList()));
  List<CheckinoTemplate> get templates => List.unmodifiable([...checkinoTemplates, ..._customTemplates]);
  AppLockSettings get lockSettings => _lockSettings;
  bool get loaded => _loaded;

  List<TodayTask> get todayTasks {
    final tasks = <TodayTask>[];
    for (final list in activeLists) {
      for (final item in list.items) {
        if (item.done || item.dueAt == null) continue;
        if (item.isOverdue || item.hasDueToday) {
          tasks.add(TodayTask(listId: list.id, listTitle: list.title, item: item));
        }
      }
    }
    tasks.sort((a, b) {
      if (a.item.isOverdue != b.item.isOverdue) return a.item.isOverdue ? -1 : 1;
      final aDue = a.item.dueAt ?? DateTime(9999);
      final bDue = b.item.dueAt ?? DateTime(9999);
      if (aDue != bDue) return aDue.compareTo(bDue);
      return b.item.priority.index.compareTo(a.item.priority.index);
    });
    return List.unmodifiable(tasks);
  }

  List<CheckListModel> _sorted(List<CheckListModel> input) {
    input.sort((a, b) {
      if (a.pinned != b.pinned) return a.pinned ? -1 : 1;
      final byOrder = a.sortOrder.compareTo(b.sortOrder);
      if (byOrder != 0) return byOrder;
      return b.createdAt.compareTo(a.createdAt);
    });
    return input;
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    dynamic encrypted;
    var hadSecurePayload = false;
    try {
      encrypted = await _secureStore.readJson(_secureDataKey);
      hadSecurePayload = encrypted != null;
    } catch (_) {
      // The legacy payload remains untouched. No new data is written here so a
      // damaged secure payload is never silently replaced with seeded data.
      hadSecurePayload = prefs.containsKey('checkino.encrypted.$_secureDataKey');
    }

    if (encrypted is Map) {
      _loadPayload(Map<String, dynamic>.from(encrypted));
    } else if (encrypted is List) {
      _lists = _parseLists(encrypted);
    } else if (!hadSecurePayload) {
      final rawLegacy = prefs.getString(_legacyListsKey);
      if (rawLegacy != null && rawLegacy.trim().isNotEmpty) {
        try {
          final legacy = jsonDecode(rawLegacy);
          _lists = legacy is List ? _parseLists(legacy) : _seedLists();
        } catch (_) {
          _lists = _seedLists();
        }
      } else {
        _lists = _seedLists();
      }
    }

    _normalizeListOrders();
    await _loadLockSettings(prefs);
    _loaded = true;

    // Migrate only after all legacy fields have been read successfully.
    if (!hadSecurePayload) {
      await _persistData();
      await prefs.remove(_legacyListsKey);
    }
    await _syncExternalServices();
    notifyListeners();
  }

  void _loadPayload(Map<String, dynamic> payload) {
    _lists = _parseLists(payload['lists']);
    final rawTemplates = payload['templates'];
    _customTemplates = rawTemplates is List
        ? rawTemplates
            .whereType<Map>()
            .map((item) => CheckinoTemplate.fromJson(Map<String, dynamic>.from(item), isBuiltIn: false))
            .toList()
        : <CheckinoTemplate>[];
  }

  List<CheckListModel> _parseLists(dynamic raw) {
    if (raw is! List) return <CheckListModel>[];
    return raw.whereType<Map>().map((item) => CheckListModel.fromJson(Map<String, dynamic>.from(item))).toList();
  }

  Future<void> _loadLockSettings(SharedPreferences prefs) async {
    Map<String, dynamic> rawLock = <String, dynamic>{};
    final raw = prefs.getString(_lockKey);
    if (raw != null && raw.trim().isNotEmpty) {
      try {
        rawLock = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      } catch (_) {
        rawLock = <String, dynamic>{};
      }
    }

    final legacyPin = rawLock['pin'] as String?;
    final securePin = await _secureStore.readSecret(_pinSecretKey);
    final pin = securePin ?? legacyPin ?? '';
    final parsed = AppLockSettings.fromJson(rawLock, pin: pin);
    _lockSettings = parsed.enabled && !_isValidPin(pin) ? parsed.copyWith(enabled: false) : parsed;

    if (legacyPin != null && legacyPin.isNotEmpty && securePin == null) {
      await _secureStore.writeSecret(_pinSecretKey, legacyPin);
    }
    await prefs.setString(_lockKey, jsonEncode(_lockSettings.toJson()));
  }

  bool _isValidPin(String pin) => RegExp(r'^\d{4,12}$').hasMatch(pin);

  List<CheckListModel> _seedLists() {
    final now = DateTime.now();
    return [
      CheckListModel(
        id: makeId(),
        title: 'کارهای امروز',
        pinned: true,
        sortOrder: 100,
        dueAt: now.add(const Duration(hours: 6)),
        reminderLeadTime: ReminderLeadTime.oneHourBefore,
        iconCodePoint: Icons.today.codePoint,
        items: [
          CheckItem(id: makeId(), title: 'مرتب‌کردن میز کار', priority: ItemPriority.high, dueAt: now.add(const Duration(hours: 2))),
          CheckItem(id: makeId(), title: 'خرید چند وسیله ضروری', priority: ItemPriority.normal),
          CheckItem(id: makeId(), title: 'بررسی برنامه فردا', done: true, completedAt: now.subtract(const Duration(hours: 1))),
        ],
      ),
      CheckListModel(
        id: makeId(),
        title: 'چک‌لیست سفر',
        sortOrder: 200,
        iconCodePoint: Icons.flight_takeoff.codePoint,
        items: [
          CheckItem(id: makeId(), title: 'شارژر و پاوربانک', priority: ItemPriority.high),
          CheckItem(id: makeId(), title: 'داروهای ضروری'),
          CheckItem(id: makeId(), title: 'مدارک'),
        ],
      ),
    ];
  }

  void _normalizeListOrders() {
    final seen = <int>{};
    var needsNormalization = false;
    for (final list in _lists) {
      if (list.sortOrder == 0 || !seen.add(list.sortOrder)) {
        needsNormalization = true;
        break;
      }
    }
    if (!needsNormalization) return;
    var order = 100;
    _lists = _lists.map((list) {
      final normalized = list.copyWith(sortOrder: order);
      order += 100;
      return normalized;
    }).toList();
  }

  int _nextSortOrder() {
    if (_lists.isEmpty) return 100;
    var minimum = _lists.first.sortOrder;
    for (final list in _lists.skip(1)) {
      if (list.sortOrder < minimum) minimum = list.sortOrder;
    }
    return minimum - 100;
  }

  CheckListModel? listById(String id) {
    for (final list in _lists) {
      if (list.id == id) return list;
    }
    return null;
  }

  Future<void> addList(CheckListModel list) async {
    _lists = [list.copyWith(sortOrder: _nextSortOrder()), ..._lists];
    await _save();
  }

  Future<void> updateList(CheckListModel list) async {
    final current = listById(list.id);
    final normalized = current == null || list.sortOrder != 0 ? list : list.copyWith(sortOrder: current.sortOrder);
    _lists = _lists.map((item) => item.id == normalized.id ? normalized : item).toList();
    await _save();
  }

  Future<void> deleteList(String listId) async {
    final list = listById(listId);
    if (list == null) return;
    await ReminderService.instance.cancelForList(list);
    for (final item in list.items) {
      await _deleteManagedImage(item.imagePath);
    }
    _lists = _lists.where((item) => item.id != listId).toList();
    await _save();
  }

  Future<void> archiveList(String listId, bool archived) async {
    final list = listById(listId);
    if (list == null) return;
    if (archived) await ReminderService.instance.cancelForList(list);
    await updateList(list.copyWith(archived: archived));
  }

  Future<void> togglePin(String listId) async {
    final list = listById(listId);
    if (list == null) return;
    await updateList(list.copyWith(pinned: !list.pinned));
  }

  Future<void> reorderActiveLists(int oldIndex, int newIndex) async {
    final visible = activeLists.toList();
    if (oldIndex < 0 || oldIndex >= visible.length) return;
    // ReorderableListView.onReorderItem already reports the insertion index
    // after removing the item at oldIndex.
    newIndex = newIndex.clamp(0, visible.length - 1).toInt();
    final moving = visible.removeAt(oldIndex);
    final targetPin = visible.isEmpty ? moving.pinned : visible[newIndex.clamp(0, visible.length - 1).toInt()].pinned;
    visible.insert(newIndex, moving.copyWith(pinned: targetPin));

    final normalized = <CheckListModel>[];
    var pinnedOrder = 100;
    var normalOrder = 100;
    for (final list in visible) {
      if (list.pinned) {
        normalized.add(list.copyWith(sortOrder: pinnedOrder));
        pinnedOrder += 100;
      } else {
        normalized.add(list.copyWith(sortOrder: 100000 + normalOrder));
        normalOrder += 100;
      }
    }
    final archived = _lists.where((item) => item.archived).toList();
    _lists = [...normalized, ...archived];
    await _save();
  }

  Future<void> addItem(String listId, CheckItem item) async {
    final list = listById(listId);
    if (list == null) return;
    await updateList(list.copyWith(items: [item, ...list.items]));
  }

  Future<void> updateItem(String listId, CheckItem item) async {
    final list = listById(listId);
    if (list == null) return;
    final previous = list.items.where((current) => current.id == item.id).firstOrNull;
    if (previous?.imagePath != null && previous!.imagePath != item.imagePath) {
      await _deleteManagedImage(previous.imagePath);
    }
    final updatedItems = list.items.map((current) => current.id == item.id ? item : current).toList();
    await updateList(list.copyWith(items: updatedItems));
  }

  Future<void> deleteItem(String listId, String itemId) async {
    final list = listById(listId);
    if (list == null) return;
    final item = list.items.where((current) => current.id == itemId).firstOrNull;
    if (item != null) {
      await ReminderService.instance.cancelForItem(item);
      await _deleteManagedImage(item.imagePath);
    }
    await updateList(list.copyWith(items: list.items.where((item) => item.id != itemId).toList()));
  }

  Future<void> toggleItem(String listId, String itemId) async {
    final list = listById(listId);
    if (list == null) return;
    final updated = <CheckItem>[];
    CheckItem? repeatedCopy;
    for (final item in list.items) {
      if (item.id != itemId) {
        updated.add(item);
        continue;
      }
      final newDone = !item.done;
      final changed = item.copyWith(done: newDone, completedAt: newDone ? DateTime.now() : null, clearCompletedAt: !newDone);
      updated.add(changed);
      if (newDone && item.repeatRule != RepeatRule.none) {
        final nextDue = item.repeatRule.nextDate(item.dueAt ?? DateTime.now());
        repeatedCopy = item.copyWith(
          id: makeId(),
          done: false,
          dueAt: nextDue,
          clearDueAt: nextDue == null,
          clearCompletedAt: true,
          createdAt: DateTime.now(),
        );
      }
    }
    if (repeatedCopy != null) updated.insert(0, repeatedCopy);
    await updateList(list.copyWith(items: updated));
  }

  Future<void> toggleSubTask(String listId, String itemId, String subTaskId) async {
    final list = listById(listId);
    if (list == null) return;
    final updatedItems = list.items.map((item) {
      if (item.id != itemId) return item;
      final subtasks = item.subTasks.map((sub) => sub.id == subTaskId ? sub.copyWith(done: !sub.done) : sub).toList();
      return item.copyWith(subTasks: subtasks);
    }).toList();
    await updateList(list.copyWith(items: updatedItems));
  }

  Future<void> addSubTask(String listId, String itemId, String title) async {
    final list = listById(listId);
    if (list == null || title.trim().isEmpty) return;
    final updatedItems = list.items.map((item) {
      if (item.id != itemId) return item;
      return item.copyWith(subTasks: [...item.subTasks, SubTask(id: makeId(), title: title.trim())]);
    }).toList();
    await updateList(list.copyWith(items: updatedItems));
  }

  Future<void> deleteSubTask(String listId, String itemId, String subTaskId) async {
    final list = listById(listId);
    if (list == null) return;
    final updatedItems = list.items.map((item) {
      if (item.id != itemId) return item;
      return item.copyWith(subTasks: item.subTasks.where((sub) => sub.id != subTaskId).toList());
    }).toList();
    await updateList(list.copyWith(items: updatedItems));
  }

  Future<void> reorderItems(String listId, int oldIndex, int newIndex) async {
    final list = listById(listId);
    if (list == null) return;
    final remaining = list.items.where((item) => !item.done).toList();
    final completed = list.items.where((item) => item.done).toList();
    if (oldIndex < 0 || oldIndex >= remaining.length) return;
    // Flutter's onReorderItem callback already normalizes newIndex after the
    // item at oldIndex has been removed. Applying the legacy decrement here
    // would place downward moves one position too high.
    newIndex = newIndex.clamp(0, remaining.length - 1).toInt();
    final item = remaining.removeAt(oldIndex);
    remaining.insert(newIndex, item);
    await updateList(list.copyWith(items: [...remaining, ...completed]));
  }

  Future<String?> persistImage(String sourcePath) async {
    if (sourcePath.trim().isEmpty) return null;
    final source = File(sourcePath);
    if (!await source.exists()) return null;
    final directory = await _attachmentsDirectory();
    final extension = _safeImageExtension(source.path);
    final destination = File('${directory.path}/${makeId()}$extension');
    await source.copy(destination.path);
    return destination.path;
  }

  Future<void> _deleteManagedImage(String? path) async {
    if (path == null || path.trim().isEmpty) return;
    final directory = await _attachmentsDirectory();
    if (!path.startsWith(directory.path)) return;
    final file = File(path);
    if (await file.exists()) await file.delete();
  }

  Future<Directory> _attachmentsDirectory() async {
    final root = await getApplicationDocumentsDirectory();
    final directory = Directory('${root.path}/checkino_attachments');
    if (!await directory.exists()) await directory.create(recursive: true);
    return directory;
  }

  String _safeImageExtension(String path) {
    final match = RegExp(r'\.(jpg|jpeg|png|webp)$', caseSensitive: false).firstMatch(path);
    if (match == null) return '.jpg';
    return '.${match.group(1)!.toLowerCase()}';
  }

  Future<void> setLockSettings(AppLockSettings settings) async {
    final pin = settings.pin.trim();
    if (settings.enabled && !_isValidPin(pin)) {
      throw const FormatException('PIN باید بین ۴ تا ۱۲ رقم باشد.');
    }
    _lockSettings = settings.copyWith(pin: pin);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_lockKey, jsonEncode(_lockSettings.toJson()));
    if (pin.isEmpty) {
      await _secureStore.deleteSecret(_pinSecretKey);
    } else {
      await _secureStore.writeSecret(_pinSecretKey, pin);
    }
    await _syncExternalServices();
    notifyListeners();
  }

  Future<bool> authenticateBiometric() async {
    try {
      final auth = LocalAuthentication();
      final supported = await auth.isDeviceSupported();
      final canCheck = await auth.canCheckBiometrics;
      if (!supported && !canCheck) return false;
      return auth.authenticate(localizedReason: 'برای ورود به چکینو تأیید هویت کنید');
    } catch (_) {
      return false;
    }
  }

  String exportBackupJson() {
    return const JsonEncoder.withIndent('  ').convert(_backupManifest());
  }

  Map<String, dynamic> _backupManifest({List<Map<String, dynamic>>? lists}) {
    return {
      'app': 'checkino',
      'schema': 5,
      'exportedAt': DateTime.now().toIso8601String(),
      'lists': lists ?? _lists.map((item) => item.toJson()).toList(),
      'templates': _customTemplates.map((item) => item.toJson()).toList(),
    };
  }

  Future<void> importBackupJson(String raw, {BackupImportMode mode = BackupImportMode.replace}) async {
    final decoded = jsonDecode(raw);
    final preview = _decodeBackupManifest(decoded, sourceName: 'بکاپ متنی');
    await importBackupPreview(preview, mode: mode);
  }

  Future<void> copyBackupToClipboard() async {
    await Clipboard.setData(ClipboardData(text: exportBackupJson()));
  }

  Future<void> shareBackupFile() async {
    final file = await _createBackupArchive();
    await Share.shareXFiles([XFile(file.path)], text: 'بکاپ کامل چکینو');
  }

  Future<BackupPreview?> pickBackupPreview() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['zip', 'json'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return null;
    final file = result.files.first;
    final bytes = file.bytes ?? (file.path == null ? null : await File(file.path!).readAsBytes());
    if (bytes == null || bytes.isEmpty) throw const FormatException('فایل بکاپ خوانده نشد.');
    final name = file.name.isEmpty ? 'بکاپ چکینو' : file.name;
    final lowerName = name.toLowerCase();
    if (lowerName.endsWith('.json')) {
      return _decodeBackupManifest(jsonDecode(utf8.decode(bytes)), sourceName: name);
    }
    return _decodeBackupArchive(bytes, sourceName: name);
  }

  Future<void> importBackupPreview(BackupPreview preview, {required BackupImportMode mode}) async {
    final restored = await _restoreBackupAttachments(preview);
    final restoredTemplates = preview.templates;
    if (mode == BackupImportMode.replace) {
      _lists = restored;
      _customTemplates = restoredTemplates;
    } else {
      _lists = [..._lists, ..._deduplicateImportedLists(restored)];
      _customTemplates = [..._customTemplates, ..._deduplicateTemplates(restoredTemplates)];
    }
    _normalizeListOrders();
    await _save();
  }

  BackupPreview _decodeBackupArchive(Uint8List bytes, {required String sourceName}) {
    final archive = ZipDecoder().decodeBytes(bytes);
    ArchiveFile? manifest;
    for (final file in archive.files) {
      if (file.name == 'checkino_backup.json') {
        manifest = file;
        break;
      }
    }
    if (manifest == null || manifest.content is! List<int>) {
      throw const FormatException('فایل checkino_backup.json در بکاپ وجود ندارد.');
    }
    final attachments = <String, List<int>>{};
    for (final file in archive.files) {
      if (!file.isFile || !file.name.startsWith('attachments/') || file.content is! List<int>) continue;
      attachments[file.name] = List<int>.from(file.content as List<int>);
    }
    return _decodeBackupManifest(
      jsonDecode(utf8.decode(List<int>.from(manifest.content as List<int>))),
      sourceName: sourceName,
      attachments: attachments,
    );
  }

  BackupPreview _decodeBackupManifest(
    dynamic decoded, {
    required String sourceName,
    Map<String, List<int>> attachments = const <String, List<int>>{},
  }) {
    final dynamic rawLists = decoded is Map ? decoded['lists'] : decoded;
    if (rawLists is! List) throw const FormatException('ساختار بکاپ معتبر نیست.');
    final rawTemplates = decoded is Map ? decoded['templates'] : null;
    return BackupPreview(
      sourceName: sourceName,
      lists: _parseLists(rawLists),
      templates: rawTemplates is List
          ? rawTemplates
              .whereType<Map>()
              .map((item) => CheckinoTemplate.fromJson(Map<String, dynamic>.from(item), isBuiltIn: false))
              .toList()
          : const <CheckinoTemplate>[],
      attachments: attachments,
    );
  }

  Future<List<CheckListModel>> _restoreBackupAttachments(BackupPreview preview) async {
    final directory = await _attachmentsDirectory();
    final restored = <CheckListModel>[];
    for (final list in preview.lists) {
      final items = <CheckItem>[];
      for (final item in list.items) {
        final path = item.imagePath;
        if (path == null || path.isEmpty) {
          items.add(item);
          continue;
        }
        if (!path.startsWith('attachment:')) {
          items.add(item);
          continue;
        }
        final name = path.substring('attachment:'.length);
        final bytes = preview.attachments[name];
        if (bytes == null) {
          items.add(item.copyWith(clearImagePath: true));
          continue;
        }
        final destination = File('${directory.path}/${makeId()}${_safeImageExtension(name)}');
        await destination.writeAsBytes(bytes, flush: true);
        items.add(item.copyWith(imagePath: destination.path));
      }
      restored.add(list.copyWith(items: items));
    }
    return restored;
  }

  List<CheckListModel> _deduplicateImportedLists(List<CheckListModel> imported) {
    final existingListIds = _lists.map((list) => list.id).toSet();
    final result = <CheckListModel>[];
    for (final list in imported) {
      if (!existingListIds.contains(list.id)) {
        existingListIds.add(list.id);
        result.add(list);
        continue;
      }
      final items = list.items.map((item) => item.copyWith(id: makeId())).toList();
      final copied = list.copyWith(id: makeId(), items: items, sortOrder: _nextSortOrder());
      existingListIds.add(copied.id);
      result.add(copied);
    }
    return result;
  }

  List<CheckinoTemplate> _deduplicateTemplates(List<CheckinoTemplate> imported) {
    final ids = _customTemplates.map((template) => template.id).toSet();
    final output = <CheckinoTemplate>[];
    for (final template in imported) {
      if (!ids.contains(template.id)) {
        ids.add(template.id);
        output.add(template);
      } else {
        final copied = template.copyWith(id: makeId());
        ids.add(copied.id);
        output.add(copied);
      }
    }
    return output;
  }

  Future<File> _createBackupArchive() async {
    final archive = Archive();
    final copiedLists = <Map<String, dynamic>>[];
    for (final list in _lists) {
      final listMap = Map<String, dynamic>.from(list.toJson());
      final itemMaps = (listMap['items'] as List).map((item) => Map<String, dynamic>.from(item as Map)).toList();
      for (final item in itemMaps) {
        final path = item['imagePath'] as String?;
        if (path == null || path.trim().isEmpty) continue;
        final image = File(path);
        if (!await image.exists()) {
          item['imagePath'] = null;
          continue;
        }
        final relativePath = 'attachments/${item['id']}${_safeImageExtension(path)}';
        final bytes = await image.readAsBytes();
        archive.addFile(ArchiveFile(relativePath, bytes.length, bytes));
        item['imagePath'] = 'attachment:$relativePath';
      }
      listMap['items'] = itemMaps;
      copiedLists.add(listMap);
    }
    final manifest = utf8.encode(jsonEncode(_backupManifest(lists: copiedLists)));
    archive.addFile(ArchiveFile('checkino_backup.json', manifest.length, manifest));
    final zipBytes = ZipEncoder().encode(archive);
    if (zipBytes == null) throw const FileSystemException('ساخت فایل بکاپ ناموفق بود.');
    final directory = await getTemporaryDirectory();
    final file = File('${directory.path}/checkino_backup_${DateTime.now().millisecondsSinceEpoch}.zip');
    await file.writeAsBytes(zipBytes, flush: true);
    return file;
  }

  String listAsText(CheckListModel list) {
    final buffer = StringBuffer();
    buffer.writeln('چک‌لیست: ${list.title}');
    buffer.writeln('پیشرفت: ${toPersianDigits(list.progressPercent)}٪');
    if (list.dueAt != null) buffer.writeln('موعد: ${formatDateTimeFa(list.dueAt)}');
    if (list.nextReminderAt != null) buffer.writeln('یادآور بعدی: ${formatDateTimeFa(list.nextReminderAt)}');
    buffer.writeln('');
    for (final item in list.items) {
      buffer.writeln('${item.done ? '✓' : '□'} ${item.title}');
      if (item.dueAt != null) buffer.writeln('  تاریخ: ${formatDateTimeFa(item.dueAt)}');
      if (item.note != null && item.note!.trim().isNotEmpty) buffer.writeln('  توضیح: ${item.note}');
      for (final sub in item.subTasks) {
        buffer.writeln('  ${sub.done ? '✓' : '□'} ${sub.title}');
      }
    }
    return buffer.toString();
  }

  Future<void> shareListText(CheckListModel list) async {
    await Share.share(listAsText(list), subject: list.title);
  }

  Future<void> shareListPdf(CheckListModel list) async {
    final doc = pw.Document();
    doc.addPage(
      pw.MultiPage(
        build: (context) => [
          pw.Header(level: 0, child: pw.Text(list.title)),
          pw.Text('Progress: ${list.progressPercent}%'),
          if (list.dueAt != null) pw.Text('Due: ${list.dueAt!.toLocal()}'),
          pw.SizedBox(height: 16),
          ...list.items.map((item) => pw.Bullet(text: '${item.done ? '[x]' : '[ ]'} ${item.title}')),
        ],
      ),
    );
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/checkino_${list.id}.pdf');
    await file.writeAsBytes(await doc.save());
    await Share.shareXFiles([XFile(file.path)], text: 'خروجی PDF چکینو');
  }

  Map<String, int> get stats {
    final today = DateTime.now();
    var completedToday = 0;
    var overdue = 0;
    var high = 0;
    var total = 0;
    var done = 0;
    for (final list in _lists.where((item) => !item.archived)) {
      total += list.totalItems;
      done += list.completedItems;
      for (final item in list.items) {
        if (item.done && item.completedAt != null && isSameDay(item.completedAt!, today)) completedToday++;
        if (item.isOverdue) overdue++;
        if (!item.done && item.priority == ItemPriority.high) high++;
      }
    }
    return {'total': total, 'done': done, 'completedToday': completedToday, 'overdue': overdue, 'high': high};
  }

  Future<void> applyTemplate(CheckinoTemplate template) async {
    final list = CheckListModel(
      id: makeId(),
      title: template.title,
      iconCodePoint: template.iconCodePoint,
      items: template.items.map((title) => CheckItem(id: makeId(), title: title)).toList(),
    );
    await addList(list);
  }

  Future<void> createTemplateFromList(CheckListModel list) async {
    final template = CheckinoTemplate(
      id: makeId(),
      title: list.title,
      iconCodePoint: list.iconCodePoint,
      items: list.items.map((item) => item.title).where((title) => title.trim().isNotEmpty).toList(),
      isBuiltIn: false,
    );
    _customTemplates = [..._customTemplates, template];
    await _save();
  }

  Future<void> deleteCustomTemplate(String templateId) async {
    _customTemplates = _customTemplates.where((template) => template.id != templateId || template.isBuiltIn).toList();
    await _save();
  }

  Future<void> _save({bool silent = false}) async {
    await _persistData();
    await _syncExternalServices();
    if (!silent) notifyListeners();
  }

  Future<void> _persistData() {
    return _secureStore.writeJson(_secureDataKey, {
      'version': 1,
      'lists': _lists.map((item) => item.toJson()).toList(),
      'templates': _customTemplates.map((item) => item.toJson()).toList(),
    });
  }

  Future<void> _syncExternalServices() async {
    final active = _lists.where((item) => !item.archived).toList();
    await ReminderService.instance.syncLists(active);
    final prefs = await SharedPreferences.getInstance();
    final todayItems = <String>[];
    if (_lockSettings.enabled) {
      todayItems.add('برای حفظ حریم خصوصی، نمایش کارها در ویجت قفل است.');
    } else {
      for (final list in activeLists) {
        for (final item in list.items.where((item) => !item.done)) {
          if (todayItems.length >= 4) break;
          if (item.hasDueToday || item.isOverdue || todayItems.length < 2) {
            todayItems.add('${list.title}: ${item.title}');
          }
        }
        if (todayItems.length >= 4) break;
      }
    }
    await prefs.setString(_homeWidgetKey, jsonEncode({'updatedAt': DateTime.now().toIso8601String(), 'items': todayItems}));
    await HomeWidgetService.refresh();
  }
}

class CheckinoDataScope extends InheritedNotifier<CheckinoDataController> {
  const CheckinoDataScope({super.key, required CheckinoDataController controller, required super.child}) : super(notifier: controller);

  static CheckinoDataController of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<CheckinoDataScope>();
    assert(scope != null, 'CheckinoDataScope not found');
    return scope!.notifier!;
  }
}

class CheckinoTemplate {
  const CheckinoTemplate({
    required this.id,
    required this.title,
    required this.iconCodePoint,
    required this.items,
    this.isBuiltIn = true,
  });

  final String id;
  final String title;
  final int iconCodePoint;
  final List<String> items;
  final bool isBuiltIn;

  IconData get icon => checkinoIconFromCodePoint(iconCodePoint);

  CheckinoTemplate copyWith({String? id, String? title, int? iconCodePoint, List<String>? items, bool? isBuiltIn}) {
    return CheckinoTemplate(
      id: id ?? this.id,
      title: title ?? this.title,
      iconCodePoint: iconCodePoint ?? this.iconCodePoint,
      items: items ?? this.items,
      isBuiltIn: isBuiltIn ?? this.isBuiltIn,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'iconCodePoint': iconCodePoint,
        'items': items,
      };

  factory CheckinoTemplate.fromJson(Map<String, dynamic> json, {required bool isBuiltIn}) {
    final rawItems = json['items'];
    return CheckinoTemplate(
      id: json['id'] as String? ?? makeId(),
      title: json['title'] as String? ?? 'قالب شخصی',
      iconCodePoint: json['iconCodePoint'] as int? ?? Icons.checklist_rounded.codePoint,
      items: rawItems is List ? rawItems.map((item) => item.toString()).where((item) => item.trim().isNotEmpty).toList() : <String>[],
      isBuiltIn: isBuiltIn,
    );
  }
}

const checkinoTemplates = <CheckinoTemplate>[
  CheckinoTemplate(id: 'travel', title: 'چک‌لیست سفر', iconCodePoint: 0xe29c, items: ['مدارک', 'شارژر', 'لباس مناسب', 'داروهای ضروری', 'رزروها', 'پول نقد']),
  CheckinoTemplate(id: 'shopping', title: 'خرید خانه', iconCodePoint: 0xe8cc, items: ['نان', 'میوه', 'سبزیجات', 'مواد شوینده', 'لبنیات']),
  CheckinoTemplate(id: 'study', title: 'برنامه درس', iconCodePoint: 0xe80c, items: ['مرور جزوه', 'حل تمرین', 'آماده‌سازی آزمون', 'جمع‌بندی']),
  CheckinoTemplate(id: 'cleaning', title: 'نظافت خانه', iconCodePoint: 0xeb43, items: ['آشپزخانه', 'اتاق‌ها', 'حمام', 'جاروبرقی', 'لباس‌ها']),
  CheckinoTemplate(id: 'work', title: 'پروژه کاری', iconCodePoint: 0xe8f9, items: ['تعریف هدف', 'تقسیم کارها', 'زمان‌بندی', 'بررسی نهایی', 'ارسال خروجی']),
  CheckinoTemplate(id: 'gym', title: 'باشگاه', iconCodePoint: 0xeb43, items: ['لباس ورزشی', 'بطری آب', 'تمرین هوازی', 'تمرین قدرتی', 'کشش پایانی']),
];

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
