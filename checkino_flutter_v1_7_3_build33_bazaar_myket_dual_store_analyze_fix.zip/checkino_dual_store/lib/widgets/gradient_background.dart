import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class GradientBackground extends StatelessWidget {
  const GradientBackground({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return Container(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: Alignment.topRight,
          radius: 1.35,
          colors: [
            colors.accent.withValues(alpha: colors.isDark ? 0.20 : 0.13),
            colors.background,
            colors.background,
          ],
          stops: const [0.0, 0.58, 1.0],
        ),
      ),
      child: child,
    );
  }
}
