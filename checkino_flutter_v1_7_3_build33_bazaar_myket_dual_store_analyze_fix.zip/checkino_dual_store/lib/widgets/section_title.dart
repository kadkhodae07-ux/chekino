import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../utils/persian_numbers.dart';

class SectionTitle extends StatelessWidget {
  const SectionTitle({super.key, required this.title, this.count, this.trailing});
  final String title;
  final int? count;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 24, 4, 10),
      child: Row(
        children: [
          if (count != null)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
              decoration: BoxDecoration(
                color: colors.accent.withValues(alpha: 0.18),
                borderRadius: BorderRadius.circular(99),
                border: Border.all(color: colors.accent.withValues(alpha: 0.35)),
              ),
              child: Text(toPersianDigits(count), style: TextStyle(color: colors.accent, fontWeight: FontWeight.w900)),
            ),
          if (count != null) const SizedBox(width: 10),
          Expanded(child: Text(title, style: TextStyle(color: colors.text, fontWeight: FontWeight.w900, fontSize: 18))),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}
