import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class ProgressLine extends StatelessWidget {
  const ProgressLine({super.key, required this.value, this.height = 8});
  final double value;
  final double height;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final safe = value.clamp(0.0, 1.0);
    return ClipRRect(
      borderRadius: BorderRadius.circular(99),
      child: SizedBox(
        height: height,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Container(color: colors.track),
            Align(
              alignment: Alignment.centerRight,
              child: FractionallySizedBox(
                widthFactor: safe,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [colors.accent, colors.accentDark]),
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
