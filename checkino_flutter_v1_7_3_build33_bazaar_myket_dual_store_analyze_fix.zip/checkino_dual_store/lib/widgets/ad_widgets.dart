import 'dart:async';

import 'package:adivery/adivery_ads.dart';
import 'package:flutter/material.dart';

import '../services/adivery_ads_service.dart';
import '../services/monetization_controller.dart';
import '../theme/app_theme.dart';

class MonetizationScope extends InheritedNotifier<MonetizationController> {
  const MonetizationScope({super.key, required MonetizationController controller, required super.child}) : super(notifier: controller);

  static MonetizationController of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<MonetizationScope>();
    assert(scope != null, 'MonetizationScope not found');
    return scope!.notifier!;
  }
}

class AdBannerSlot extends StatefulWidget {
  const AdBannerSlot({super.key, this.placement = 'banner', this.compact = false});

  final String placement;
  final bool compact;

  @override
  State<AdBannerSlot> createState() => _AdBannerSlotState();
}

class _AdBannerSlotState extends State<AdBannerSlot> {
  late final BannerAd _bannerAd;
  bool _loaded = false;
  bool _failed = false;
  bool _timedOut = false;
  Timer? _timeout;

  @override
  void initState() {
    super.initState();
    _bannerAd = BannerAd(
      AdiveryAdConfig.bannerPlacementId,
      widget.compact ? BannerAdSize.BANNER : BannerAdSize.LARGE_BANNER,
      onAdLoaded: (_) {
        _timeout?.cancel();
        if (mounted) setState(() => _loaded = true);
      },
      onError: (_, __) {
        _timeout?.cancel();
        if (mounted) setState(() => _failed = true);
      },
    );
    _timeout = Timer(const Duration(seconds: 12), () {
      if (mounted && !_loaded) {
        setState(() => _timedOut = true);
      }
    });
  }

  @override
  void dispose() {
    _timeout?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final monetization = MonetizationScope.of(context);
    if (monetization.isPro || _failed || _timedOut) return const SizedBox.shrink();

    final colors = context.appColors;
    final height = widget.compact ? 58.0 : 74.0;

    // Before Adivery reports a successful load, do not show a fake "در حال آماده‌سازی" card.
    // The platform ad view remains mounted so the SDK can finish loading; if it fails or times out, the slot disappears.
    if (!_loaded) {
      return SizedBox(
        width: double.infinity,
        height: height,
        child: Opacity(opacity: 0, child: _bannerAd),
      );
    }

    return Container(
      width: double.infinity,
      height: height,
      margin: EdgeInsets.only(bottom: widget.compact ? 0 : 12),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: colors.cardAlt,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: colors.border),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Center(child: _bannerAd),
      ),
    );
  }
}

class AdiveryNativeAdSlot extends StatefulWidget {
  const AdiveryNativeAdSlot({super.key});

  @override
  State<AdiveryNativeAdSlot> createState() => _AdiveryNativeAdSlotState();
}

class _AdiveryNativeAdSlotState extends State<AdiveryNativeAdSlot> {
  NativeAd? _nativeAd;
  bool _loaded = false;
  bool _failed = false;
  bool _timedOut = false;
  Timer? _timeout;

  @override
  void initState() {
    super.initState();
    _timeout = Timer(const Duration(seconds: 12), () {
      if (mounted && !_loaded) {
        setState(() => _timedOut = true);
      }
    });
    _loadNativeAd();
  }

  void _loadNativeAd() {
    _nativeAd = NativeAd(
      AdiveryAdConfig.nativePlacementId,
      onAdLoaded: () {
        _timeout?.cancel();
        if (mounted) setState(() => _loaded = true);
      },
      onError: (_) {
        _timeout?.cancel();
        if (mounted) setState(() => _failed = true);
      },
    )..loadAd();
  }

  @override
  void dispose() {
    _timeout?.cancel();
    _nativeAd?.destroy();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final monetization = MonetizationScope.of(context);
    if (monetization.isPro || _failed || _timedOut) return const SizedBox.shrink();

    final colors = context.appColors;
    final ad = _nativeAd;
    if (!_loaded || ad == null || ad.isLoaded != true) {
      return const SizedBox.shrink();
    }

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: colors.cardAlt,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: colors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (ad.icon != null)
                ClipRRect(borderRadius: BorderRadius.circular(12), child: SizedBox(width: 44, height: 44, child: ad.icon!))
              else
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(color: colors.accent.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(12)),
                  child: Icon(Icons.campaign_rounded, color: colors.accent),
                ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(ad.headline ?? 'تبلیغ پیشنهادی', style: TextStyle(color: colors.text, fontWeight: FontWeight.w900)),
                    if (ad.advertiser != null) Text(ad.advertiser!, style: TextStyle(color: colors.muted, fontSize: 11)),
                  ],
                ),
              ),
              if (ad.callToAction != null)
                FilledButton(
                  onPressed: ad.recordClick,
                  child: Text(ad.callToAction!),
                ),
            ],
          ),
          if (ad.description != null) ...[
            const SizedBox(height: 8),
            Text(ad.description!, style: TextStyle(color: colors.muted, fontSize: 12)),
          ],
          if (ad.image != null) ...[
            const SizedBox(height: 10),
            ClipRRect(borderRadius: BorderRadius.circular(16), child: ad.image!),
          ],
        ],
      ),
    );
  }
}

Future<void> showOpenInterstitialAd(BuildContext context) async {
  final monetization = MonetizationScope.of(context);
  if (!monetization.hasPendingOpenInterstitial || monetization.isPro) return;
  await monetization.consumeOpenInterstitial();
  await AdiveryAdsService.instance.showInterstitial();
}

Future<bool> showRewardedVideoGate(BuildContext context, {required String title, required String message}) async {
  final monetization = MonetizationScope.of(context);
  if (monetization.isPro) return true;

  final accepted = await showDialog<bool>(
    context: context,
    barrierDismissible: false,
    builder: (context) => AlertDialog(
      title: Text(title),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(message),
          const SizedBox(height: 12),
          const Text('بعد از پایان کامل تبلیغ، فرم ساخت چک‌لیست باز می‌شود.'),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
        FilledButton.icon(onPressed: () => Navigator.pop(context, true), icon: const Icon(Icons.play_circle), label: const Text('دیدن تبلیغ و ادامه')),
      ],
    ),
  );

  if (accepted != true || !context.mounted) return false;

  final rewarded = await AdiveryAdsService.instance.showRewarded();
  if (!context.mounted) return false;

  if (!rewarded) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تبلیغ کامل نشد یا هنوز آماده نیست. دوباره تلاش کنید.')));
    return false;
  }

  await monetization.markRewardedListAllowed();
  return true;
}

Future<bool> showExitDialogWithAd(BuildContext context) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('خروج از چکینو؟'),
      content: const Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('می‌خواهید از برنامه خارج شوید؟'),
          SizedBox(height: 14),
          AdBannerSlot(placement: 'exit_dialog', compact: true),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('ماندن')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('خروج')),
      ],
    ),
  );
  return result == true;
}

Future<void> showProPurchaseDialog(BuildContext context) async {
  await showDialog<void>(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('نسخه پرو'),
      content: const Text('خرید نسخه پرو در این انتشار فعال نیست و هیچ فعال‌سازی آزمایشی در برنامه وجود ندارد.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('متوجه شدم'))],
    ),
  );
}
