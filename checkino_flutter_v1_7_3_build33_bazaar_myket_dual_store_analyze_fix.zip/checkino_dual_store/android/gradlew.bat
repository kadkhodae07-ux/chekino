@echo off
setlocal EnableExtensions

REM Checkino Gradle bootstrap. Always uses the project-pinned Gradle version.
REM It intentionally ignores any globally installed Gradle version.
set "GRADLE_VERSION=8.14.5"
set "CACHE_ROOT=%USERPROFILE%\.gradle\wrapper\dists\checkino-gradle-%GRADLE_VERSION%"
set "DIST_DIR=%CACHE_ROOT%\gradle-%GRADLE_VERSION%"
set "ZIP_FILE=%CACHE_ROOT%\gradle-%GRADLE_VERSION%-bin.zip"
set "URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip"

if not exist "%DIST_DIR%\bin\gradle.bat" (
  if not exist "%CACHE_ROOT%" mkdir "%CACHE_ROOT%"
  if not exist "%ZIP_FILE%" (
    echo Downloading pinned Gradle %GRADLE_VERSION%...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri '%URL%' -OutFile '%ZIP_FILE%'"
    if not %ERRORLEVEL% EQU 0 exit /b %ERRORLEVEL%
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force -Path '%ZIP_FILE%' -DestinationPath '%CACHE_ROOT%'"
  if not %ERRORLEVEL% EQU 0 exit /b %ERRORLEVEL%
)

call "%DIST_DIR%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
