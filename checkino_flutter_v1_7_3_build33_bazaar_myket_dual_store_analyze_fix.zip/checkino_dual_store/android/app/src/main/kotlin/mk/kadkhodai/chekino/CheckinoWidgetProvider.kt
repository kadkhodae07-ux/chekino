package mk.kadkhodai.chekino

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONObject

class CheckinoWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId)
        }
    }

    private fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
        val prefs = context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
        val raw = prefs.getString("flutter.home_widget_payload", null)

        var text = "هنوز کاری برای نمایش ثبت نشده."
        if (!raw.isNullOrBlank()) {
            try {
                val json = JSONObject(raw)
                val items = json.optJSONArray("items")
                if (items != null && items.length() > 0) {
                    val builder = StringBuilder()
                    for (i in 0 until items.length()) {
                        builder.append("• ").append(items.optString(i)).append('\n')
                    }
                    text = builder.toString().trim()
                }
            } catch (_: Exception) {
                text = "چکینو آماده است."
            }
        }

        val packageName = context.packageName
        val layoutId = context.resources.getIdentifier("checkino_widget", "layout", packageName)
        val rootViewId = context.resources.getIdentifier("widgetRoot", "id", packageName)
        val itemsViewId = context.resources.getIdentifier("widgetItems", "id", packageName)
        if (layoutId == 0 || rootViewId == 0 || itemsViewId == 0) return

        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)?.apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val views = RemoteViews(packageName, layoutId)
        views.setTextViewText(itemsViewId, text)
        if (launchIntent != null) {
            val pendingIntent = PendingIntent.getActivity(
                context,
                appWidgetId,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            views.setOnClickPendingIntent(rootViewId, pendingIntent)
        }
        appWidgetManager.updateAppWidget(appWidgetId, views)
    }
}
