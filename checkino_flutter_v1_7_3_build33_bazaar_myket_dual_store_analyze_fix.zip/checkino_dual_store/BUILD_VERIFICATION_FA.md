# گزارش بررسی نسخه ۱.۷.۱+۳۱

## بررسی انجام‌شده

- Product ID بازار در Flutter و بک‌اند یکسان است: `checkino_pro_monthly`.
- پکیج Android با تنظیم بازار یکسان است: `mk.kadkhodai.chekino`.
- کلید RSA عمومی بازار در کلاینت ثبت شده است.
- `flutter_poolakey: ^2.2.0+1.0.0` و JitPack به Android اضافه شده‌اند.
- Package visibility بازار در AndroidManifest ثبت شده است.
- API داخلی اپ: `https://podtman.anony.ir/chekino/api.php`.
- PHP تمام فایل‌های بک‌اند با `php -l` بدون خطای syntax بررسی شده‌اند.
- Workflow قبلی بدون تغییر در همین سورس حفظ شده است.

## محدودیت بررسی

Flutter SDK در محیط بسته‌بندی وجود ندارد؛ بنابراین `flutter analyze`، دریافت dependency جدید و build واقعی APK/AAB در این محیط اجرا نشده است. این مراحل باید توسط GitHub Actions اجرا شوند.
