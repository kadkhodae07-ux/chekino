# اصلاح تداخل SDK پرداخت بازار و مایکت — WF3

علت خطای Build، وجود هم‌زمان این دو کتابخانه در یک Dependency Graph اندروید بود:

- `com.github.cafebazaar.Poolakey:poolakey`
- `com.github.myketstore:myket-billing-client`

هر دو کتابخانه کلاس قدیمی `com.android.vending.billing.IInAppBillingService` را داخل AAR خود دارند؛ بنابراین Gradle در مرحله `check...DuplicateClasses` متوقف می‌شود.

## راه‌حل نهایی

Workflow برای هر فروشگاه یک Workspace تمیز و مستقل می‌سازد:

- نسخه بازار: فقط `flutter_poolakey` و سرویس واقعی بازار
- نسخه مایکت: فقط `myket_iap` و سرویس واقعی مایکت

سرویس فروشگاه غیرفعال با Stub هم‌امضا جایگزین می‌شود تا کد مشترک برنامه بدون وارد کردن Plugin فروشگاه دیگر کامپایل شود.

این روش باعث می‌شود هر APK فقط SDK پرداخت فروشگاه مقصد را داشته باشد و از حذف کلاس، Patch کردن AAR یا نگه‌داشتن Plugin ناقص در زمان اجرا استفاده نمی‌کند.

## RSA مایکت

نبود RSA مانع Build نسخه اولیه مایکت نیست. در حالت Bootstrap، پرداخت مایکت غیرفعال می‌ماند. پس از دریافت کلید عمومی از پنل مایکت، Secret زیر را اضافه و Workflow را دوباره اجرا کنید:

`CHECKINO_MYKET_RSA_KEY`
