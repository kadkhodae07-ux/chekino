#!/usr/bin/env python3
"""Create a store-isolated Flutter workspace for Checkino.

The two Android billing SDKs embed the same legacy IInAppBillingService class.
Keeping both Flutter plugins in one Android dependency graph therefore fails at
check*DuplicateClasses. This tool creates a clean build workspace containing
only the requested store plugin and replaces the inactive Dart adapter with an
API-compatible stub.
"""

from __future__ import annotations

import argparse
import pathlib
import re
import shutil
import sys

IGNORED_NAMES = {
    ".dart_tool",
    ".git",
    ".gradle",
    ".idea",
    "build",
}

STORE_CONFIG = {
    "bazaar": {
        "active_dependency": "flutter_poolakey",
        "inactive_dependency": "myket_iap",
        "inactive_service": pathlib.Path("lib/services/myket_billing_service.dart"),
        "stub": pathlib.Path("tool/store_stubs/myket_billing_service.stub"),
    },
    "myket": {
        "active_dependency": "myket_iap",
        "inactive_dependency": "flutter_poolakey",
        "inactive_service": pathlib.Path("lib/services/bazaar_billing_service.dart"),
        "stub": pathlib.Path("tool/store_stubs/bazaar_billing_service.stub"),
    },
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True, type=pathlib.Path)
    parser.add_argument("--output", required=True, type=pathlib.Path)
    parser.add_argument("--store", required=True, choices=sorted(STORE_CONFIG))
    return parser.parse_args()


def ignore_paths(_directory: str, names: list[str]) -> set[str]:
    return {name for name in names if name in IGNORED_NAMES}


def remove_dependency(pubspec: pathlib.Path, package: str) -> None:
    text = pubspec.read_text(encoding="utf-8")
    pattern = re.compile(rf"^[ \t]+{re.escape(package)}\s*:[^\n]*(?:\n|$)", re.MULTILINE)
    updated, count = pattern.subn("", text)
    if count != 1:
        raise SystemExit(f"ERROR: expected exactly one {package} dependency, found {count}.")
    pubspec.write_text(updated, encoding="utf-8")


def require_dependency(pubspec: pathlib.Path, package: str, present: bool) -> None:
    text = pubspec.read_text(encoding="utf-8")
    found = re.search(rf"^[ \t]+{re.escape(package)}\s*:", text, re.MULTILINE) is not None
    if found != present:
        expectation = "present" if present else "absent"
        raise SystemExit(f"ERROR: {package} must be {expectation} in {pubspec}.")


def main() -> int:
    args = parse_args()
    source = args.source.resolve()
    output = args.output.resolve()
    config = STORE_CONFIG[args.store]

    if not (source / "pubspec.yaml").is_file():
        raise SystemExit(f"ERROR: Flutter source not found at {source}.")
    if source == output or source in output.parents:
        raise SystemExit("ERROR: output workspace must be outside the source tree.")

    shutil.rmtree(output, ignore_errors=True)
    shutil.copytree(source, output, ignore=ignore_paths)

    pubspec = output / "pubspec.yaml"
    remove_dependency(pubspec, config["inactive_dependency"])

    stub = output / config["stub"]
    target = output / config["inactive_service"]
    if not stub.is_file():
        raise SystemExit(f"ERROR: missing store stub: {stub}")
    shutil.copy2(stub, target)

    for stale in (
        output / "pubspec.lock",
        output / ".flutter-plugins",
        output / ".flutter-plugins-dependencies",
    ):
        stale.unlink(missing_ok=True)

    require_dependency(pubspec, config["active_dependency"], True)
    require_dependency(pubspec, config["inactive_dependency"], False)

    marker = output / "STORE_BUILD_PREPARATION.txt"
    marker.write_text(
        "\n".join(
            [
                f"store={args.store}",
                f"active_dependency={config['active_dependency']}",
                f"removed_dependency={config['inactive_dependency']}",
                f"stubbed_service={config['inactive_service']}",
                "",
            ]
        ),
        encoding="utf-8",
    )

    print(f"Prepared {args.store} workspace: {output}")
    print(marker.read_text(encoding="utf-8"), end="")
    return 0


if __name__ == "__main__":
    sys.exit(main())
