/// Store channel and store-specific build values selected at compile time.
///
/// Bazaar build:
///   --dart-define=CHECKINO_STORE=bazaar
///   --dart-define=CHECKINO_BAZAAR_PRODUCT_ID=<bazaar sku>
///   --dart-define=CHECKINO_BAZAAR_RSA_KEY=<bazaar public key>
///
/// Myket build:
///   --dart-define=CHECKINO_STORE=myket
///   --dart-define=CHECKINO_MYKET_PRODUCT_ID=<myket sku>
///   --dart-define=CHECKINO_MYKET_RSA_KEY=<myket public key>
class StoreEnvironment {
  StoreEnvironment._();

  static const String store = String.fromEnvironment(
    'CHECKINO_STORE',
    defaultValue: 'bazaar',
  );

  static const String bazaarProductId = String.fromEnvironment(
    'CHECKINO_BAZAAR_PRODUCT_ID',
    defaultValue: 'checkino_pro_monthly',
  );

  // Existing verified Bazaar public key remains the safe default so the
  // already-working Bazaar build is not changed when no workflow secret is set.
  static const String bazaarPublicRsaKey = String.fromEnvironment(
    'CHECKINO_BAZAAR_RSA_KEY',
    defaultValue:
        'MIHNMA0GCSqGSIb3DQEBAQUAA4G7ADCBtwKBrwCvWiLK1KsWc+xpHMAoQo0lKi67eb3gnAfnHGvbFQz9rfJ3K7ptt7w5Wu9eIQAH1/WVSJwDu4sawqZNsIjhFjQ5Uw5w7GAw7er95Pd/Hho33qWezbnS5D4/tSt2ZUPkFFDaz6ofjdMGTqqmGyilDTquuN4D5ZWbbCo4pEZJ5wLJ6RD8mkT6tSiH3MSXir/WYNZdcMaYu8JrUQmMydsyUOTbHYtPE9Qz/Bioa8UmnvkCAwEAAQ==',
  );

  static const String myketProductId = String.fromEnvironment(
    'CHECKINO_MYKET_PRODUCT_ID',
    defaultValue: 'checkino_pro_monthly',
  );

  // This may intentionally be empty in the first bootstrap APK uploaded to
  // Myket. After the key is received, set CHECKINO_MYKET_RSA_KEY and rebuild.
  static const String myketPublicRsaKey = String.fromEnvironment(
    'CHECKINO_MYKET_RSA_KEY',
  );

  // The first APK submitted to Myket is allowed to run in bootstrap mode.
  // Billing is enabled only when the workflow has a real Myket RSA key.
  static const bool myketBillingEnabled = bool.fromEnvironment(
    'CHECKINO_MYKET_BILLING_ENABLED',
    defaultValue: false,
  );

  static bool get isMyket => store == 'myket';
  static bool get isBazaar => store == 'bazaar';
  static bool get isMyketBillingReady =>
      isMyket && myketBillingEnabled && myketPublicRsaKey.trim().isNotEmpty;
  static String get label => isMyket ? 'مایکت' : 'بازار';
  static String get subscriptionSource => isMyket ? 'myket' : 'bazaar';
  static String get monthlyProductId =>
      isMyket ? myketProductId : bazaarProductId;
}
