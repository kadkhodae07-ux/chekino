/// Store channel and store-specific build values selected at compile time.
///
/// Bazaar build:
///   --dart-define=CHECKINO_STORE=bazaar
///   --dart-define=CHECKINO_BAZAAR_PRODUCT_ID=<bazaar sku>
///   --dart-define=CHECKINO_BAZAAR_RSA_KEY=<bazaar public key>
///
/// Myket build:
///   --dart-define=CHECKINO_STORE=myket
///   --dart-define=CHECKINO_MYKET_PRODUCT_ID=<myket sku>
///   --dart-define=CHECKINO_MYKET_RSA_KEY=<myket public key>
class StoreEnvironment {
  StoreEnvironment._();

  static const String store = String.fromEnvironment(
    'CHECKINO_STORE',
    defaultValue: 'bazaar',
  );

  static const String bazaarProductId = String.fromEnvironment(
    'CHECKINO_BAZAAR_PRODUCT_ID',
    defaultValue: 'checkino_pro_monthly',
  );

  // Existing verified Bazaar public key remains the safe default so the
  // already-working Bazaar build is not changed when no workflow secret is set.
  static const String bazaarPublicRsaKey = String.fromEnvironment(
    'CHECKINO_BAZAAR_RSA_KEY',
    defaultValue:
        'MIHNMA0GCSqGSIb3DQEBAQUAA4G7ADCBtwKBrwCvWiLK1KsWc+xpHMAoQo0lKi67eb3gnAfnHGvbFQz9rfJ3K7ptt7w5Wu9eIQAH1/WVSJwDu4sawqZNsIjhFjQ5Uw5w7GAw7er95Pd/Hho33qWezbnS5D4/tSt2ZUPkFFDaz6ofjdMGTqqmGyilDTquuN4D5ZWbbCo4pEZJ5wLJ6RD8mkT6tSiH3MSXir/WYNZdcMaYu8JrUQmMydsyUOTbHYtPE9Qz/Bioa8UmnvkCAwEAAQ==',
  );

  static const String myketProductId = String.fromEnvironment(
    'CHECKINO_MYKET_PRODUCT_ID',
    defaultValue: 'checkino_pro_monthly',
  );

  static const String bazaarMonthlyPriceLabel = String.fromEnvironment(
    'CHECKINO_BAZAAR_MONTHLY_PRICE_LABEL',
    defaultValue: '۲۵٬۰۰۰ تومان',
  );

  static const String myketMonthlyPriceLabel = String.fromEnvironment(
    'CHECKINO_MYKET_MONTHLY_PRICE_LABEL',
    defaultValue: '۲۵٬۰۰۰ تومان',
  );

  // Myket's public RSA key is also embedded as a release fallback. The
  // workflow still injects the same value explicitly into the Myket build.
  static const String myketPublicRsaKey = String.fromEnvironment(
    'CHECKINO_MYKET_RSA_KEY',
    defaultValue:
        'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCPDfhUVE3fzXcux4N3DT/1FxmF0UuKI9dx14vzgypjRjhaGf51IVXuM27rvOJfjEhb3wUhiicSPRtan+eyC3lIr/QyJHSpVlyUsKbjHYJzTcAABG+JJjWeArZk20vfhD5Wrdcw+44C7dD1cz3XObpy6BFN/BIHVm837zwFiMq3nwIDAQAB',
  );

  static bool get isMyket => store == 'myket';
  static bool get isBazaar => store == 'bazaar';
  static bool get isMyketBillingReady =>
      isMyket && myketPublicRsaKey.trim().isNotEmpty;
  static String get label => isMyket ? 'مایکت' : 'بازار';
  static String get subscriptionSource => isMyket ? 'myket' : 'bazaar';
  static String get monthlyProductId =>
      isMyket ? myketProductId : bazaarProductId;
  static String get monthlyPriceLabel =>
      isMyket ? myketMonthlyPriceLabel : bazaarMonthlyPriceLabel;
}
